export default function CoinbaseWallet() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-black text-white px-4">
      <div className="flex flex-col items-center max-w-md w-full space-y-8">
        {/* Logo */}
        <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center">
          <div className="w-10 h-10 bg-black rounded-sm"></div>
        </div>

        {/* Title */}
        <h1 className="text-5xl font-bold text-center mt-6">Coinbase Wallet</h1>

        {/* Subtitle */}
        <p className="text-2xl text-gray-400 text-center mt-2">
          The fastest and easiest way
          <br />
          to get onchain.
        </p>

        {/* Button with gradient border */}
        <button className="relative mt-16 w-full group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 via-cyan-500 to-yellow-400 rounded-full opacity-90 group-hover:opacity-100 transition duration-300"></div>
          <div className="relative w-full py-4 px-6 bg-black rounded-full">
            <span className="text-xl font-medium">Open Coinbase Wallet</span>
          </div>
        </button>
      </div>
    </div>
  )
}
