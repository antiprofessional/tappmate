import CoinbaseWallet from "../coinbase-wallet"

export default function Page() {
  return <CoinbaseWallet />
}
