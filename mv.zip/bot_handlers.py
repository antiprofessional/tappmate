"""Main bot handlers for user interactions."""
import os
import time
import asyncio
from telegram import Update
from telegram.ext import ContextTypes

from user_manager import UserManager
from email_validator import EmailValidator
from file_handler import FileHandler
from message_templates import MessageTemplates
from license_manager import LicenseManager
from config import BATCH_SIZE, PROGRESS_UPDATE_INTERVAL


class BotHandlers:
    """Main bot handlers for user interactions."""
    
    def __init__(self):
        self.email_validator = EmailValidator()
        self.license_pending_users = {}

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command."""
        if UserManager.is_user_allowed(update.effective_user.id):
            await update.message.reply_text(MessageTemplates.WELCOME_MESSAGE)
        else:
            await self.send_unauthorized_message(update)

    async def send_unauthorized_message(self, update: Update):
        """Send unauthorized access message."""
        await update.message.reply_text(
            MessageTemplates.UNAUTHORIZED_MESSAGE,
            reply_markup=MessageTemplates.get_unauthorized_keyboard()
        )

    async def handle_callback_query(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle callback queries."""
        query = update.callback_query
        await query.answer()
        
        if query.data == "purchase_license":
            await query.edit_message_text(
                "🛒 **Choose your subscription plan:**\n\n"
                "Select the plan that best fits your needs:",
                reply_markup=MessageTemplates.get_purchase_options_keyboard(),
                parse_mode='Markdown'
            )
        elif query.data == "activate_license":
            await query.edit_message_text(
                MessageTemplates.LICENSE_KEY_PROMPT
            )
        
        # Mark user as waiting for license key
        self.license_pending_users[update.effective_user.id] = True

    async def handle_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle text messages."""
        user_id = update.effective_user.id
        
        # Check if user is waiting for license key
        if user_id in self.license_pending_users:
            license_key = update.message.text.strip()
            
            # Validate license key
            is_valid, message = LicenseManager.validate_key(license_key, user_id)
            
            # Remove user from pending list
            self.license_pending_users.pop(user_id, None)
            
            # Send validation result
            await update.message.reply_text(message)
            
            # Notify admin if key was valid
            if is_valid:
                await LicenseManager.notify_admin_key_used(context.bot, license_key, user_id)
                # Send welcome message
                await update.message.reply_text(MessageTemplates.WELCOME_MESSAGE)
            
            return

    async def handle_document(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle document uploads."""
        user_id = update.effective_user.id
        
        if not UserManager.is_user_allowed(user_id):
            await self.send_unauthorized_message(update)
            return

        if not update.message.document.file_name.lower().endswith('.txt'):
            await update.message.reply_text(MessageTemplates.INVALID_FILE_MESSAGE)
            return

        # Download and process file
        file = await update.message.document.get_file()
        file_path = f"emails_{user_id}_{int(time.time())}.txt"
        await file.download_to_drive(file_path)

        try:
            emails = FileHandler.extract_emails_from_file(file_path)
        except Exception as e:
            await update.message.reply_text(f"❌ {str(e)}")
            return
        finally:
            FileHandler.cleanup_file(file_path)

        if not emails:
            await update.message.reply_text(MessageTemplates.NO_EMAILS_FOUND_MESSAGE)
            return
        
        try:
            await self.process_emails(update, emails)
        finally:
            pass

    async def process_emails(self, update: Update, emails: list):
        """Process and validate emails with high-speed batching."""
        # Send initial message
        status_msg = await update.message.reply_text(
            MessageTemplates.get_validation_start_message(len(emails))
        )
        
        start_time = time.time()
        valid_emails = []
        
        # Use dynamic batch sizing between 100-200
        batch_size = min(200, max(100, len(emails) // 10))  # Adaptive batch size
        total_processed = 0
        
        for i in range(0, len(emails), batch_size):
            batch = emails[i:i + batch_size]
            batch_start = time.time()
            
            # Process batch concurrently with maximum speed
            batch_valid = await self.email_validator.validate_batch(batch)
            valid_emails.extend(batch_valid)
            
            total_processed += len(batch)
            batch_time = time.time() - batch_start
            
            # Update progress more frequently for better UX
            if total_processed % 100 == 0 or total_processed == len(emails):
                try:
                    elapsed = time.time() - start_time
                    rate = total_processed / elapsed if elapsed > 0 else 0
                    
                    await status_msg.edit_text(
                        MessageTemplates.get_progress_message(
                            total_processed, len(emails), len(valid_emails), rate, elapsed
                        )
                    )
                except Exception:
                    pass
        
        # Small delay to prevent overwhelming the API
        if i + batch_size < len(emails):  # Don't delay after last batch
            await asyncio.sleep(0.1)

        # Send results
        await self.send_results(update, status_msg, emails, valid_emails, start_time)

    async def send_results(self, update: Update, status_msg, all_emails: list, valid_emails: list, start_time: float):
        """Send validation results to user."""
        total_time = time.time() - start_time
        
        if valid_emails:
            # Create and send valid emails file
            output_file = FileHandler.save_valid_emails(valid_emails, update.effective_user.id)
            
            try:
                with open(output_file, "rb") as f:
                    await update.message.reply_document(
                        f, 
                        filename="valid.txt",
                        caption=MessageTemplates.get_file_caption(
                            len(all_emails), len(valid_emails), total_time
                        ),
                        parse_mode='Markdown'
                    )
            except Exception as e:
                await update.message.reply_text(f"❌ Error sending results file: {str(e)}")

            FileHandler.cleanup_file(output_file)

            # Final summary message
            await status_msg.edit_text(
                MessageTemplates.get_completion_message(
                    len(all_emails), len(valid_emails), total_time
                ),
                parse_mode='Markdown'
            )
        else:
            # No valid emails found
            await status_msg.edit_text(
                f"❌ **VALIDATION COMPLETED**\n\n"
                f"📊 **Results:**\n"
                f"• Total: {len(all_emails)} emails\n"
                f"• ✅ Valid: 0\n"
                f"• ⏱️ Total Time: {total_time:.2f} seconds\n\n"
                f"😔 No valid emails found in your list.",
                parse_mode='Markdown'
            )

    def cleanup(self):
        """Clean up resources."""
        self.email_validator.cleanup()
