"""Admin functionality handler."""
from telegram import Update
from telegram.ext import ContextTypes
from user_manager import UserManager
from message_templates import MessageTemplates
from config import ADMIN_ID


class AdminHandler:
    """Handles admin-specific functionality."""
    
    def __init__(self):
        pass

    async def admin_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /admin command."""
        if update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("❌ Unauthorized.")
            return
        
        # Show user info
        total_users = len(UserManager.load_users())
        await update.message.reply_text(
            f"🔧 **ADMIN PANEL**\n\n"
            f"👥 Total Users: {total_users}\n"
            f"🤖 Bot Status: Online", 
            reply_markup=MessageTemplates.get_admin_keyboard(),
            parse_mode='Markdown'
        )

    async def admin_callback_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle admin callback queries."""
        query = update.callback_query
        await query.answer()

        if update.effective_user.id != ADMIN_ID:
            await query.edit_message_text("❌ Unauthorized.")
            return

        users = UserManager.load_users()

        if query.data == "add_user":
            context.user_data["action"] = "add"
            await query.edit_message_text("👤 Send user ID to add:")
        elif query.data == "remove_user":
            context.user_data["action"] = "remove"
            await query.edit_message_text("🗑️ Send user ID to remove:")
        elif query.data == "show_users":
            if not users:
                await query.edit_message_text(
                    f"📋 **USER LIST**\n\n"
                    f"No authorized users yet.", 
                    reply_markup=MessageTemplates.get_admin_keyboard(),
                    parse_mode='Markdown'
                )
            else:
                user_list = "\n".join([f"• {user}" for user in users])
                await query.edit_message_text(
                    f"📋 **AUTHORIZED USERS**\n\n"
                    f"{user_list}\n\n"
                    f"👥 Total: {len(users)}", 
                    reply_markup=MessageTemplates.get_admin_keyboard(),
                    parse_mode='Markdown'
                )

    async def handle_admin_response(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle admin text responses for user management."""
        if update.effective_user.id != ADMIN_ID:
            return

        action = context.user_data.get("action")
        if not action:
            return

        user_id = update.message.text.strip()

        if not user_id.isdigit():
            await update.message.reply_text("❌ Invalid ID. Must be a number.")
            return

        if action == "add":
            UserManager.add_user(user_id)
            await update.message.reply_text(
                f"✅ User {user_id} added successfully!", 
                reply_markup=MessageTemplates.get_admin_keyboard()
            )
        elif action == "remove":
            if UserManager.remove_user(user_id):
                await update.message.reply_text(
                    f"🗑️ User {user_id} removed successfully!", 
                    reply_markup=MessageTemplates.get_admin_keyboard()
                )
            else:
                await update.message.reply_text(
                    "❌ User ID not found.", 
                    reply_markup=MessageTemplates.get_admin_keyboard()
                )

        context.user_data.pop("action", None)
