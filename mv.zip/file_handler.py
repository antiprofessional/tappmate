"""File handling utilities."""
import os
import time
from typing import List, Tuple


class FileHandler:
    """Handles file operations for email processing."""
    
    @staticmethod
    def extract_emails_from_file(file_path: str) -> List[str]:
        """Extract unique emails from a text file."""
        try:
            with open(file_path, "r", encoding='utf-8', errors='ignore') as f:
                lines = [line.strip() for line in f if line.strip()]
                
            # Extract emails (basic email pattern)
            emails = []
            for line in lines:
                if '@' in line and '.' in line:
                    # Extract email from line (in case there's extra text)
                    parts = line.split()
                    for part in parts:
                        if '@' in part and '.' in part:
                            emails.append(part.strip())
                            break
                    else:
                        if '@' in line and '.' in line:
                            emails.append(line)
            
            # Remove duplicates while preserving order
            seen = set()
            unique_emails = []
            for email in emails:
                if email.lower() not in seen:
                    seen.add(email.lower())
                    unique_emails.append(email)
            
            return unique_emails
            
        except Exception as e:
            raise Exception(f"Error reading file: {str(e)}")

    @staticmethod
    def save_valid_emails(emails: List[str], user_id: int) -> str:
        """Save valid emails to a file and return the filename."""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        output_file = f"valid_{user_id}_{timestamp}.txt"
        
        with open(output_file, "w", encoding='utf-8') as f:
            for email in emails:
                f.write(f"{email}\n")
        
        return output_file

    @staticmethod
    def cleanup_file(file_path: str) -> None:
        """Safely remove a file."""
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
        except Exception:
            pass
