"""Email validation module."""
import asyncio
import requests
from concurrent.futures import ThreadPoolExecutor
from typing import List, Tuple
import random
from config import (
    EMAIL_VALIDATION_URL, 
    DEFAULT_HEADERS, REQUEST_TIMEOUT, GLOBAL_SEMAPHORE_LIMIT, 
    THREAD_POOL_MAX_WORKERS
)


class EmailValidator:
    """Handles email validation logic."""
    
    def __init__(self):
        self.global_semaphore = asyncio.Semaphore(GLOBAL_SEMAPHORE_LIMIT)
        self.executor = ThreadPoolExecutor(max_workers=THREAD_POOL_MAX_WORKERS)
        # Create a session for connection pooling
        self.session = requests.Session()
        self.session.headers.update(DEFAULT_HEADERS)

    def validate_email_sync(self, email: str) -> str:
        """Synchronous validation function to run in thread pool."""
        payload = {"email": email}
        
        headers = {'Content-Type': 'application/json'}
        
        try:
            response = self.session.post(
                EMAIL_VALIDATION_URL,
                headers=headers,
                json=payload,
                timeout=REQUEST_TIMEOUT
            )
            
            response.raise_for_status()
            response_json = response.json()
            
            if response_json.get('status') == 'valid':
                return f"valid|{email}"
            else:
                return f"invalid|{email}"
            
        except Exception:
            return f"error|{email}"

    async def validate_email(self, email: str) -> str:
        """Async wrapper for email validation."""
        async with self.global_semaphore:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(self.executor, self.validate_email_sync, email)

    async def validate_batch(self, emails: List[str]) -> List[str]:
        """Validate a batch of emails concurrently with maximum speed."""
        # Shuffle emails to distribute load
        emails_shuffled = emails.copy()
        random.shuffle(emails_shuffled)
        
        tasks = [self.validate_email(email) for email in emails_shuffled]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        valid_emails = []
        for result in results:
            if isinstance(result, str) and result.startswith("valid|"):
                valid_emails.append(result.split("|")[1])
        
        return valid_emails

    def cleanup(self):
        """Clean up resources."""
        self.session.close()
        self.executor.shutdown(wait=True)
