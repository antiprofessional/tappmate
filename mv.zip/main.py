"""Main application entry point."""
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters

from config import BOT_TOKEN
from bot_handlers import BotHandlers
from admin_handler import AdminHandler


def main():
    """Main function to start the bot."""
    if not BOT_TOKEN:
        print("BOT_TOKEN not found in .env file.")
        return

    # Initialize handlers
    bot_handlers = BotHandlers()
    admin_handler = AdminHandler()
    
    # Create application
    app = Application.builder().token(BOT_TOKEN).build()

    # Add handlers
    app.add_handler(CommandHandler("start", bot_handlers.start))
    app.add_handler(CommandHandler("admin", admin_handler.admin_command))
    app.add_handler(CallbackQueryHandler(admin_handler.admin_callback_handler))
    app.add_handler(MessageHandler(filters.Document.ALL, bot_handlers.handle_document))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), bot_handlers.handle_text))

    print("🚀 Starting Email Validator Bot...")
    print("📧 Ready to validate emails!")
    
    try:
        app.run_polling()
    except KeyboardInterrupt:
        print("🛑 Bot stopped by user")
    finally:
        bot_handlers.cleanup()


if __name__ == "__main__":
    main()
