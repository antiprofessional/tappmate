"""User management module for handling authorized users."""
import os
from typing import Set
from config import USERS_FILE, ADMIN_ID


class UserManager:
    """Handles user authorization and management."""
    
    @staticmethod
    def load_users() -> Set[str]:
        """Load authorized users from file."""
        if not os.path.exists(USERS_FILE):
            return set()
        with open(USERS_FILE, "r") as f:
            return set(line.strip() for line in f)

    @staticmethod
    def save_users(users: Set[str]) -> None:
        """Save authorized users to file."""
        with open(USERS_FILE, "w") as f:
            f.write("\n".join(users))

    @staticmethod
    def is_user_allowed(user_id: int) -> bool:
        """Check if user is authorized to use the bot."""
        return str(user_id) in UserManager.load_users() or user_id == ADMIN_ID

    @staticmethod
    def add_user(user_id: str) -> bool:
        """Add a user to authorized list."""
        users = UserManager.load_users()
        users.add(user_id)
        UserManager.save_users(users)
        return True

    @staticmethod
    def remove_user(user_id: str) -> bool:
        """Remove a user from authorized list."""
        users = UserManager.load_users()
        if user_id in users:
            users.remove(user_id)
            UserManager.save_users(users)
            return True
        return False
