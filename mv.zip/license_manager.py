"""License key management module."""
import os
import requests
import json
from typing import Dict, List, Tuple, Optional
from config import ADMIN_ID
from user_manager import UserManager

class LicenseManager:
    """Handles license key validation and management."""
    
    LICENSE_URL = "https://amlyze.tech/webhook/cbvmbot.txt"
    USED_KEYS_FILE = "used_keys.json"
    
    @staticmethod
    def load_used_keys() -> Dict[str, int]:
        """Load previously used license keys."""
        if not os.path.exists(LicenseManager.USED_KEYS_FILE):
            return {}
        try:
            with open(LicenseManager.USED_KEYS_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return {}
    
    @staticmethod
    def save_used_keys(used_keys: Dict[str, int]) -> None:
        """Save used license keys to file."""
        with open(LicenseManager.USED_KEYS_FILE, "w") as f:
            json.dump(used_keys, f)
    
    @staticmethod
    def fetch_valid_keys() -> List[str]:
        """Fetch valid license keys from remote URL."""
        try:
            response = requests.get(LicenseManager.LICENSE_URL, timeout=10)
            if response.status_code == 200:
                # Assuming keys are one per line in the text file
                return [key.strip() for key in response.text.splitlines() if key.strip()]
            return []
        except Exception:
            return []
    
    @staticmethod
    def validate_key(key: str, user_id: int) -> Tuple[bool, str]:
        """
        Validate a license key.
        
        Returns:
            Tuple[bool, str]: (is_valid, message)
        """
        # Check if key was already used
        used_keys = LicenseManager.load_used_keys()
        if key in used_keys:
            return False, "❌ This license key has already been used."
        
        # Fetch valid keys from remote source
        valid_keys = LicenseManager.fetch_valid_keys()
        
        if key in valid_keys:
            # Mark key as used
            used_keys[key] = user_id
            LicenseManager.save_used_keys(used_keys)
            
            # Add user to authorized users
            UserManager.add_user(str(user_id))
            
            return True, "✅ License key validated successfully! You now have access to the bot."
        
        return False, "❌ Invalid license key. Please check and try again."
    
    @staticmethod
    async def notify_admin_key_used(bot, key: str, user_id: int) -> None:
        """Notify admin about a license key being used."""
        try:
            await bot.send_message(
                chat_id=ADMIN_ID,
                text=f"🔑 License key used:\n\n"
                     f"Key: `{key}`\n"
                     f"User ID: `{user_id}`\n"
                     f"Time: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                parse_mode='Markdown'
            )
        except Exception:
            pass
