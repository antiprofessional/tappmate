"""Configuration module for the Email Validator Bot."""
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Bot configuration
BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = 6686015911
USERS_FILE = "users.txt"

# Validation settings
GLOBAL_SEMAPHORE_LIMIT = 500  # Increased from 200
THREAD_POOL_MAX_WORKERS = 300  # Increased from 100
BATCH_SIZE = 150  # Increased from 50 (100-200 range)
PROGRESS_UPDATE_INTERVAL = 150  # Updated to match new batch size
REQUEST_TIMEOUT = 15  # Increased timeout for higher load

# API endpoints
EMAIL_VALIDATION_URL = 'https://amlyze.tech/api/check.php'

# Request headers
DEFAULT_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}
