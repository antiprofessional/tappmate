"""Message templates and keyboard layouts."""
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


class MessageTemplates:
    """Contains message templates and keyboard layouts."""
    
    WELCOME_MESSAGE = (
        "👐🏼 Welcome to COINBASE VALID MAIL CHECKER BOT!\n"
        "DEVELOPED BY: @ACETYLATE\n\n"
        "✉️ Please send your mail list as a .txt file to validate.\n"
    )
    
    UNAUTHORIZED_MESSAGE = (
        "❌ You are not authorized to use this bot.\n\n"
        "🪪 Please purchase a license key to get access!"
    )
    
    INVALID_FILE_MESSAGE = (
        "❌ Invalid file format!\n\n"
        "📁 Please upload a .txt file containing email addresses.\n"
        "Example: emails.txt, mailist.txt"
    )
    
    NO_EMAILS_FOUND_MESSAGE = (
        "❌ No valid email addresses found in the file!\n\n"
        "Please make sure your file contains email addresses in the format:\n"
        "example@domain.com"
    )
    
    LICENSE_KEY_PROMPT = (
        "🔑 Please enter your license key to activate the bot.\n\n"
        "If you don't have a license key, you can purchase one below:"
    )
    
    @staticmethod
    def get_unauthorized_keyboard():
        """Get keyboard for unauthorized users."""
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🔑 Purchase License Key", callback_data="purchase_license")],
            [InlineKeyboardButton("✅ Activate License Key", callback_data="activate_license")]
        ])
    
    @staticmethod
    def get_purchase_options_keyboard():
        """Get keyboard with purchase options."""
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🥉 24 HOURS (TRIAL)", url="http://t.me/acecoinbasebot/trial")],
            [InlineKeyboardButton("🥈 6 DAYS", url="http://t.me/acecoinbasebot/six")],
            [InlineKeyboardButton("🥇 25 DAYS", url="http://t.me/acecoinbasebot/twe")]
        ])

    @staticmethod
    def get_admin_keyboard():
        """Get admin control keyboard."""
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Add User", callback_data="add_user")],
            [InlineKeyboardButton("➖ Remove User", callback_data="remove_user")],
            [InlineKeyboardButton("📄 Show Users", callback_data="show_users")]
        ])

    @staticmethod
    def get_validation_start_message(total_emails: int) -> str:
        """Get validation start message."""
        return (
            f"🚀 Starting validation process...\n\n"
            f"📊 Total emails to validate: {total_emails}\n"
            f"⏱️ Estimated time: {total_emails/20:.1f} minutes\n"
            f"🔄 Processing..."
        )

    @staticmethod
    def get_progress_message(processed: int, total: int, valid_count: int, rate: float, elapsed: float) -> str:
        """Get progress update message."""
        progress_percent = (processed / total) * 100
        return (
            f"🔄 Validation in progress...\n\n"
            f"📊 Progress: {processed}/{total} ({progress_percent:.1f}%)\n"
            f"✅ Valid emails found: {valid_count}\n"
            f"⚡ Rate: {rate:.1f} emails/second\n"
            f"⏱️ Elapsed: {elapsed:.1f}s"
        )

    @staticmethod
    def get_completion_message(total: int, valid_count: int, total_time: float) -> str:
        """Get validation completion message."""
        success_rate = (valid_count/total*100) if total > 0 else 0
        processing_rate = total/total_time if total_time > 0 else 0
        
        return (
            f"🎉 **VALIDATION COMPLETED!**\n\n"
            f"📊 **Results:**\n"
            f"• Total: {total} emails\n"
            f"• ✅ Valid: {valid_count}\n"
            f"• 📈 Success Rate: {success_rate:.2f}%\n"
            f"• ⏱️ Total Time: {total_time:.2f} seconds\n"
            f"• ⚡ Processing Rate: {processing_rate:.2f} emails/second\n\n"
            f"📁 Valid emails file sent above! ⬆️"
        )

    @staticmethod
    def get_file_caption(total: int, valid_count: int, total_time: float) -> str:
        """Get file caption for results."""
        success_rate = (valid_count/total*100) if total > 0 else 0
        processing_rate = total/total_time if total_time > 0 else 0
        
        return (
            f"✅ **VALIDATION COMPLETED!**\n\n"
            f"📊 **Results:**\n"
            f"• Total Processed: {total}\n"
            f"• ✅ Valid Emails: {valid_count}\n"
            f"• 📈 Success Rate: {success_rate:.2f}%\n"
            f"• ⏱️ Time: {total_time:.2f}s\n"
            f"• ⚡ Rate: {processing_rate:.2f} emails/sec\n\n"
            f"🔥 **Powered by @ACETARY**"
        )
