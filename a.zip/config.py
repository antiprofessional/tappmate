"""Configuration settings for the Telegram bot"""
import os
from dataclasses import dataclass

@dataclass
class BotConfig:
    """Bot configuration class"""
    API_TOKEN: str = '7715353665:AAFBidbYxPuXkSb4VemN6vc2W9b-juCVs50'  # Replace with your actual token
    PASSWORD: str = 'acd'
    MAX_MESSAGE_LENGTH: int = 4096
    TEMP_DIR: str = '/tmp/bot_files'
    
    def __post_init__(self):
        """Create temp directory if it doesn't exist"""
        os.makedirs(self.TEMP_DIR, exist_ok=True)

# Global config instance
config = BotConfig()

