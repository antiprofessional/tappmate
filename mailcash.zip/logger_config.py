"""Logging configuration"""
import logging

def setup_logger():
    """Set up basic logging configuration"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[logging.FileHandler("bot_log.txt")]
    )
    return logging.getLogger(__name__)

logger = setup_logger()
