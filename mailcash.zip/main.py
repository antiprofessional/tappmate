"""
AceMailerBot - Telegram Email Marketing Bot
Main entry point and bot setup
"""
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    filters, ConversationHandler, CallbackQueryHandler
)
from config import TELEGRAM_BOT_TOKEN, LICENSE_KEY, SENDER_NAME, SENDER_EMAIL, SUBJECT, FILE_CONTENT, MAILIST, DELAY, TEMPLATE_SELECTION
from logger_config import logger
from conversation_handlers import (
    start, show_main_menu, handle_main_menu, 
    show_template_browser, handle_template_browser,
    show_template_preview, handle_template_preview,
    handle_activate_license, validate_license, handle_start_bot, handle_buy_subscription,
    get_sender_name, get_sender_email, get_subject, get_file_content,
    get_mailist, handle_delay_selection, get_delay, start_sending, cancel, cancel_campaign,
    MAIN_MENU, TEMPLATE_BROWSER, TEMPLATE_PREVIEW
)
from admin_handlers import admin_panel, handle_admin_action, handle_admin_input
from template_manager import ensure_templates_directory

async def error_handler(update, context):
    """Handle errors in the telegram bot"""
    logger.error(f"Bot error: {context.error}")

    # Notify user of error if possible  
    if update and update.effective_message:  
        await update.effective_message.reply_text("An error occurred while processing your request. Please try again or contact the developer.")

def main():
    """Start the bot"""
    # Check if required environment variables are set
    if not TELEGRAM_BOT_TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN is not set! Bot cannot start.")
        return

    try:  
        # Create application  
        application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()  

        # Ensure templates directory exists
        ensure_templates_directory()

        # Add license key conversation handler
        license_handler = ConversationHandler(
            entry_points=[CallbackQueryHandler(handle_activate_license, pattern="activate_license")],
            states={
                LICENSE_KEY: [MessageHandler(filters.TEXT & ~filters.COMMAND, validate_license)]
            },
            fallbacks=[CommandHandler('cancel', cancel)]
        )
        application.add_handler(license_handler)

        # Add main conversation handler with enhanced navigation
        main_handler = ConversationHandler(
            entry_points=[
                CommandHandler('start', start),
                CallbackQueryHandler(handle_start_bot, pattern="start_bot")
            ],
            states={
                MAIN_MENU: [
                    CallbackQueryHandler(handle_main_menu)
                ],
                TEMPLATE_BROWSER: [
                    CallbackQueryHandler(handle_template_browser)
                ],
                TEMPLATE_PREVIEW: [
                    CallbackQueryHandler(handle_template_preview)
                ],
                SENDER_NAME: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, get_sender_name),
                    CallbackQueryHandler(cancel_campaign, pattern="cancel_campaign")
                ],
                SENDER_EMAIL: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, get_sender_email),
                    CallbackQueryHandler(cancel_campaign, pattern="cancel_campaign")
                ],
                SUBJECT: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, get_subject),
                    CallbackQueryHandler(cancel_campaign, pattern="cancel_campaign")
                ],
                FILE_CONTENT: [
                    MessageHandler(filters.Document.ALL, get_file_content),
                    CallbackQueryHandler(cancel_campaign, pattern="cancel_campaign")
                ],
                MAILIST: [
                    MessageHandler(filters.Document.ALL, get_mailist),
                    CallbackQueryHandler(cancel_campaign, pattern="cancel_campaign")
                ],
                DELAY: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, get_delay),
                    CallbackQueryHandler(handle_delay_selection, pattern="delay_"),
                    CallbackQueryHandler(start_sending, pattern="start_sending"),
                    CallbackQueryHandler(cancel_campaign, pattern="cancel_campaign")
                ]
            },
            fallbacks=[
                CommandHandler('cancel', cancel),
                CallbackQueryHandler(show_main_menu, pattern="back_to_main")
            ]
        )
        application.add_handler(main_handler)
          
        # Add other handlers  
        application.add_handler(CallbackQueryHandler(handle_buy_subscription, pattern="buy_subscription"))  
        application.add_handler(CommandHandler("admin", admin_panel))  
        application.add_handler(CallbackQueryHandler(handle_admin_action, pattern="^(admin_|delete_template_|confirm_delete_)"))  
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND | filters.Document.ALL, handle_admin_input))  

        # Add error handler  
        application.add_error_handler(error_handler)  
          
        # Start the bot  
        logger.info("Starting AceMailerBot...")
        application.run_polling()  
          
    except Exception as e:  
        logger.error(f"Failed to start bot: {e}")

if __name__ == "__main__":
    main()
