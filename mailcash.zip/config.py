"""Configuration and environment variables"""
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("T")
ADMIN_ID = int(os.getenv("U")) if os.getenv("U") else None

# License key validation URL
LICENSE_KEY_URL = "https://amlyze.tech/webhook/license_keys.txt"

# Conversation states
LICENSE_KEY, SENDER_NAME, SENDER_EMAIL, SUBJECT, FILE_CONTENT, MAILIST, DELAY = range(7)
# Template selection state
TEMPLATE_SELECTION = 7
# Additional states for enhanced navigation
MAIN_MENU, TEMPLATE_BROWSER, TEMPLATE_PREVIEW = range(8, 11)
