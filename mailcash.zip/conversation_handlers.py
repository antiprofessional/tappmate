"""Main conversation flow handlers"""
import asyncio
import datetime
import html2text
import math
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode
from telegram.ext import ConversationHandler, ContextTypes
from config import ADMIN_ID, SENDER_NAME, SENDER_EMAIL, SUBJECT, FILE_CONTENT, MAILIST, DELAY, LICENSE_KEY, TEMPLATE_SELECTION
from file_manager import load_allowed_user_ids, add_user_to_allowed_list
from license_validator import validate_license_key
from email_sender import process_email_campaign
from template_manager import get_templates, get_template_by_id, get_templates_by_platform
from logger_config import logger

# Define additional states for enhanced navigation
MAIN_MENU, TEMPLATE_BROWSER, TEMPLATE_PREVIEW, PLATFORM_SELECTION = range(8, 12)

# Store pagination data
TEMPLATES_PER_PAGE = 5

async def start(update, context):
    """Start the conversation and check if user is authorized"""
    user_id = update.message.from_user.id
    username = update.message.from_user.username or "Unknown"
    
    logger.info(f"User {user_id} (@{username}) started the bot")

    allowed_user_ids = load_allowed_user_ids()  
    if user_id in allowed_user_ids or user_id == ADMIN_ID:  
        # Clear any previous data
        context.user_data.clear()
        
        # Show main menu
        return await show_main_menu(update, context)
    else:  
        keyboard = [  
            [InlineKeyboardButton("🔑 ACTIVATE LICENSE KEY", callback_data="activate_license")],
            [InlineKeyboardButton("📞 CONTACT DEVELOPER", url="https://t.me/acetary")],  
            [InlineKeyboardButton("💳 BUY SUBSCRIPTION", callback_data="buy_subscription")]  
        ]  
        reply_markup = InlineKeyboardMarkup(keyboard)  
        await update.message.reply_text(  
            "🚫 YOU ARE NOT AUTHORIZED TO USE THIS BOT\n\n"
            "Please activate your license key or subscribe to a plan to use @CashMailerBot.\n\n"
            "If you have a license key, click the button below to activate it:",  
            reply_markup=reply_markup  
        )  
        return ConversationHandler.END

async def show_main_menu(update, context):
    """Show the main menu with all options"""
    # Clear any previous template selection data
    context.user_data.pop('selected_platform', None)
    context.user_data.pop('template_page', None)
    context.user_data.pop('selected_template_id', None)
    context.user_data.pop('for_campaign', None)
    
    # Determine if this is from a message or callback
    if update.callback_query:
        query = update.callback_query
        await query.answer()
        message_func = query.edit_message_text
    else:
        message_func = update.message.reply_text
    
    keyboard = [
        [InlineKeyboardButton("📧 Start Email Campaign", callback_data="start_campaign")],
        [InlineKeyboardButton("📝 Browse Templates", callback_data="browse_templates")],
        [InlineKeyboardButton("⚙️ Settings", callback_data="settings")],
        [InlineKeyboardButton("❓ Help", callback_data="help")]
    ]
    
    await message_func(
        "🤖 *CashMailerBot MAIN MENU*\n\n"
        "Welcome to the CashMailerBot! Choose an option below to get started:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    
    return MAIN_MENU

async def handle_main_menu(update, context):
    """Handle main menu button clicks"""
    query = update.callback_query
    await query.answer()
    
    choice = query.data
    
    if choice == "start_campaign":
        # Ask if user wants to use a template or upload their own
        keyboard = [  
            [InlineKeyboardButton("📝 Use Template", callback_data="use_template")],  
            [InlineKeyboardButton("📤 Upload My Own HTML", callback_data="upload_own")],
            [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_to_main")]
        ]  
        await query.edit_message_text(
            "📧 *START EMAIL CAMPAIGN*\n\n"
            "Would you like to use a premade template or upload your own HTML?",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
        return MAIN_MENU
    
    elif choice == "browse_templates":
        # Show platform selection first
        context.user_data['for_campaign'] = False
        return await show_platform_selection(update, context)
    
    elif choice == "settings":
        # Show settings menu (removed SMTP settings - admin only)
        keyboard = [
            [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_to_main")]
        ]
        await query.edit_message_text(
            "⚙️ *SETTINGS*\n\n"
            "Settings are currently managed by the administrator.\n"
            "Contact @acetary for configuration changes.",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
        return MAIN_MENU
    
    elif choice == "help":
        # Show help menu
        keyboard = [
            [InlineKeyboardButton("📚 Usage Guide", callback_data="usage_guide")],
            [InlineKeyboardButton("🔧 Troubleshooting", callback_data="troubleshooting")],
            [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_to_main")]
        ]
        await query.edit_message_text(
            "❓ *HELP CENTER*\n\n"
            "What do you need help with?",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
        return MAIN_MENU
    
    elif choice == "back_to_main":
        return await show_main_menu(update, context)
    
    elif choice == "use_template":
        # Show platform selection for campaign
        context.user_data['for_campaign'] = True
        return await show_platform_selection(update, context)
    
    elif choice == "upload_own":
        await query.edit_message_text("Please enter Email Sender Name:")
        return SENDER_NAME
    
    elif choice == "usage_guide":
        guide = (
            "*📚 USAGE GUIDE*\n\n"
            "*Starting a Campaign:*\n"
            "1. Select 'Start Email Campaign'\n"
            "2. Choose a template or upload your own HTML\n"
            "3. Enter sender details and subject\n"
            "4. Upload recipient list\n"
            "5. Set delay between emails\n\n"
            
            "*Templates:*\n"
            "- Browse available templates by platform\n"
            "- Preview templates before using them\n"
            "- Templates support dynamic placeholders like {email}, {otp}, etc.\n\n"
            
            "*SMTP Settings:*\n"
            "- SMTP servers are managed by the administrator\n"
            "- Multiple SMTP servers are used in rotation for better delivery"
        )
        
        keyboard = [[InlineKeyboardButton("🔙 Back to Help", callback_data="help")]]
        await query.edit_message_text(
            guide,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
        return MAIN_MENU
    
    elif choice == "troubleshooting":
        troubleshooting = (
            "*🔧 TROUBLESHOOTING*\n\n"
            "*Email Not Sending:*\n"
            "- Check sender email format\n"
            "- Check recipient email format\n"
            "- Try increasing delay between emails\n"
            "- Contact administrator for SMTP issues\n\n"
            
            "*Template Issues:*\n"
            "- Ensure HTML is properly formatted\n"
            "- Check for missing closing tags\n"
            "- Verify placeholders are correctly formatted\n\n"
            
            "*Other Issues:*\n"
            "- Restart the bot with /start\n"
            "- Contact support at @acetary"
        )
        
        keyboard = [[InlineKeyboardButton("🔙 Back to Help", callback_data="help")]]
        await query.edit_message_text(
            troubleshooting,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
        return MAIN_MENU
    
    return MAIN_MENU

async def show_platform_selection(update, context):
    """Show platform selection menu"""
    query = update.callback_query
    if query:
        await query.answer()
    
    # Get templates organized by platform
    platforms = get_templates_by_platform()
    
    if not platforms:
        keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_to_main")]]
        
        if query:
            await query.edit_message_text(
                "No templates found. Please contact the administrator.",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        else:
            await update.message.reply_text(
                "No templates found. Please contact the administrator.",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        return MAIN_MENU
    
    # Create platform buttons with emojis and counts
    keyboard = []
    platform_emojis = {
        'Coinbase': '🔵',
        'Binance': '🟡', 
        'Kraken': '🟣',
        'Ledger': '🟠',
        'Trezor': '🟢',
        'Google': '🔴'
    }
    
    for platform, templates in platforms.items():
        emoji = platform_emojis.get(platform, '📝')
        count = len(templates)
        keyboard.append([
            InlineKeyboardButton(
                f"{emoji} {platform} ({count} templates)", 
                callback_data=f"platform_{platform.lower()}"
            )
        ])
    
    keyboard.append([InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_to_main")])
    
    message_text = "🏢 *SELECT EXCHANGE*\n\n" \
                  "Choose a platform to browse its templates:"
    
    if query:
        await query.edit_message_text(
            message_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
    else:
        await update.message.reply_text(
            message_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
    
    return PLATFORM_SELECTION

async def handle_platform_selection(update, context):
    """Handle platform selection"""
    query = update.callback_query
    await query.answer()
    
    choice = query.data
    
    if choice == "back_to_main":
        return await show_main_menu(update, context)
    
    elif choice.startswith("platform_"):
        platform = choice.replace("platform_", "").title()
        context.user_data['selected_platform'] = platform
        context.user_data['template_page'] = 1
        return await show_template_browser(update, context)
    
    return PLATFORM_SELECTION

async def show_template_browser(update, context):
    """Show template browser with pagination for selected platform"""
    query = update.callback_query
    if query:
        await query.answer()
    
    # Get current page and platform
    current_page = context.user_data.get('template_page', 1)
    selected_platform = context.user_data.get('selected_platform')
    
    if not selected_platform:
        return await show_platform_selection(update, context)
    
    # Get templates for the selected platform
    platforms = get_templates_by_platform()
    templates = platforms.get(selected_platform, [])
    
    if not templates:
        keyboard = [[InlineKeyboardButton("🔙 Back to Platforms", callback_data="back_to_platforms")]]
        
        if query:
            await query.edit_message_text(
                f"No templates found for {selected_platform}. Please contact the administrator.",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        else:
            await update.message.reply_text(
                f"No templates found for {selected_platform}. Please contact the administrator.",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        return PLATFORM_SELECTION
    
    # Calculate pagination
    total_pages = math.ceil(len(templates) / TEMPLATES_PER_PAGE)
    start_idx = (current_page - 1) * TEMPLATES_PER_PAGE
    end_idx = start_idx + TEMPLATES_PER_PAGE
    current_templates = templates[start_idx:end_idx]
    
    # Create template buttons
    keyboard = []
    for template in current_templates:
        keyboard.append([
            InlineKeyboardButton(
                f"📧 {template['name']}", 
                callback_data=f"preview_{template['id']}"
            )
        ])
    
    # Add pagination buttons
    pagination_buttons = []
    
    if current_page > 1:
        pagination_buttons.append(
            InlineKeyboardButton("◀️ Previous", callback_data="prev_page")
        )
    
    if current_page < total_pages:
        pagination_buttons.append(
            InlineKeyboardButton("Next ▶️", callback_data="next_page")
        )
    
    if pagination_buttons:
        keyboard.append(pagination_buttons)
    
    # Add page indicator and navigation buttons
    if total_pages > 1:
        keyboard.append([
            InlineKeyboardButton(f"Page {current_page}/{total_pages}", callback_data="page_info")
        ])
    
    keyboard.append([
        InlineKeyboardButton("🔙 Back to Platforms", callback_data="back_to_platforms"),
        InlineKeyboardButton("🏠 Main Menu", callback_data="back_to_main")
    ])
    
    # Platform emoji
    platform_emojis = {
        'Coinbase': '🔵',
        'Binance': '🟡', 
        'Kraken': '🟣',
        'Ledger': '🟠',
        'Trezor': '🟢',
        'Google': '🔴'
    }
    emoji = platform_emojis.get(selected_platform, '📝')
    
    message_text = f"{emoji} *{selected_platform.upper()} TEMPLATES*\n\n" \
                  f"Select a template to preview ({len(templates)} available):"
    
    if query:
        await query.edit_message_text(
            message_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
    else:
        await update.message.reply_text(
            message_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
    
    return TEMPLATE_BROWSER

async def handle_template_browser(update, context):
    """Handle template browser actions"""
    query = update.callback_query
    await query.answer()
    
    action = query.data
    
    if action == "prev_page":
        context.user_data['template_page'] = max(1, context.user_data.get('template_page', 1) - 1)
        return await show_template_browser(update, context)
    
    elif action == "next_page":
        context.user_data['template_page'] = context.user_data.get('template_page', 1) + 1
        return await show_template_browser(update, context)
    
    elif action == "page_info":
        # Do nothing on page info click
        return TEMPLATE_BROWSER
    
    elif action.startswith("preview_"):
        template_id = action.replace("preview_", "")
        context.user_data['selected_template_id'] = template_id
        return await show_template_preview(update, context)
    
    elif action == "back_to_platforms":
        return await show_platform_selection(update, context)
    
    elif action == "back_to_main":
        return await show_main_menu(update, context)
    
    return TEMPLATE_BROWSER

async def show_template_preview(update, context):
    """Show template preview with options"""
    query = update.callback_query
    await query.answer()
    
    template_id = context.user_data.get('selected_template_id')
    template = get_template_by_id(template_id)
    
    if not template:
        await query.edit_message_text(
            "Error loading template. Please try again.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 Back to Templates", callback_data="back_to_templates")
            ]])
        )
        return TEMPLATE_BROWSER
    
    # Store template data in context
    context.user_data['template_name'] = template['name']
    context.user_data['template_subject'] = template['subject']
    context.user_data['content'] = template['content']
    
    # Convert HTML to plain text
    try:
        plain_text = html2text.html2text(template['content'])
        context.user_data['plain_text_content'] = plain_text
    except Exception:
        context.user_data['plain_text_content'] = "Plain text version not available."
    
    # Show template preview and options
    preview_text = (
        f"📝 *TEMPLATE PREVIEW*\n\n"
        f"*Name:* {template['name']}\n"
        f"*Subject:* {template['subject']}\n"
        f"*Description:* {template.get('description', 'No description available')}\n\n"
        f"This template includes placeholders for dynamic content such as email address, verification codes, dates, etc."
    )
    
    # Different buttons based on whether we're browsing or selecting for campaign
    if context.user_data.get('for_campaign'):
        keyboard = [
            [InlineKeyboardButton("✅ Use This Template", callback_data="use_this_template")],
            [InlineKeyboardButton("🔍 View HTML Code", callback_data="view_html")],
            [
                InlineKeyboardButton("🔙 Back to Templates", callback_data="back_to_templates"),
                InlineKeyboardButton("🏢 Back to Platforms", callback_data="back_to_platforms")
            ]
        ]
    else:
        keyboard = [
            [InlineKeyboardButton("🔍 View HTML Code", callback_data="view_html")],
            [InlineKeyboardButton("📧 Start Campaign with This", callback_data="use_this_template")],
            [
                InlineKeyboardButton("🔙 Back to Templates", callback_data="back_to_templates"),
                InlineKeyboardButton("🏢 Back to Platforms", callback_data="back_to_platforms")
            ]
        ]
    
    await query.edit_message_text(
        preview_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )
    
    return TEMPLATE_PREVIEW

async def handle_template_preview(update, context):
    """Handle template preview actions"""
    query = update.callback_query
    await query.answer()
    
    action = query.data
    
    if action == "use_this_template":
        # Show confirmation dialog before using template
        template_name = context.user_data.get('template_name', 'Unknown Template')
        template_subject = context.user_data.get('template_subject', 'No Subject')
        
        keyboard = [
            [
                InlineKeyboardButton("✅ Yes, Use This Template", callback_data="confirm_use_template"),
                InlineKeyboardButton("❌ No, Go Back", callback_data="back_to_preview")
            ]
        ]
        
        confirmation_text = (
            f"🔍 *TEMPLATE CONFIRMATION*\n\n"
            f"*Template:* {template_name}\n"
            f"*Subject:* {template_subject}\n\n"
            f"Are you sure you want to use this template for your email campaign?\n\n"
            f"This template includes dynamic placeholders that will be automatically filled with:\n"
            f"• Recipient email addresses\n"
            f"• Random verification codes\n"
            f"• Current dates\n"
            f"• Case IDs and employee names\n"
            f"• Other dynamic content"
        )
        
        await query.edit_message_text(
            confirmation_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
        return TEMPLATE_PREVIEW
    
    elif action == "confirm_use_template":
        # Mark that we're using a template and proceed
        context.user_data['using_template'] = True
        
        await query.edit_message_text("✅ Template confirmed! Please enter Email Sender Name:")
        return SENDER_NAME
    
    elif action == "view_html":
        # Get template content
        template_content = context.user_data.get('content', '')
        
        # Truncate if too long
        if len(template_content) > 500:
            html_preview = template_content[:500] + "...\n\n(HTML truncated for preview)"
        else:
            html_preview = template_content
        
        # Escape HTML for display
        html_preview = f"\`\`\`html\n{html_preview}\n\`\`\`"
        
        keyboard = [[InlineKeyboardButton("🔙 Back to Preview", callback_data="back_to_preview")]]
        
        await query.edit_message_text(
            f"*HTML CODE PREVIEW*\n\n{html_preview}",
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
        return TEMPLATE_PREVIEW
    
    elif action == "back_to_preview":
        return await show_template_preview(update, context)
    
    elif action == "back_to_templates":
        return await show_template_browser(update, context)
    
    elif action == "back_to_platforms":
        return await show_platform_selection(update, context)
    
    return TEMPLATE_PREVIEW

async def handle_activate_license(update, context):
    """Handle license key activation button click"""
    await update.callback_query.answer()
    await update.callback_query.message.reply_text(
        "🔑 **LICENSE KEY ACTIVATION**\n\n"
        "Please enter your license key to activate access to the bot:\n\n"
        "Format: Your license key should be exactly as provided to you.\n"
        "Example: ABC123-DEF456-GHI789\n\n"
        "Enter your license key below:",
        parse_mode=ParseMode.MARKDOWN
    )
    return LICENSE_KEY

async def validate_license(update, context):
    """Validate the license key entered by the user"""
    license_key = update.message.text.strip()
    user_id = update.message.from_user.id
    username = update.message.from_user.username or "Unknown"
    
    logger.info(f"User {user_id} (@{username}) attempting to validate license key: {license_key}")
    
    # Show "typing" status to indicate processing
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="typing")
    
    # Send processing message
    processing_msg = await update.message.reply_text("🔄 Validating your license key, please wait...")
    
    # Validate the license key
    is_valid = validate_license_key(license_key)
    
    if is_valid:
        # Add user to allowed list
        success = add_user_to_allowed_list(user_id)
        
        if success:
            keyboard = [[InlineKeyboardButton("🚀 Start Using Bot", callback_data="start_bot")]]
            
            await processing_msg.edit_text(
                "✅ **LICENSE KEY VALIDATED SUCCESSFULLY!**\n\n"
                "🎉 Congratulations! You are now authorized to use @CashMailerBot.\n\n"
                "Click the button below to start using the bot.",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode=ParseMode.MARKDOWN
            )
            
            # Log successful activation
            logger.info(f"SUCCESS: User {user_id} (@{username}) successfully activated with license key: {license_key}")
            
            # Notify admin about new activation
            try:
                await context.bot.send_message(
                    chat_id=ADMIN_ID,
                    text=f"🔑 **NEW LICENSE ACTIVATION**\n\n"
                         f"👤 User ID: `{user_id}`\n"
                         f"👤 Username: @{username}\n"
                         f"🔑 License Key: `{license_key}`\n"
                         f"⏰ Time: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Failed to notify admin: {str(e)}")
        else:
            await processing_msg.edit_text(
                "⚠️ **VALIDATION SUCCESSFUL BUT ERROR OCCURRED**\n\n"
                "Your license key is valid, but there was an error adding you to the authorized users list.\n\n"
                "Please contact the administrator or try again later.\n\n"
                "Contact: @acetary"
            )
            logger.error(f"Valid license key but failed to add user {user_id} to allowed list")
    else:
        await processing_msg.edit_text(
            "❌ **INVALID LICENSE KEY**\n\n"
            "The license key you entered is not valid or has been revoked.\n\n"
            "Please check your key and try again, or contact the administrator for assistance.\n\n"
            "Contact: @acetary"
        )
        logger.warning(f"FAILED: User {user_id} (@{username}) provided invalid license key: {license_key}")
    
    return ConversationHandler.END

async def handle_start_bot(update, context):
    """Handle start bot button after license activation"""
    query = update.callback_query
    await query.answer()
    
    # Show main menu
    return await show_main_menu(update, context)

async def handle_buy_subscription(update, context):
    """Handle subscription button click"""
    keyboard = [
        [InlineKeyboardButton("₢ 1,000", url="http://t.me/CashMailerBot/first")],
        [InlineKeyboardButton("₢ 5,000", url="http://t.me/CashMailerBot/second")],
        [InlineKeyboardButton("₢ 10,000", url="http://t.me/CashMailerBot/third")]
    ]
    await update.callback_query.answer()
    await update.callback_query.message.reply_text(
        "💳 **SUBSCRIPTION PLANS**\n\n"
        "*RATES:*\n*₢ 1 = 1 MAIL ADDRESS*\n\n"
        "Choose your preferred plan below:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )

async def get_sender_name(update, context):
    """Get sender name from user"""
    sender_name = update.message.text
    context.user_data['sender_name'] = sender_name
    
    # Create back button
    keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="cancel_campaign")]]
    
    await update.message.reply_text(
        "Please enter the sender email address:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return SENDER_EMAIL

async def get_sender_email(update, context):
    """Get sender email from user"""
    sender_email = update.message.text
    context.user_data['sender_email'] = sender_email
    
    # Create back button
    keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="cancel_campaign")]]
    
    # If using a template, suggest the template subject
    if context.user_data.get('using_template'):
        template_subject = context.user_data.get('template_subject', '')
        await update.message.reply_text(
            f"Suggested subject from template: \"{template_subject}\"\n\n"
            f"Please enter the subject of the email (or press Enter to use the suggested subject):",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    else:
        await update.message.reply_text(
            "Please enter the subject of the email:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    return SUBJECT

async def get_subject(update, context):
    """Get email subject from user"""
    subject = update.message.text
    
    # If empty and using template, use template subject
    if not subject.strip() and context.user_data.get('using_template'):
        subject = context.user_data.get('template_subject', 'Email Subject')
        await update.message.reply_text(f"Using template subject: \"{subject}\"")
    
    context.user_data['subject'] = subject
    
    # Create back button
    keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="cancel_campaign")]]
    
    # If using a template, skip to mailist upload
    if context.user_data.get('using_template'):
        await update.message.reply_text(
            "Please upload the mailist.txt file with recipient emails:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return MAILIST
    else:
        await update.message.reply_text(
            "Please upload the HTML file (file.html) for the main content:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return FILE_CONTENT

async def get_file_content(update, context):
    """Get HTML content file from user"""
    user_id = update.message.from_user.id

    try:  
        if not update.message.document:  
            await update.message.reply_text("Please upload an HTML file.")  
            return FILE_CONTENT  
              
        file = await update.message.document.get_file()  
        file_path = f"content_{user_id}.html"  
        await file.download_to_drive(file_path)  
          
        try:  
            with open(file_path, 'r', encoding='utf-8') as f:  
                content = f.read()  
                  
            context.user_data['content'] = content  
              
            # Use html2text with error handling  
            try:  
                plain_text = html2text.html2text(content)  
                context.user_data['plain_text_content'] = plain_text  
            except Exception:  
                context.user_data['plain_text_content'] = "Plain text version not available."  
            
            # Create back button
            keyboard = [[InlineKeyboardButton("🔙 Back to Main Menu", callback_data="cancel_campaign")]]
                  
            await update.message.reply_text(
                "Please upload the mailist.txt file with recipient emails:",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return MAILIST  
        except UnicodeDecodeError:  
            await update.message.reply_text("Error: The file contains invalid characters. Please ensure it's a proper HTML file with UTF-8 encoding.")  
            return FILE_CONTENT  
        except Exception as e:  
            await update.message.reply_text(f"Error reading file content: {str(e)}")  
            return FILE_CONTENT  
    except Exception as e:  
        await update.message.reply_text(f"Error processing your file: {str(e)}\nPlease make sure it's a valid HTML file and try again.")  
        return FILE_CONTENT

async def get_mailist(update, context):
    """Get recipient list file from user"""
    user_id = update.message.from_user.id

    try:  
        if not update.message.document:  
            await update.message.reply_text("Please upload a text file with email addresses.")  
            return MAILIST  
              
        file = await update.message.document.get_file()  
        file_path = f"mailist_{user_id}.txt"  
        await file.download_to_drive(file_path)  
          
        try:  
            with open(file_path, 'r', encoding='utf-8') as f:  
                mailist = [line.strip() for line in f if line.strip()]  
                  
            if not mailist:  
                await update.message.reply_text("The mailist file appears to be empty. Please upload a file with email addresses.")  
                return MAILIST  
                  
            context.user_data['mailist'] = mailist
            
            # Create delay selection keyboard
            keyboard = [
                [
                    InlineKeyboardButton("1s", callback_data="delay_1"),
                    InlineKeyboardButton("2s", callback_data="delay_2"),
                    InlineKeyboardButton("3s", callback_data="delay_3"),
                    InlineKeyboardButton("5s", callback_data="delay_5")
                ],
                [
                    InlineKeyboardButton("10s", callback_data="delay_10"),
                    InlineKeyboardButton("15s", callback_data="delay_15"),
                    InlineKeyboardButton("30s", callback_data="delay_30"),
                    InlineKeyboardButton("60s", callback_data="delay_60")
                ],
                [InlineKeyboardButton("Custom Delay", callback_data="delay_custom")],
                [InlineKeyboardButton("🔙 Back to Main Menu", callback_data="cancel_campaign")]
            ]
            
            await update.message.reply_text(
                f"{len(
            ]
            
await update.message.reply_text(
f"{len(mailist)} recipients found. Please select the delay between each email:",
reply_markup=InlineKeyboardMarkup(keyboard)
)
return DELAY
except UnicodeDecodeError:
await update.message.reply_text("Error: The file contains invalid characters. Please ensure it's a proper text file with UTF-8 encoding.")
return MAILIST
except Exception as e:
await update.message.reply_text(f"Error reading mailist: {str(e)}")
return MAILIST
except Exception as e:
await update.message.reply_text(f"Error processing your mailist file: {str(e)}\nPlease make sure it's a valid text file and try again.")
return MAILIST

async def handle_delay_selection(update, context):
"""Handle delay selection from keyboard"""
query = update.callback_query
await query.answer()

choice = query.data

if choice == "cancel_campaign":
await query.edit_message_text("Campaign setup cancelled. Use /start to begin again.")
return ConversationHandler.END

if choice == "delay_custom":
await query.edit_message_text("Please enter a custom delay in seconds (e.g., 7):")
return DELAY

# Extract delay value from callback data
delay = int(choice.split("_")[1])
context.user_data['delay'] = delay

# Show campaign summary and confirmation
template_info = ""
if context.user_data.get('using_template'):
template_name = context.user_data.get('template_name', 'Unknown')
template_info = f"Template: {template_name}\n"

summary = (
f"📧 *SEND SUMMARY*\n\n"
f"Sender Name: {context.user_data['sender_name']}\n"
f"Sender Email: {context.user_data['sender_email']}\n"
f"Subject: {context.user_data['subject']}\n"
f"{template_info}"
f"Recipients: {len(context.user_data['mailist'])}\n"
f"Delay: {delay} seconds\n\n"
f"Are you ready to start sending?"
)

keyboard = [
[InlineKeyboardButton("✅ Start Sending", callback_data="start_sending")],
[InlineKeyboardButton("❌ Cancel", callback_data="cancel_campaign")]
]

await query.edit_message_text(
summary,
reply_markup=InlineKeyboardMarkup(keyboard),
parse_mode=ParseMode.MARKDOWN
)
return DELAY

async def get_delay(update, context):
"""Get custom delay between emails"""
try:
delay_text = update.message.text

try:
delay = int(delay_text)
except ValueError:
await update.message.reply_text("Invalid input. Please enter a number for the delay.")
return DELAY

if delay < 0:
await update.message.reply_text("Delay cannot be negative. Please enter a positive number.")
return DELAY

context.user_data['delay'] = delay

# Show campaign summary and confirmation
template_info = ""
if context.user_data.get('using_template'):
template_name = context.user_data.get('template_name', 'Unknown')
template_info = f"Template: {template_name}\n"

summary = (
f"📧 *SENDING SUMMARY*\n\n"
f"Sender Name: {context.user_data['sender_name']}\n"
f"Sender Email: {context.user_data['sender_email']}\n"
f"Subject: {context.user_data['subject']}\n"
f"{template_info}"
f"Recipients: {len(context.user_data['mailist'])}\n"
f"Delay: {delay} seconds\n\n"
f"Are you ready to start sending?"
)

keyboard = [
[InlineKeyboardButton("✅ Start Sending", callback_data="start_sending")],
[InlineKeyboardButton("❌ Cancel", callback_data="cancel_campaign")]
]

await update.message.reply_text(
summary,
reply_markup=InlineKeyboardMarkup(keyboard),
parse_mode=ParseMode.MARKDOWN
)
return DELAY
except Exception as e:
await update.message.reply_text(f"An error occurred: {str(e)}\nPlease try again.")
return DELAY

async def start_sending(update, context):
"""Start sending emails after confirmation"""
query = update.callback_query
await query.answer()

# Send a status message first
status_message = await query.edit_message_text("Starting to send emails with the specified delay! I'll update you on progress...")

# Process the email campaign
result = await process_email_campaign(context, update, status_message)

if result:
# Final status update with return to main menu button
keyboard = [[InlineKeyboardButton("🔙 Return to Main Menu", callback_data="back_to_main")]]

await query.message.reply_text(
f"📧 *SENDING COMPLETED*\n\n"
f"✅ Successfully sent: {result['successful']}\n"
f"❌ Failed: {result['failed']}\n"
f"⏱️ Total time: {result['total_time']}",
reply_markup=InlineKeyboardMarkup(keyboard),
parse_mode=ParseMode.MARKDOWN
)
return MAIN_MENU
else:
keyboard = [[InlineKeyboardButton("🔙 Return to Main Menu", callback_data="back_to_main")]]

await query.message.reply_text(
"❌ Campaign failed to start. Please check your settings and try again.",
reply_markup=InlineKeyboardMarkup(keyboard)
)
return MAIN_MENU

async def cancel(update, context):
"""Cancel the conversation"""
keyboard = [[InlineKeyboardButton("🔙 Return to Main Menu", callback_data="back_to_main")]]

await update.message.reply_text(
"Operation cancelled.",
reply_markup=InlineKeyboardMarkup(keyboard)
)
return MAIN_MENU

async def cancel_campaign(update, context):
"""Cancel campaign setup from inline button"""
query = update.callback_query
await query.answer()

await query.edit_message_text("Campaign setup cancelled. Returning to main menu...")
return await show_main_menu(update, context)
