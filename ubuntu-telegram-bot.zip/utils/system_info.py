"""System information utilities for Linux"""
import os
import subprocess
import platform
import psutil
from datetime import datetime

def get_system_info():
    """Get basic system information"""
    try:
        info = {
            "System": platform.system(),
            "Host name": platform.node(),
            "OS version": platform.release(),
            "Architecture": platform.architecture()[0],
            "Processor": platform.processor(),
            "CPU cores": psutil.cpu_count(),
            "RAM": f"{psutil.virtual_memory().total // (1024**3)} GB",
            "Boot time": datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")
        }
        return info
    except Exception as e:
        return {"Error": str(e)}

def get_network_info():
    """Get network information using curl"""
    info = {}
    commands = {
        "IP": "curl -s ipinfo.io/ip",
        "City": "curl -s ipinfo.io/city", 
        "Region": "curl -s ipinfo.io/region",
        "Country": "curl -s ipinfo.io/country",
        "Location": "curl -s ipinfo.io/loc",
        "Provider": "curl -s ipinfo.io/org",
        "Timezone": "curl -s ipinfo.io/timezone"
    }
    
    for key, cmd in commands.items():
        try:
            result = subprocess.run(cmd.split(), capture_output=True, text=True, timeout=10)
            info[key] = result.stdout.strip() if result.returncode == 0 else "N/A"
        except Exception:
            info[key] = "N/A"
    
    return info

def get_running_processes():
    """Get list of running processes"""
    try:
        processes = []
        for proc in psutil.process_iter(['pid', 'name', 'username']):
            try:
                processes.append(f"{proc.info['pid']:<8} {proc.info['name']:<20} {proc.info['username']}")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return processes
    except Exception as e:
        return [f"Error: {e}"]
