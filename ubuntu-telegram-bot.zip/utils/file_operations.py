"""File operation utilities"""
import os
import shutil
import subprocess
from pathlib import Path

def execute_command(command, timeout=30):
    """Execute shell command safely"""
    try:
        result = subprocess.run(
            command, 
            shell=True, 
            capture_output=True, 
            text=True, 
            timeout=timeout
        )
        return result.stdout + result.stderr if result.stderr else result.stdout
    except subprocess.TimeoutExpired:
        return "Command timed out"
    except Exception as e:
        return f"Error: {e}"

def get_file_metadata(filepath):
    """Get file metadata"""
    try:
        if not os.path.exists(filepath):
            return "File does not exist"
        
        stat = os.stat(filepath)
        size_mb = stat.st_size / (1024 * 1024)
        
        metadata = f"""File: {filepath}
Size: {size_mb:.2f} MB
Modified: {os.path.getctime(filepath)}
Accessed: {os.path.getatime(filepath)}
Permissions: {oct(stat.st_mode)[-3:]}"""
        
        return metadata
    except Exception as e:
        return f"Error: {e}"

def safe_file_operation(operation, *args):
    """Safely perform file operations"""
    try:
        if operation == "copy":
            shutil.copy2(args[0], args[1])
            return f"Copied {args[0]} to {args[1]}"
        elif operation == "move":
            shutil.move(args[0], args[1])
            return f"Moved {args[0]} to {args[1]}"
        elif operation == "delete":
            os.remove(args[0])
            return f"Deleted {args[0]}"
        else:
            return "Unknown operation"
    except Exception as e:
        return f"Error: {e}"
