"""Configuration settings for the Telegram bot"""
import os
from dataclasses import dataclass

@dataclass
class BotConfig:
    """Bot configuration class"""
    API_TOKEN: str = 'YOUR_API_TOKEN'  # Replace with your actual token
    PASSWORD: str = 'acd'
    MAX_MESSAGE_LENGTH: int = 4096
    TEMP_DIR: str = '/tmp/bot_files'
    
    def __post_init__(self):
        """Create temp directory if it doesn't exist"""
        os.makedirs(self.TEMP_DIR, exist_ok=True)

# Global config instance
config = BotConfig()
