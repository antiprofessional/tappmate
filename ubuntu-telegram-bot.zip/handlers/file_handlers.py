"""File operation handlers"""
import os
import tempfile
from utils.file_operations import execute_command, get_file_metadata, safe_file_operation
from config import config

def handle_download(bot, message):
    """Handle file download"""
    try:
        filepath = message.text.split('/download', 1)[1].strip()
        
        if not os.path.exists(filepath):
            bot.send_message(message.chat.id, "File does not exist")
            return
        
        with open(filepath, 'rb') as file:
            # Determine file type and send accordingly
            if filepath.lower().endswith(('.png', '.jpg', '.jpeg', '.gif')):
                bot.send_photo(message.chat.id, file)
            elif filepath.lower().endswith(('.mp4', '.avi', '.mkv')):
                bot.send_video(message.chat.id, file, timeout=100)
            else:
                bot.send_document(message.chat.id, file)
                
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

def handle_upload(bot, message):
    """Handle file upload"""
    bot.send_message(message.chat.id, "Please send your file:")
    return True  # Indicate waiting for file

def handle_file_upload(bot, message):
    """Process uploaded file"""
    try:
        if message.document:
            file_info = bot.get_file(message.document.file_id)
            file_name = message.document.file_name
        elif message.photo:
            file_info = bot.get_file(message.photo[-1].file_id)
            file_name = f"photo_{message.photo[-1].file_id}.jpg"
        else:
            bot.send_message(message.chat.id, "Unsupported file type")
            return
        
        downloaded_file = bot.download_file(file_info.file_path)
        
        # Save to current directory
        with open(file_name, 'wb') as new_file:
            new_file.write(downloaded_file)
        
        current_dir = os.getcwd()
        bot.send_message(message.chat.id, f'File saved successfully in: {current_dir}/{file_name}')
        
    except Exception as e:
        bot.send_message(message.chat.id, f'Error: {e}')

def handle_metadata(bot, message):
    """Handle metadata request"""
    try:
        filepath = message.text.split('/metadata', 1)[1].strip()
        metadata = get_file_metadata(filepath)
        bot.send_message(message.chat.id, metadata)
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

def handle_run_file(bot, message):
    """Handle file execution"""
    try:
        filepath = message.text.split('/run', 1)[1].strip()
        
        if not os.path.exists(filepath):
            bot.send_message(message.chat.id, "File does not exist")
            return
        
        # Make file executable if it's a script
        if filepath.endswith(('.sh', '.py', '.pl')):
            os.chmod(filepath, 0o755)
        
        result = execute_command(f"nohup {filepath} &")
        bot.send_message(message.chat.id, f"File executed: {result}")
        
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")
