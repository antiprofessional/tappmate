"""System-related command handlers"""
import os
import subprocess
import psutil
from utils.system_info import get_system_info, get_network_info, get_running_processes
from utils.file_operations import execute_command

def handle_system_info(bot, message):
    """Handle system info command"""
    try:
        info = get_system_info()
        info_text = "\n".join([f"{key}: {value}" for key, value in info.items()])
        bot.send_message(message.chat.id, f"System Information:\n{info_text}")
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

def handle_network_info(bot, message):
    """Handle network info command"""
    try:
        info = get_network_info()
        for key, value in info.items():
            bot.send_message(message.chat.id, f"{key}: {value}")
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

def handle_processes(bot, message):
    """Handle process list command"""
    try:
        processes = get_running_processes()
        
        # Split into chunks if too long
        chunk_size = 50
        chunks = [processes[i:i + chunk_size] for i in range(0, len(processes), chunk_size)]
        
        for chunk in chunks:
            process_text = "\n".join(chunk)
            bot.send_message(message.chat.id, f"Running Processes:\n```\n{process_text}\n```", parse_mode='Markdown')
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

def handle_kill_process(bot, message):
    """Handle process termination"""
    try:
        parts = message.text.split()
        if len(parts) < 2:
            bot.send_message(message.chat.id, "Usage: /killprocess <process_name_or_pid>")
            return
        
        target = parts[1]
        
        # Try to kill by PID first, then by name
        if target.isdigit():
            result = execute_command(f"kill -9 {target}")
        else:
            result = execute_command(f"pkill -f {target}")
        
        bot.send_message(message.chat.id, f"Kill result: {result}")
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

def handle_system_command(bot, message):
    """Handle system shutdown/restart"""
    command_type = message.text.split('/')[1]
    
    try:
        if command_type == 'shutdown':
            execute_command("sudo shutdown -h now")
            bot.send_message(message.chat.id, "System shutting down...")
        elif command_type == 'restart':
            execute_command("sudo reboot")
            bot.send_message(message.chat.id, "System restarting...")
        elif command_type == 'suspend':
            execute_command("sudo systemctl suspend")
            bot.send_message(message.chat.id, "System suspended...")
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")
