#!/usr/bin/env python3
"""
Ubuntu VPS Telegram Bot
A modular Telegram bot for remote system administration on Ubuntu
"""

import telebot
import os
from config import config
from handlers.system_handlers import (
    handle_system_info, handle_network_info, handle_processes, 
    handle_kill_process, handle_system_command
)
from handlers.file_handlers import (
    handle_download, handle_upload, handle_file_upload, 
    handle_metadata, handle_run_file
)
from handlers.media_handlers import (
    handle_screenshot, handle_audio_recording, handle_webcam_photo
)
from handlers.command_handlers import (
    handle_execute_command, handle_interactive_shell, handle_shell_input, shell_sessions
)

# Initialize bot
try:
    bot = telebot.TeleBot(config.API_TOKEN)
    print("Bot initialized successfully")
except Exception as e:
    print(f"Failed to initialize bot: {e}")
    exit(1)

# Authentication state
authenticated_users = set()
waiting_for_upload = {}

# Help text
HELP_TEXT = """
🤖 **Ubuntu VPS Remote Control Bot**

## **🛠️ System Commands**
- `/start` - Start and authenticate
- `/help` - Show this help
- `/sysinfo` - Show system information  
- `/netinfo` - Show network information
- `/processes` - List running processes
- `/killprocess <name/pid>` - Kill a process
- `/shutdown` - Shutdown system
- `/restart` - Restart system
- `/suspend` - Suspend system

## **📁 File Operations**
- `/download <filepath>` - Download a file
- `/upload` - Upload a file
- `/metadata <filepath>` - Show file metadata
- `/run <filepath>` - Execute a file

## **📷 Media Capture**
- `/screenshot` - Take a screenshot
- `/mic [seconds]` - Record audio (default 5s)
- `/webcam` - Take webcam photo

## **⚙️ Command Execution**
- `/e <command>` - Execute single command
- `/shell` - Start interactive shell session

## **Examples:**
- `/e ls -la` - List files
- `/e whoami` - Show current user
- `/killprocess firefox` - Kill Firefox
- `/mic 10` - Record 10 seconds of audio

**Note:** Some commands may require sudo privileges.
"""

def check_auth(func):
    """Decorator to check authentication"""
    def wrapper(message):
        if message.from_user.id not in authenticated_users:
            bot.send_message(message.chat.id, "Please authenticate first with /start")
            return
        return func(message)
    return wrapper

@bot.message_handler(commands=['start'])
def start_command(message):
    """Handle start command with authentication"""
    user_id = message.from_user.id
    
    if user_id in authenticated_users:
        bot.send_message(message.chat.id, "You are already authenticated!")
        return
    
    bot.send_message(message.chat.id, "Enter password:")
    bot.register_next_step_handler(message, check_password)

def check_password(message):
    """Check password for authentication"""
    if message.text == config.PASSWORD:
        authenticated_users.add(message.from_user.id)
        bot.send_message(message.chat.id, "✅ Authentication successful!")
        
        user_name = message.from_user.first_name
        if message.from_user.last_name:
            user_name += f" {message.from_user.last_name}"
        
        bot.send_message(message.chat.id, f"Welcome {user_name}!")
        bot.send_message(message.chat.id, "Use /help to see available commands")
        
        # Show basic system info
        hostname = os.popen('hostname').read().strip()
        bot.send_message(message.chat.id, f"Connected to: {hostname}")
    else:
        bot.send_message(message.chat.id, "❌ Wrong password!")

@bot.message_handler(commands=['help'])
@check_auth
def help_command(message):
    """Show help information"""
    bot.send_message(message.chat.id, HELP_TEXT, parse_mode='Markdown')

# System commands
@bot.message_handler(commands=['sysinfo'])
@check_auth
def system_info_command(message):
    handle_system_info(bot, message)

@bot.message_handler(commands=['netinfo'])
@check_auth
def network_info_command(message):
    handle_network_info(bot, message)

@bot.message_handler(commands=['processes'])
@check_auth
def processes_command(message):
    handle_processes(bot, message)

@bot.message_handler(commands=['killprocess'])
@check_auth
def kill_process_command(message):
    handle_kill_process(bot, message)

@bot.message_handler(commands=['shutdown', 'restart', 'suspend'])
@check_auth
def system_command(message):
    handle_system_command(bot, message)

# File operations
@bot.message_handler(commands=['download'])
@check_auth
def download_command(message):
    handle_download(bot, message)

@bot.message_handler(commands=['upload'])
@check_auth
def upload_command(message):
    waiting_for_upload[message.from_user.id] = True
    handle_upload(bot, message)

@bot.message_handler(commands=['metadata'])
@check_auth
def metadata_command(message):
    handle_metadata(bot, message)

@bot.message_handler(commands=['run'])
@check_auth
def run_command(message):
    handle_run_file(bot, message)

# Media commands
@bot.message_handler(commands=['screenshot'])
@check_auth
def screenshot_command(message):
    handle_screenshot(bot, message)

@bot.message_handler(commands=['mic'])
@check_auth
def mic_command(message):
    handle_audio_recording(bot, message)

@bot.message_handler(commands=['webcam'])
@check_auth
def webcam_command(message):
    handle_webcam_photo(bot, message)

# Command execution
@bot.message_handler(commands=['e'])
@check_auth
def execute_command(message):
    handle_execute_command(bot, message)

@bot.message_handler(commands=['shell'])
@check_auth
def shell_command(message):
    handle_interactive_shell(bot, message)

# Handle file uploads
@bot.message_handler(content_types=['document', 'photo', 'audio', 'video'])
def file_handler(message):
    user_id = message.from_user.id
    if user_id in waiting_for_upload:
        waiting_for_upload.pop(user_id)
        handle_file_upload(bot, message)
    else:
        bot.send_message(message.chat.id, "Use /upload command first")

# Handle shell input
@bot.message_handler(func=lambda message: message.from_user.id in shell_sessions)
def shell_input_handler(message):
    if not handle_shell_input(bot, message):
        # Shell session ended, remove from sessions
        shell_sessions.pop(message.from_user.id, None)

if __name__ == "__main__":
    print("Starting Ubuntu VPS Telegram Bot...")
    print("Make sure to:")
    print("1. Replace 'YOUR_API_TOKEN' in config.py with your actual bot token")
    print("2. Install required packages: pip install pyTelegramBotAPI psutil")
    print("3. Install system tools: sudo apt install scrot alsa-utils fswebcam")
    print("\nBot is running...")
    
    try:
        bot.polling(none_stop=True)
    except KeyboardInterrupt:
        print("\nBot stopped by user")
    except Exception as e:
        print(f"Bot error: {e}")
