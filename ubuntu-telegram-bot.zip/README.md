# Ubuntu VPS Telegram Bot

A modular Telegram bot for remote system administration on Ubuntu VPS servers.

## Features

### System Management
- System information (CPU, RAM, disk, uptime)
- Network information (IP, location, ISP)
- Process management (list, kill processes)
- System control (shutdown, restart, suspend)

### File Operations
- Upload/download files
- Execute scripts and programs
- View file metadata
- File management

### Media Capture
- Screenshots (using scrot/gnome-screenshot)
- Audio recording (using alsa-utils)
- Webcam photos (using fswebcam)

### Command Execution
- Single command execution
- Interactive shell sessions
- Directory navigation

## Installation

1. **Clone and setup:**
   \`\`\`bash
   git clone <repository>
   cd ubuntu-telegram-bot
   chmod +x install.sh
   ./install.sh
   \`\`\`

2. **Configure:**
   - Edit `config.py` and replace `YOUR_API_TOKEN` with your actual Telegram bot token
   - Optionally change the password (default: 'acd')

3. **Run:**
   \`\`\`bash
   # Test run
   python3 main.py
   
   # Or as system service
   sudo systemctl enable telegram-bot
   sudo systemctl start telegram-bot
   \`\`\`

## Usage

1. Start a chat with your bot
2. Send `/start` and enter the password
3. Use `/help` to see all available commands

## Security Notes

- Change the default password in `config.py`
- Consider using environment variables for sensitive data
- The bot requires sudo privileges for system commands
- Be cautious with file operations and command execution

## Dependencies

### Python packages:
- `pyTelegramBotAPI` - Telegram bot API
- `psutil` - System information

### System tools:
- `scrot` - Screenshots
- `alsa-utils` - Audio recording
- `fswebcam` - Webcam capture
- `imagemagick` - Image processing

## File Structure

\`\`\`
├── main.py              # Main bot file
├── config.py            # Configuration
├── handlers/            # Command handlers
│   ├── system_handlers.py
│   ├── file_handlers.py
│   ├── media_handlers.py
│   └── command_handlers.py
├── utils/               # Utility modules
│   ├── system_info.py
│   ├── file_operations.py
│   └── media_capture.py
├── install.sh           # Installation script
└── requirements.txt     # Python dependencies
\`\`\`

## Commands

- `/start` - Authenticate
- `/help` - Show help
- `/sysinfo` - System information
- `/netinfo` - Network information
- `/processes` - List processes
- `/killprocess <name>` - Kill process
- `/screenshot` - Take screenshot
- `/mic [seconds]` - Record audio
- `/webcam` - Webcam photo
- `/e <command>` - Execute command
- `/shell` - Interactive shell
- `/upload` - Upload file
- `/download <path>` - Download file

## License

Educational use only. Use responsibly and in compliance with local laws.
