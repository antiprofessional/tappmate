#!/bin/bash
# Installation script for Ubuntu VPS Telegram Bot

echo "Installing Ubuntu VPS Telegram Bot..."

# Update system
sudo apt update

# Install Python dependencies
pip3 install pyTelegramBotAPI psutil

# Install system tools
sudo apt install -y scrot alsa-utils fswebcam imagemagick

# Create systemd service file
sudo tee /etc/systemd/system/telegram-bot.service > /dev/null <<EOF
[Unit]
Description=Ubuntu VPS Telegram Bot
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$(pwd)
ExecStart=/usr/bin/python3 $(pwd)/main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Make main.py executable
chmod +x main.py

echo "Installation complete!"
echo ""
echo "Next steps:"
echo "1. Edit config.py and add your Telegram bot token"
echo "2. Run: python3 main.py (for testing)"
echo "3. Or enable as service: sudo systemctl enable telegram-bot && sudo systemctl start telegram-bot"
echo ""
echo "Required packages installed:"
echo "- scrot (screenshots)"
echo "- alsa-utils (audio recording)"  
echo "- fswebcam (webcam photos)"
echo "- imagemagick (image processing)"
