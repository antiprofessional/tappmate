import logging
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
import json
import os

# Enable logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Replace this with your actual token
TOKEN = "7552114625:AAHZtdYvsqoUqDyDGwf5_v3yh898PqRsuR8"

# Replace with your admin user ID
ADMIN_USER_ID = 123456789  # Replace with your actual Telegram user ID

# File to store user data
USERS_FILE = "bot_users.json"

# In-memory user tracking
seen_users = {}
bot_users = {}

def load_users():
    """Load users from file"""
    global bot_users
    try:
        if os.path.exists(USERS_FILE):
            with open(USERS_FILE, 'r') as f:
                bot_users = json.load(f)
    except Exception as e:
        logger.error(f"Error loading users: {e}")
        bot_users = {}

def save_users():
    """Save users to file"""
    try:
        with open(USERS_FILE, 'w') as f:
            json.dump(bot_users, f, indent=2)
    except Exception as e:
        logger.error(f"Error saving users: {e}")

def add_user(user_id, user_data):
    """Add user to database"""
    bot_users[str(user_id)] = user_data
    save_users()

def remove_user(user_id):
    """Remove user from database"""
    if str(user_id) in bot_users:
        del bot_users[str(user_id)]
        save_users()
        return True
    return False

def is_admin(user_id):
    """Check if user is admin"""
    return user_id == ADMIN_USER_ID

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    
    # Add user to bot users database
    user_data = {
        'user_id': user.id,
        'username': user.username,
        'first_name': user.first_name,
        'last_name': user.last_name,
        'joined_date': datetime.now().isoformat(),
        'is_active': True
    }
    add_user(user.id, user_data)
    
    await update.message.reply_text(
        "👤 Send me a forwarded message from any user.\n"
        "I'll return their UID, username, full name, profile picture and a permanent link to their profile.\n\n"
        "⚠️ Note: Due to Telegram's privacy settings, some user information may be hidden."
    )

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ You are not authorized to access the admin panel.")
        return
    
    # Admin greeting
    admin_name = update.effective_user.first_name or "Admin"
    greeting = f"👋 Welcome to Admin Panel, {admin_name}!\n\n"
    greeting += f"📊 Total Bot Users: {len(bot_users)}\n"
    greeting += f"🕐 Current Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    # Admin keyboard
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("👥 List Users", callback_data="admin_list_users")],
        [InlineKeyboardButton("➕ Add User", callback_data="admin_add_user"),
         InlineKeyboardButton("🗑️ Delete User", callback_data="admin_delete_user")],
        [InlineKeyboardButton("📢 Broadcast Message", callback_data="admin_broadcast")],
        [InlineKeyboardButton("📈 Statistics", callback_data="admin_stats")]
    ])
    
    await update.message.reply_text(greeting, reply_markup=keyboard)

async def admin_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    
    if not is_admin(user_id):
        await query.answer("❌ Unauthorized access!", show_alert=True)
        return
    
    await query.answer()
    
    if query.data == "admin_list_users":
        await list_users(query, context)
    elif query.data == "admin_add_user":
        await add_user_prompt(query, context)
    elif query.data == "admin_delete_user":
        await delete_user_prompt(query, context)
    elif query.data == "admin_broadcast":
        await broadcast_prompt(query, context)
    elif query.data == "admin_stats":
        await show_stats(query, context)
    elif query.data.startswith("delete_user_"):
        user_id_to_delete = int(query.data.split("_")[-1])
        await confirm_delete_user(query, context, user_id_to_delete)
    elif query.data.startswith("confirm_delete_"):
        user_id_to_delete = int(query.data.split("_")[-1])
        await execute_delete_user(query, context, user_id_to_delete)

async def list_users(query, context):
    """List all bot users"""
    if not bot_users:
        await query.edit_message_text("📭 No users found in the database.")
        return
    
    message = "👥 <b>Bot Users List:</b>\n\n"
    
    for i, (user_id, user_data) in enumerate(bot_users.items(), 1):
        username = f"@{user_data.get('username', 'N/A')}" if user_data.get('username') else "No username"
        first_name = user_data.get('first_name', 'N/A')
        last_name = user_data.get('last_name', '')
        full_name = f"{first_name} {last_name}".strip()
        joined_date = user_data.get('joined_date', 'Unknown')[:10]  # Just date part
        
        message += f"{i}. <b>{full_name}</b>\n"
        message += f"   🆔 ID: <code>{user_id}</code>\n"
        message += f"   👤 Username: {username}\n"
        message += f"   📅 Joined: {joined_date}\n\n"
        
        # Telegram message limit is 4096 characters
        if len(message) > 3500:
            message += f"... and {len(bot_users) - i} more users"
            break
    
    # Back button
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="back_to_admin")]
    ])
    
    await query.edit_message_text(message, parse_mode='HTML', reply_markup=keyboard)

async def add_user_prompt(query, context):
    """Prompt admin to add user"""
    message = "➕ <b>Add User</b>\n\n"
    message += "To add a user, please send me their User ID in the following format:\n"
    message += "<code>/adduser 123456789</code>\n\n"
    message += "Note: The user must have interacted with the bot at least once for this to work properly."
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="back_to_admin")]
    ])
    
    await query.edit_message_text(message, parse_mode='HTML', reply_markup=keyboard)

async def delete_user_prompt(query, context):
    """Show users for deletion"""
    if not bot_users:
        await query.edit_message_text("📭 No users found to delete.")
        return
    
    message = "🗑️ <b>Delete User</b>\n\n"
    message += "Select a user to delete:\n\n"
    
    keyboard_buttons = []
    for user_id, user_data in list(bot_users.items())[:10]:  # Show first 10 users
        username = user_data.get('username', 'N/A')
        first_name = user_data.get('first_name', 'Unknown')
        display_name = f"{first_name} (@{username})" if username != 'N/A' else first_name
        
        keyboard_buttons.append([
            InlineKeyboardButton(f"🗑️ {display_name}", callback_data=f"delete_user_{user_id}")
        ])
    
    keyboard_buttons.append([
        InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="back_to_admin")
    ])
    
    keyboard = InlineKeyboardMarkup(keyboard_buttons)
    await query.edit_message_text(message, parse_mode='HTML', reply_markup=keyboard)

async def confirm_delete_user(query, context, user_id_to_delete):
    """Confirm user deletion"""
    user_data = bot_users.get(str(user_id_to_delete))
    if not user_data:
        await query.edit_message_text("❌ User not found!")
        return
    
    username = user_data.get('username', 'N/A')
    first_name = user_data.get('first_name', 'Unknown')
    
    message = f"⚠️ <b>Confirm Deletion</b>\n\n"
    message += f"Are you sure you want to delete this user?\n\n"
    message += f"👤 <b>Name:</b> {first_name}\n"
    message += f"🆔 <b>ID:</b> <code>{user_id_to_delete}</code>\n"
    message += f"👤 <b>Username:</b> @{username}\n\n"
    message += "This action cannot be undone!"
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Yes, Delete", callback_data=f"confirm_delete_{user_id_to_delete}"),
         InlineKeyboardButton("❌ Cancel", callback_data="admin_delete_user")]
    ])
    
    await query.edit_message_text(message, parse_mode='HTML', reply_markup=keyboard)

async def execute_delete_user(query, context, user_id_to_delete):
    """Execute user deletion"""
    if remove_user(user_id_to_delete):
        await query.edit_message_text(f"✅ User {user_id_to_delete} has been deleted successfully!")
    else:
        await query.edit_message_text(f"❌ Failed to delete user {user_id_to_delete}. User not found.")

async def broadcast_prompt(query, context):
    """Prompt for broadcast message"""
    message = "📢 <b>Broadcast Message</b>\n\n"
    message += "To send a broadcast message to all users, use the following format:\n"
    message += "<code>/broadcast Your message here</code>\n\n"
    message += "The message will be sent to all active bot users."
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="back_to_admin")]
    ])
    
    await query.edit_message_text(message, parse_mode='HTML', reply_markup=keyboard)

async def show_stats(query, context):
    """Show bot statistics"""
    total_users = len(bot_users)
    active_users = sum(1 for user in bot_users.values() if user.get('is_active', True))
    
    # Calculate users joined today
    today = datetime.now().date()
    users_today = sum(1 for user in bot_users.values() 
                     if datetime.fromisoformat(user.get('joined_date', '2000-01-01')).date() == today)
    
    message = "📈 <b>Bot Statistics</b>\n\n"
    message += f"👥 Total Users: {total_users}\n"
    message += f"✅ Active Users: {active_users}\n"
    message += f"📅 New Users Today: {users_today}\n"
    message += f"🕐 Last Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 Refresh", callback_data="admin_stats")],
        [InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="back_to_admin")]
    ])
    
    await query.edit_message_text(message, parse_mode='HTML', reply_markup=keyboard)

async def handle_adduser_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /adduser command"""
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ You are not authorized to use this command.")
        return
    
    if not context.args:
        await update.message.reply_text("❌ Please provide a user ID. Usage: /adduser 123456789")
        return
    
    try:
        target_user_id = int(context.args[0])
        
        # Try to get user info
        try:
            user_info = await context.bot.get_chat(target_user_id)
            user_data = {
                'user_id': target_user_id,
                'username': user_info.username,
                'first_name': user_info.first_name,
                'last_name': user_info.last_name,
                'joined_date': datetime.now().isoformat(),
                'is_active': True,
                'added_by_admin': True
            }
            add_user(target_user_id, user_data)
            await update.message.reply_text(f"✅ User {target_user_id} has been added successfully!")
        except Exception as e:
            await update.message.reply_text(f"❌ Error adding user: {str(e)}")
            
    except ValueError:
        await update.message.reply_text("❌ Invalid user ID. Please provide a valid number.")

async def handle_broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /broadcast command"""
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text("❌ You are not authorized to use this command.")
        return
    
    if not context.args:
        await update.message.reply_text("❌ Please provide a message to broadcast. Usage: /broadcast Your message here")
        return
    
    broadcast_message = " ".join(context.args)
    
    # Send broadcast message to all users
    success_count = 0
    failed_count = 0
    
    status_message = await update.message.reply_text("📢 Starting broadcast...")
    
    for user_id_str, user_data in bot_users.items():
        try:
            await context.bot.send_message(
                chat_id=int(user_id_str),
                text=f"📢 <b>Broadcast Message:</b>\n\n{broadcast_message}",
                parse_mode='HTML'
            )
            success_count += 1
        except Exception as e:
            logger.warning(f"Failed to send broadcast to {user_id_str}: {e}")
            failed_count += 1
    
    result_message = f"📢 <b>Broadcast Complete!</b>\n\n"
    result_message += f"✅ Successfully sent: {success_count}\n"
    result_message += f"❌ Failed to send: {failed_count}\n"
    result_message += f"📊 Total users: {len(bot_users)}"
    
    await status_message.edit_text(result_message, parse_mode='HTML')

async def handle_back_to_admin(query, context):
    """Handle back to admin panel"""
    admin_name = query.from_user.first_name or "Admin"
    greeting = f"👋 Welcome to Admin Panel, {admin_name}!\n\n"
    greeting += f"📊 Total Bot Users: {len(bot_users)}\n"
    greeting += f"🕐 Current Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("👥 List Users", callback_data="admin_list_users")],
        [InlineKeyboardButton("➕ Add User", callback_data="admin_add_user"),
         InlineKeyboardButton("🗑️ Delete User", callback_data="admin_delete_user")],
        [InlineKeyboardButton("📢 Broadcast Message", callback_data="admin_broadcast")],
        [InlineKeyboardButton("📈 Statistics", callback_data="admin_stats")]
    ])
    
    await query.edit_message_text(greeting, reply_markup=keyboard)

async def handle_forward(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.effective_message
    
    # Check if message is actually forwarded
    if not message.forward_origin:
        return await message.reply_text("⚠️ Please forward a message directly from a user.")
    
    forward_origin = message.forward_origin
    
    # Handle different types of forward origins
    if forward_origin.type == "user":
        # Message forwarded from a user
        user = forward_origin.sender_user
        uid = user.id
        full_name = f"{user.first_name or ''} {user.last_name or ''}".strip()
        username = f"@{user.username}" if user.username else "None"
        
        # First-seen timestamp
        if uid not in seen_users:
            seen_users[uid] = datetime.now()
        created_at = seen_users[uid].strftime("%Y-%m-%d %H:%M:%S")
        
        # Message caption
        caption = (
            f"💳 <b>Full Name:</b> {full_name}\n"
            f"🪪 <b>UID:</b> <code>{uid}</code>\n"
            f"🫆 <b>Username:</b> {username}\n"
            f"🗓️ <b>First Seen:</b> <code>{created_at}</code>"
        )
        
        # Permanent link to profile
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔗 View Profile", url=f"tg://openmessage?user_id={uid}")]
        ])
        
        # Try to fetch profile photo
        try:
            photos = await context.bot.get_user_profile_photos(uid, limit=1)
            if photos.total_count > 0:
                file_id = photos.photos[0][-1].file_id
                await message.reply_photo(
                    photo=file_id,
                    caption=caption,
                    parse_mode='HTML',
                    reply_markup=keyboard
                )
                return
        except Exception as e:
            logger.warning(f"Error getting profile photo: {e}")
        
        # Fallback: send just text if no photo
        await message.reply_text(caption, parse_mode='HTML', reply_markup=keyboard)
        
    elif forward_origin.type == "hidden_user":
        # Message forwarded from a user who chose to hide their account
        sender_name = forward_origin.sender_user_name
        caption = (
            f"🔒 <b>Hidden User</b>\n"
            f"💳 <b>Name:</b> {sender_name}\n"
            f"⚠️ <b>Note:</b> This user has chosen to hide their account when forwarding messages.\n"
            f"UID and profile link are not available."
        )
        await message.reply_text(caption, parse_mode='HTML')
        
    elif forward_origin.type == "chat":
        # Message forwarded from a group chat
        chat = forward_origin.sender_chat
        caption = (
            f"👥 <b>Forwarded from Chat</b>\n"
            f"💳 <b>Chat Name:</b> {chat.title}\n"
            f"🪪 <b>Chat ID:</b> <code>{chat.id}</code>\n"
            f"📝 <b>Chat Type:</b> {chat.type}"
        )
        
        # Add chat link if available
        keyboard = None
        if chat.username:
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("🔗 View Chat", url=f"https://t.me/{chat.username}")]
            ])
            caption += f"\n🫆 <b>Username:</b> @{chat.username}"
        
        await message.reply_text(caption, parse_mode='HTML', reply_markup=keyboard)
        
    elif forward_origin.type == "channel":
        # Message forwarded from a channel
        chat = forward_origin.chat
        caption = (
            f"📢 <b>Forwarded from Channel</b>\n"
            f"💳 <b>Channel Name:</b> {chat.title}\n"
            f"🪪 <b>Channel ID:</b> <code>{chat.id}</code>"
        )
        
        # Add channel link if available
        keyboard = None
        if chat.username:
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("🔗 View Channel", url=f"https://t.me/{chat.username}")]
            ])
            caption += f"\n🫆 <b>Username:</b> @{chat.username}"
        
        await message.reply_text(caption, parse_mode='HTML', reply_markup=keyboard)
        
    else:
        await message.reply_text("⚠️ Unknown forward origin type. Please try again with a different message.")

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Log errors and notify user"""
    logger.error(f"Update {update} caused error {context.error}")
    
    if update and update.effective_message:
        await update.effective_message.reply_text(
            "❌ An error occurred while processing your request. Please try again."
        )

def main():
    # Load users on startup
    load_users()
    
    app = ApplicationBuilder().token(TOKEN).build()
    
    # Add error handler
    app.add_error_handler(error_handler)
    
    # Add command and message handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CommandHandler("adduser", handle_adduser_command))
    app.add_handler(CommandHandler("broadcast", handle_broadcast_command))
    app.add_handler(MessageHandler(filters.FORWARDED, handle_forward))
    
    # Add callback query handler for admin panel
    app.add_handler(CallbackQueryHandler(admin_callback_handler, pattern="^admin_"))
    app.add_handler(CallbackQueryHandler(admin_callback_handler, pattern="^delete_user_"))
    app.add_handler(CallbackQueryHandler(admin_callback_handler, pattern="^confirm_delete_"))
    app.add_handler(CallbackQueryHandler(handle_back_to_admin, pattern="^back_to_admin$"))
    
    logger.info("🤖 Bot is running. Awaiting forwarded messages...")
    app.run_polling()

if __name__ == "__main__":
    main()
