import logging
from datetime import datetime
from typing import Optional
from config import ADMIN_USER_ID

logger = logging.getLogger(__name__)

def is_admin(user_id: int) -> bool:
    """Check if user is admin"""
    return user_id == ADMIN_USER_ID

def format_user_display_name(user_data: dict) -> str:
    """Format user display name"""
    first_name = user_data.get('first_name', 'Unknown')
    last_name = user_data.get('last_name', '')
    username = user_data.get('username')
    
    full_name = f"{first_name} {last_name}".strip()
    if username:
        return f"{full_name} (@{username})"
    return full_name

def format_date(date_string: str) -> str:
    """Format date string for display"""
    try:
        date_obj = datetime.fromisoformat(date_string)
        return date_obj.strftime('%Y-%m-%d %H:%M')
    except:
        return 'Unknown'

def truncate_text(text: str, max_length: int = 100) -> str:
    """Truncate text to specified length"""
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."

def create_user_data(user) -> dict:
    """Create user data dictionary from Telegram user object"""
    return {
        'user_id': user.id,
        'username': user.username,
        'first_name': user.first_name,
        'last_name': user.last_name,
        'joined_date': datetime.now().isoformat(),
        'is_active': True,
        'last_activity': datetime.now().isoformat()
    }
