import logging
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, filters
from config import TOKEN, LOGS_DIR
from admin import AdminPanel
from handlers import start_handler, forward_handler, error_handler

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'{LOGS_DIR}/bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def main():
    """Main function to run the bot"""
    # Create application
    app = ApplicationBuilder().token(TOKEN).build()
    
    # Add error handler
    app.add_error_handler(error_handler)
    
    # Add command handlers
    app.add_handler(CommandHandler("start", start_handler))
    app.add_handler(CommandHandler("admin", AdminPanel.admin_command))
    app.add_handler(CommandHandler("adduser", AdminPanel.adduser_command))
    app.add_handler(CommandHandler("broadcast", AdminPanel.broadcast_command))
    
    # Add message handlers
    app.add_handler(MessageHandler(filters.FORWARDED, forward_handler))
    
    # Add callback query handlers
    app.add_handler(CallbackQueryHandler(AdminPanel.handle_callback, pattern="^(admin_|delete_user_|confirm_delete_|view_profile_|back_to_admin)"))
    
    logger.info("🤖 Bot is running. Awaiting messages...")
    app.run_polling()

if __name__ == "__main__":
    main()
