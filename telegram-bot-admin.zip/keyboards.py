from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from typing import List, Tuple

class Keyboards:
    @staticmethod
    def admin_main_menu() -> InlineKeyboardMarkup:
        """Main admin panel keyboard"""
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("👥 List Users", callback_data="admin_list_users")],
            [InlineKeyboardButton("➕ Add User", callback_data="admin_add_user"),
             InlineKeyboardButton("🗑️ Delete User", callback_data="admin_delete_user")],
            [InlineKeyboardButton("📢 Broadcast Message", callback_data="admin_broadcast")],
            [InlineKeyboardButton("📈 Statistics", callback_data="admin_stats")]
        ])
    
    @staticmethod
    def back_to_admin() -> InlineKeyboardMarkup:
        """Back to admin panel keyboard"""
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="back_to_admin")]
        ])
    
    @staticmethod
    def user_list_actions(user_id: str) -> InlineKeyboardMarkup:
        """User list action buttons"""
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🗑️ Delete", callback_data=f"delete_user_{user_id}"),
             InlineKeyboardButton("👤 View Profile", url=f"tg://openmessage?user_id={user_id}")],
            [InlineKeyboardButton("🔙 Back", callback_data="admin_list_users")]
        ])
    
    @staticmethod
    def delete_confirmation(user_id: str) -> InlineKeyboardMarkup:
        """Delete user confirmation keyboard"""
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ Yes, Delete", callback_data=f"confirm_delete_{user_id}"),
             InlineKeyboardButton("❌ Cancel", callback_data="admin_delete_user")]
        ])
    
    @staticmethod
    def user_deletion_list(users: List[Tuple[str, dict]]) -> InlineKeyboardMarkup:
        """Keyboard for user deletion list"""
        buttons = []
        for user_id, user_data in users:
            username = user_data.get('username', 'N/A')
            first_name = user_data.get('first_name', 'Unknown')
            display_name = f"{first_name} (@{username})" if username != 'N/A' else first_name
            
            buttons.append([
                InlineKeyboardButton(f"🗑️ {display_name}", callback_data=f"delete_user_{user_id}")
            ])
        
        buttons.append([
            InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="back_to_admin")
        ])
        
        return InlineKeyboardMarkup(buttons)
    
    @staticmethod
    def stats_refresh() -> InlineKeyboardMarkup:
        """Statistics refresh keyboard"""
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🔄 Refresh", callback_data="admin_stats")],
            [InlineKeyboardButton("🔙 Back to Admin Panel", callback_data="back_to_admin")]
        ])
    
    @staticmethod
    def profile_link_direct(user_id: str) -> InlineKeyboardMarkup:
        """Direct profile link keyboard"""
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🔗 View Profile", url=f"tg://openmessage?user_id={user_id}")]
        ])
