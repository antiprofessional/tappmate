import logging
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import db
from utils import create_user_data
from keyboards import Keyboards

logger = logging.getLogger(__name__)

# In-memory user tracking for forwarded messages
seen_users = {}

async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command"""
    user = update.effective_user
    
    # Add user to bot users database
    user_data = create_user_data(user)
    db.add_user(user.id, user_data)
    
    await update.message.reply_text(
        "👤 Send me a forwarded message from any user.\n"
        "I'll return their UID, username, full name, profile picture and a permanent link to their profile.\n\n"
        "⚠️ Note: Due to Telegram's privacy settings, some user information may be hidden."
    )

async def forward_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle forwarded messages"""
    message = update.effective_message
    
    # Update user activity
    db.update_user_activity(update.effective_user.id)
    
    # Check if message is actually forwarded
    if not message.forward_origin:
        return await message.reply_text("⚠️ Please forward a message directly from a user.")
    
    forward_origin = message.forward_origin
    
    # Handle different types of forward origins
    if forward_origin.type == "user":
        await _handle_user_forward(message, context, forward_origin)
    elif forward_origin.type == "hidden_user":
        await _handle_hidden_user_forward(message, forward_origin)
    elif forward_origin.type == "chat":
        await _handle_chat_forward(message, forward_origin)
    elif forward_origin.type == "channel":
        await _handle_channel_forward(message, forward_origin)
    else:
        await message.reply_text("⚠️ Unknown forward origin type. Please try again with a different message.")

async def _handle_user_forward(message, context, forward_origin):
    """Handle forwarded message from user"""
    user = forward_origin.sender_user
    uid = user.id
    full_name = f"{user.first_name or ''} {user.last_name or ''}".strip()
    username = f"@{user.username}" if user.username else "None"
    
    # First-seen timestamp
    if uid not in seen_users:
        seen_users[uid] = datetime.now()
    created_at = seen_users[uid].strftime("%Y-%m-%d %H:%M:%S")
    
    # Message caption
    caption = (
        f"💳 <b>Full Name:</b> {full_name}\n"
        f"🪪 <b>UID:</b> <code>{uid}</code>\n"
        f"🫆 <b>Username:</b> {username}\n"
        f"🗓️ <b>First Seen:</b> <code>{created_at}</code>"
    )
    
    # Use direct profile link keyboard
    keyboard = Keyboards.profile_link_direct(str(uid))
    
    # Try to fetch profile photo
    try:
        photos = await context.bot.get_user_profile_photos(uid, limit=1)
        if photos.total_count > 0:
            file_id = photos.photos[0][-1].file_id
            await message.reply_photo(
                photo=file_id,
                caption=caption,
                parse_mode='HTML',
                reply_markup=keyboard
            )
            return
    except Exception as e:
        logger.warning(f"Error getting profile photo: {e}")
    
    # Fallback: send just text if no photo
    await message.reply_text(caption, parse_mode='HTML', reply_markup=keyboard)

async def _handle_hidden_user_forward(message, forward_origin):
    """Handle forwarded message from hidden user"""
    sender_name = forward_origin.sender_user_name
    caption = (
        f"🔒 <b>Hidden User</b>\n"
        f"💳 <b>Name:</b> {sender_name}\n"
        f"⚠️ <b>Note:</b> This user has chosen to hide their account when forwarding messages.\n"
        f"UID and profile link are not available."
    )
    await message.reply_text(caption, parse_mode='HTML')

async def _handle_chat_forward(message, forward_origin):
    """Handle forwarded message from chat"""
    chat = forward_origin.sender_chat
    caption = (
        f"👥 <b>Forwarded from Chat</b>\n"
        f"💳 <b>Chat Name:</b> {chat.title}\n"
        f"🪪 <b>Chat ID:</b> <code>{chat.id}</code>\n"
        f"📝 <b>Chat Type:</b> {chat.type}"
    )
    
    # Add direct chat link if available
    keyboard = None
    if chat.username:
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔗 View Chat", url=f"https://t.me/{chat.username}")]
        ])
        caption += f"\n🫆 <b>Username:</b> @{chat.username}"
    
    await message.reply_text(caption, parse_mode='HTML', reply_markup=keyboard)

async def _handle_channel_forward(message, forward_origin):
    """Handle forwarded message from channel"""
    chat = forward_origin.chat
    caption = (
        f"📢 <b>Forwarded from Channel</b>\n"
        f"💳 <b>Channel Name:</b> {chat.title}\n"
        f"🪪 <b>Channel ID:</b> <code>{chat.id}</code>"
    )
    
    # Add direct channel link if available
    keyboard = None
    if chat.username:
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔗 View Channel", url=f"https://t.me/{chat.username}")]
        ])
        caption += f"\n🫆 <b>Username:</b> @{chat.username}"
    
    await message.reply_text(caption, parse_mode='HTML', reply_markup=keyboard)

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Log errors and notify user"""
    logger.error(f"Update {update} caused error {context.error}")
    
    if update and update.effective_message:
        await update.effective_message.reply_text(
            "❌ An error occurred while processing your request. Please try again."
        )
