import json
import os
import logging
from datetime import datetime
from typing import Dict, Optional, List
from config import USERS_FILE

logger = logging.getLogger(__name__)

class UserDatabase:
    def __init__(self):
        self.users: Dict[str, dict] = {}
        self.load_users()
    
    def load_users(self) -> None:
        """Load users from file"""
        try:
            if os.path.exists(USERS_FILE):
                with open(USERS_FILE, 'r', encoding='utf-8') as f:
                    self.users = json.load(f)
                logger.info(f"Loaded {len(self.users)} users from database")
        except Exception as e:
            logger.error(f"Error loading users: {e}")
            self.users = {}
    
    def save_users(self) -> None:
        """Save users to file"""
        try:
            with open(USERS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.users, f, indent=2, ensure_ascii=False)
            logger.info(f"Saved {len(self.users)} users to database")
        except Exception as e:
            logger.error(f"Error saving users: {e}")
    
    def add_user(self, user_id: int, user_data: dict) -> None:
        """Add user to database"""
        self.users[str(user_id)] = user_data
        self.save_users()
        logger.info(f"Added user {user_id} to database")
    
    def remove_user(self, user_id: int) -> bool:
        """Remove user from database"""
        user_id_str = str(user_id)
        if user_id_str in self.users:
            del self.users[user_id_str]
            self.save_users()
            logger.info(f"Removed user {user_id} from database")
            return True
        return False
    
    def get_user(self, user_id: int) -> Optional[dict]:
        """Get user data by ID"""
        return self.users.get(str(user_id))
    
    def get_all_users(self) -> Dict[str, dict]:
        """Get all users"""
        return self.users.copy()
    
    def get_user_count(self) -> int:
        """Get total user count"""
        return len(self.users)
    
    def get_active_users(self) -> List[dict]:
        """Get all active users"""
        return [user for user in self.users.values() if user.get('is_active', True)]
    
    def get_users_joined_today(self) -> int:
        """Get count of users who joined today"""
        today = datetime.now().date()
        count = 0
        for user in self.users.values():
            try:
                join_date = datetime.fromisoformat(user.get('joined_date', '2000-01-01')).date()
                if join_date == today:
                    count += 1
            except:
                continue
        return count
    
    def update_user_activity(self, user_id: int, is_active: bool = True) -> None:
        """Update user activity status"""
        user_id_str = str(user_id)
        if user_id_str in self.users:
            self.users[user_id_str]['is_active'] = is_active
            self.users[user_id_str]['last_activity'] = datetime.now().isoformat()
            self.save_users()

# Global database instance
db = UserDatabase()
