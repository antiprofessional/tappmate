import os

# Bot Configuration
TOKEN = "7552114625:AAHZtdYvsqoUqDyDGwf5_v3yh898PqRsuR8"

# Replace with your admin user ID
ADMIN_USER_ID = 123456789  # Replace with your actual Telegram user ID

# File paths
USERS_FILE = "bot_users.json"
LOGS_DIR = "logs"

# Bot settings
MAX_USERS_PER_PAGE = 10
BROADCAST_DELAY = 0.1  # Delay between broadcast messages to avoid rate limiting

# Create logs directory if it doesn't exist
if not os.path.exists(LOGS_DIR):
    os.makedirs(LOGS_DIR)
