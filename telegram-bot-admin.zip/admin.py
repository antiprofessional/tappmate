import logging
from datetime import datetime
from telegram import Update
from telegram.ext import ContextTypes
from database import db
from utils import is_admin, format_user_display_name, format_date
from keyboards import Keyboards
from config import MAX_USERS_PER_PAGE

logger = logging.getLogger(__name__)

class AdminPanel:
    @staticmethod
    async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /admin command"""
        user_id = update.effective_user.id
        
        if not is_admin(user_id):
            await update.message.reply_text("❌ You are not authorized to access the admin panel.")
            return
        
        admin_name = update.effective_user.first_name or "Admin"
        greeting = f"👋 Welcome to Admin Panel, {admin_name}!\n\n"
        greeting += f"📊 Total Bot Users: {db.get_user_count()}\n"
        greeting += f"🕐 Current Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        await update.message.reply_text(greeting, reply_markup=Keyboards.admin_main_menu())
    
    @staticmethod
    async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle admin panel callbacks"""
        query = update.callback_query
        user_id = query.from_user.id
        
        if not is_admin(user_id):
            await query.answer("❌ Unauthorized access!", show_alert=True)
            return
        
        await query.answer()
        
        if query.data == "admin_list_users":
            await AdminPanel._list_users(query, context)
        elif query.data == "admin_add_user":
            await AdminPanel._add_user_prompt(query, context)
        elif query.data == "admin_delete_user":
            await AdminPanel._delete_user_prompt(query, context)
        elif query.data == "admin_broadcast":
            await AdminPanel._broadcast_prompt(query, context)
        elif query.data == "admin_stats":
            await AdminPanel._show_stats(query, context)
        elif query.data.startswith("delete_user_"):
            user_id_to_delete = query.data.split("_")[-1]
            await AdminPanel._confirm_delete_user(query, context, user_id_to_delete)
        elif query.data.startswith("confirm_delete_"):
            user_id_to_delete = query.data.split("_")[-1]
            await AdminPanel._execute_delete_user(query, context, user_id_to_delete)
        elif query.data.startswith("view_profile_"):
            user_id_to_view = query.data.split("_")[-1]
            await AdminPanel._view_user_profile(query, context, user_id_to_view)
        elif query.data == "back_to_admin":
            await AdminPanel._back_to_main(query, context)
    
    @staticmethod
    async def _list_users(query, context):
        """List all bot users"""
        users = db.get_all_users()
        
        if not users:
            await query.edit_message_text("📭 No users found in the database.")
            return
        
        message = "👥 <b>Bot Users List:</b>\n\n"
        
        for i, (user_id, user_data) in enumerate(list(users.items())[:MAX_USERS_PER_PAGE], 1):
            display_name = format_user_display_name(user_data)
            joined_date = format_date(user_data.get('joined_date', ''))
            status = "🟢" if user_data.get('is_active', True) else "🔴"
            
            message += f"{i}. {status} <b>{display_name}</b>\n"
            message += f"   🆔 ID: <code>{user_id}</code>\n"
            message += f"   📅 Joined: {joined_date}\n\n"
        
        if len(users) > MAX_USERS_PER_PAGE:
            message += f"... and {len(users) - MAX_USERS_PER_PAGE} more users"
        
        await query.edit_message_text(
            message, 
            parse_mode='HTML', 
            reply_markup=Keyboards.back_to_admin()
        )
    
    @staticmethod
    async def _add_user_prompt(query, context):
        """Prompt admin to add user"""
        message = "➕ <b>Add User</b>\n\n"
        message += "To add a user, please send me their User ID in the following format:\n"
        message += "<code>/adduser 123456789</code>\n\n"
        message += "Note: The user must have interacted with the bot at least once for this to work properly."
        
        await query.edit_message_text(
            message, 
            parse_mode='HTML', 
            reply_markup=Keyboards.back_to_admin()
        )
    
    @staticmethod
    async def _delete_user_prompt(query, context):
        """Show users for deletion"""
        users = db.get_all_users()
        
        if not users:
            await query.edit_message_text("📭 No users found to delete.")
            return
        
        message = "🗑️ <b>Delete User</b>\n\n"
        message += "Select a user to delete:\n\n"
        
        user_list = list(users.items())[:MAX_USERS_PER_PAGE]
        
        await query.edit_message_text(
            message, 
            parse_mode='HTML', 
            reply_markup=Keyboards.user_deletion_list(user_list)
        )
    
    @staticmethod
    async def _confirm_delete_user(query, context, user_id_to_delete):
        """Confirm user deletion"""
        user_data = db.get_user(int(user_id_to_delete))
        if not user_data:
            await query.edit_message_text("❌ User not found!")
            return
        
        display_name = format_user_display_name(user_data)
        
        message = f"⚠️ <b>Confirm Deletion</b>\n\n"
        message += f"Are you sure you want to delete this user?\n\n"
        message += f"👤 <b>User:</b> {display_name}\n"
        message += f"🆔 <b>ID:</b> <code>{user_id_to_delete}</code>\n\n"
        message += "This action cannot be undone!"
        
        await query.edit_message_text(
            message, 
            parse_mode='HTML', 
            reply_markup=Keyboards.delete_confirmation(user_id_to_delete)
        )
    
    @staticmethod
    async def _execute_delete_user(query, context, user_id_to_delete):
        """Execute user deletion"""
        if db.remove_user(int(user_id_to_delete)):
            await query.edit_message_text(f"✅ User {user_id_to_delete} has been deleted successfully!")
        else:
            await query.edit_message_text(f"❌ Failed to delete user {user_id_to_delete}. User not found.")
    
    @staticmethod
    async def _view_user_profile(query, context, user_id_to_view):
        """View user profile details"""
        user_data = db.get_user(int(user_id_to_view))
        if not user_data:
            await query.edit_message_text("❌ User not found!")
            return
        
        display_name = format_user_display_name(user_data)
        joined_date = format_date(user_data.get('joined_date', ''))
        last_activity = format_date(user_data.get('last_activity', ''))
        status = "🟢 Active" if user_data.get('is_active', True) else "🔴 Inactive"
        
        message = f"👤 <b>User Profile</b>\n\n"
        message += f"<b>Name:</b> {display_name}\n"
        message += f"<b>ID:</b> <code>{user_id_to_view}</code>\n"
        message += f"<b>Status:</b> {status}\n"
        message += f"<b>Joined:</b> {joined_date}\n"
        message += f"<b>Last Activity:</b> {last_activity}\n"
        
        await query.edit_message_text(
            message, 
            parse_mode='HTML', 
            reply_markup=Keyboards.user_list_actions(user_id_to_view)
        )
    
    @staticmethod
    async def _broadcast_prompt(query, context):
        """Prompt for broadcast message"""
        message = "📢 <b>Broadcast Message</b>\n\n"
        message += "To send a broadcast message to all users, use the following format:\n"
        message += "<code>/broadcast Your message here</code>\n\n"
        message += f"The message will be sent to {len(db.get_active_users())} active users."
        
        await query.edit_message_text(
            message, 
            parse_mode='HTML', 
            reply_markup=Keyboards.back_to_admin()
        )
    
    @staticmethod
    async def _show_stats(query, context):
        """Show bot statistics"""
        total_users = db.get_user_count()
        active_users = len(db.get_active_users())
        users_today = db.get_users_joined_today()
        
        message = "📈 <b>Bot Statistics</b>\n\n"
        message += f"👥 Total Users: {total_users}\n"
        message += f"✅ Active Users: {active_users}\n"
        message += f"📅 New Users Today: {users_today}\n"
        message += f"🕐 Last Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        await query.edit_message_text(
            message, 
            parse_mode='HTML', 
            reply_markup=Keyboards.stats_refresh()
        )
    
    @staticmethod
    async def _back_to_main(query, context):
        """Handle back to admin panel"""
        admin_name = query.from_user.first_name or "Admin"
        greeting = f"👋 Welcome to Admin Panel, {admin_name}!\n\n"
        greeting += f"📊 Total Bot Users: {db.get_user_count()}\n"
        greeting += f"🕐 Current Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        await query.edit_message_text(greeting, reply_markup=Keyboards.admin_main_menu())
    
    @staticmethod
    async def adduser_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /adduser command"""
        user_id = update.effective_user.id
        
        if not is_admin(user_id):
            await update.message.reply_text("❌ You are not authorized to use this command.")
            return
        
        if not context.args:
            await update.message.reply_text("❌ Please provide a user ID. Usage: /adduser 123456789")
            return
        
        try:
            target_user_id = int(context.args[0])
            
            # Try to get user info
            try:
                user_info = await context.bot.get_chat(target_user_id)
                user_data = {
                    'user_id': target_user_id,
                    'username': user_info.username,
                    'first_name': user_info.first_name,
                    'last_name': user_info.last_name,
                    'joined_date': datetime.now().isoformat(),
                    'is_active': True,
                    'added_by_admin': True,
                    'last_activity': datetime.now().isoformat()
                }
                db.add_user(target_user_id, user_data)
                await update.message.reply_text(f"✅ User {target_user_id} has been added successfully!")
            except Exception as e:
                await update.message.reply_text(f"❌ Error adding user: {str(e)}")
                
        except ValueError:
            await update.message.reply_text("❌ Invalid user ID. Please provide a valid number.")
    
    @staticmethod
    async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /broadcast command"""
        user_id = update.effective_user.id
        
        if not is_admin(user_id):
            await update.message.reply_text("❌ You are not authorized to use this command.")
            return
        
        if not context.args:
            await update.message.reply_text("❌ Please provide a message to broadcast. Usage: /broadcast Your message here")
            return
        
        broadcast_message = " ".join(context.args)
        active_users = db.get_active_users()
        
        # Send broadcast message to all users
        success_count = 0
        failed_count = 0
        
        status_message = await update.message.reply_text("📢 Starting broadcast...")
        
        for user_data in active_users:
            try:
                await context.bot.send_message(
                    chat_id=user_data['user_id'],
                    text=f"📢 <b>Broadcast Message:</b>\n\n{broadcast_message}",
                    parse_mode='HTML'
                )
                success_count += 1
            except Exception as e:
                logger.warning(f"Failed to send broadcast to {user_data['user_id']}: {e}")
                # Mark user as inactive if message fails
                db.update_user_activity(user_data['user_id'], False)
                failed_count += 1
        
        result_message = f"📢 <b>Broadcast Complete!</b>\n\n"
        result_message += f"✅ Successfully sent: {success_count}\n"
        result_message += f"❌ Failed to send: {failed_count}\n"
        result_message += f"📊 Total active users: {len(active_users)}"
        
        await status_message.edit_text(result_message, parse_mode='HTML')
