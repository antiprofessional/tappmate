import os
from dataclasses import dataclass
from typing import Optional

@dataclass
class BotConfig:
    """Bot configuration settings"""
    token: str
    admin_user_ids: list[int]
    max_message_length: int = 4096
    rate_limit_seconds: int = 30
    
    @classmethod
    def from_env(cls) -> 'BotConfig':
        """Load configuration from environment variables"""
        token = os.getenv('TELEGRAM_BOT_TOKEN')
        if not token:
            raise ValueError("TELEGRAM_BOT_TOKEN environment variable is required")
        
        admin_ids_str = os.getenv('ADMIN_USER_IDS', '')
        admin_ids = []
        if admin_ids_str:
            try:
                admin_ids = [int(id.strip()) for id in admin_ids_str.split(',')]
            except ValueError:
                print("Warning: Invalid ADMIN_USER_IDS format")
        
        return cls(
            token=token,
            admin_user_ids=admin_ids,
            max_message_length=int(os.getenv('MAX_MESSAGE_LENGTH', '4096')),
            rate_limit_seconds=int(os.getenv('RATE_LIMIT_SECONDS', '30'))
        )

# Global config instance
config = BotConfig.from_env()
