import time
from typing import List
from config import config

def is_admin(user_id: int) -> bool:
    """Check if user is an admin"""
    return user_id in config.admin_user_ids

def rate_limit(user_id: int, limit_seconds: int) -> bool:
    """Simple rate limiting implementation"""
    from handlers import user_last_request
    
    current_time = time.time()
    last_request = user_last_request.get(user_id, 0)
    
    if current_time - last_request < limit_seconds:
        return False
    
    user_last_request[user_id] = current_time
    return True

def split_long_message(message: str, max_length: int = 4096) -> List[str]:
    """Split long messages into chunks that fit Telegram's limits"""
    if len(message) <= max_length:
        return [message]
    
    messages = []
    current_message = ""
    
    for line in message.split('\n'):
        if len(current_message + line + '\n') > max_length:
            if current_message:
                messages.append(current_message.strip())
                current_message = ""
            
            # If single line is too long, split it
            if len(line) > max_length:
                while line:
                    chunk = line[:max_length]
                    messages.append(chunk)
                    line = line[max_length:]
            else:
                current_message = line + '\n'
        else:
            current_message += line + '\n'
    
    if current_message.strip():
        messages.append(current_message.strip())
    
    return messages

def format_user_info(user) -> str:
    """Format user information for logging"""
    username = f"@{user.username}" if user.username else "No username"
    return f"{user.full_name} ({username}, ID: {user.id})"
