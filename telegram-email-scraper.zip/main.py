import logging
import asyncio
from telegram.ext import Application

from config import config
from handlers import handlers

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def error_handler(update, context):
    """Handle errors"""
    logger.error(f"Update {update} caused error {context.error}")
    
    # Try to send error message to user
    if update and update.effective_chat:
        try:
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text="❌ **Oops! Something went wrong.**\n\n"
                     "Please try again or send /start to restart! 🔄",
                parse_mode="Markdown"
            )
        except:
            pass

async def main():
    """Main function to run the bot"""
    try:
        # Create application
        application = Application.builder().token(config.token).build()
        
        # Add handlers
        for handler in handlers:
            application.add_handler(handler)
        
        # Add error handler
        application.add_error_handler(error_handler)
        
        # Start the bot
        logger.info("🚀 Starting Email Scraper Bot...")
        logger.info(f"⏱️ Rate limit: 30 seconds between crawls")
        logger.info(f"👑 Admin users: {len(config.admin_user_ids)}")
        logger.info("🕷️ Ready to scrape websites!")
        
        # Run the bot
        await application.run_polling(
            allowed_updates=['message'],
            drop_pending_updates=True
        )
        
    except Exception as e:
        logger.error(f"Failed to start bot: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(main())
