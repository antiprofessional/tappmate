import re
from typing import List, Set, Dict, Optional, Tuple
from dataclasses import dataclass
from urllib.parse import urlparse, urljoin
import asyncio
import aiohttp
from bs4 import BeautifulSoup
import xml.etree.ElementTree as ET
from urllib.robotparser import RobotFileParser
import socket
import time
from collections import deque

@dataclass
class EmailResult:
    """Result of email scraping operation"""
    emails: Set[str]
    source: str
    total_found: int
    unique_domains: Set[str]

@dataclass
class CrawlResult:
    """Result of comprehensive website crawling"""
    emails: Set[str]
    base_domain: str
    total_pages_crawled: int
    total_emails_found: int
    unique_domains: Set[str]
    crawled_urls: Set[str]
    failed_urls: Set[str]
    subdomains_found: Set[str]
    crawl_duration: float
    
    def to_report(self) -> str:
        """Generate a detailed crawl report"""
        return f"""
🕷️ **COMPREHENSIVE CRAWL REPORT**
🌐 Target: {self.base_domain}
⏱️ Duration: {self.crawl_duration:.2f} seconds

📊 **STATISTICS**
📄 Pages Crawled: {self.total_pages_crawled}
📧 Total Emails: {self.total_emails_found}
🏢 Unique Domains: {len(self.unique_domains)}
🌍 Subdomains Found: {len(self.subdomains_found)}
❌ Failed URLs: {len(self.failed_urls)}

🎯 **SUBDOMAINS DISCOVERED**
{chr(10).join(f"• {sub}" for sub in sorted(self.subdomains_found)) if self.subdomains_found else "• None found"}

🏢 **EMAIL DOMAINS**
{chr(10).join(f"• {domain}" for domain in sorted(self.unique_domains)) if self.unique_domains else "• None found"}
        """

class EmailScraper:
    """Email scraping utility class"""
    
    # Comprehensive email regex pattern
    EMAIL_PATTERN = re.compile(
        r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        re.IGNORECASE
    )
    
    # Common email obfuscation patterns
    OBFUSCATED_PATTERNS = [
        (r'\[at\]', '@'),
        (r'$$at$$', '@'),
        (r' at ', '@'),
        (r'\[dot\]', '.'),
        (r'$$dot$$', '.'),
        (r' dot ', '.'),
    ]
    
    def __init__(self):
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30),
            headers={'User-Agent': 'Mozilla/5.0 (compatible; EmailBot/1.0)'}
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    def extract_from_text(self, text: str) -> EmailResult:
        """Extract emails from plain text"""
        # First, handle obfuscated emails
        cleaned_text = self._deobfuscate_text(text)
        
        # Find all email matches
        emails = set(self.EMAIL_PATTERN.findall(cleaned_text))
        
        # Filter out common false positives
        emails = self._filter_valid_emails(emails)
        
        # Extract unique domains
        domains = {email.split('@')[1].lower() for email in emails}
        
        return EmailResult(
            emails=emails,
            source="text",
            total_found=len(emails),
            unique_domains=domains
        )
    
    def _deobfuscate_text(self, text: str) -> str:
        """Remove common email obfuscation patterns"""
        cleaned = text
        for pattern, replacement in self.OBFUSCATED_PATTERNS:
            cleaned = re.sub(pattern, replacement, cleaned, flags=re.IGNORECASE)
        return cleaned
    
    def _filter_valid_emails(self, emails: Set[str]) -> Set[str]:
        """Filter out invalid or unwanted email patterns"""
        valid_emails = set()
        
        # Common false positive patterns to exclude
        exclude_patterns = [
            r'.*\.(png|jpg|jpeg|gif|css|js|pdf)@',
            r'.*@(example\.com|test\.com|localhost)',
            r'^[0-9]+@[0-9]+\.',  # Numeric-only local parts
        ]
        
        for email in emails:
            email = email.lower().strip()
            
            # Skip if matches exclude patterns
            if any(re.match(pattern, email) for pattern in exclude_patterns):
                continue
            
            # Basic validation
            if len(email) > 254 or len(email) < 5:  # RFC 5321 limits
                continue
            
            local, domain = email.split('@', 1)
            if len(local) > 64 or not domain:  # RFC 5321 limits
                continue
            
            valid_emails.add(email)
        
        return valid_emails

class ComprehensiveEmailScraper(EmailScraper):
    """Enhanced email scraper with comprehensive crawling capabilities"""
    
    def __init__(self, max_pages: int = 500, max_depth: int = 5, delay: float = 1.0):
        super().__init__()
        self.max_pages = max_pages
        self.max_depth = max_depth
        self.delay = delay
        self.crawled_urls: Set[str] = set()
        self.failed_urls: Set[str] = set()
        self.found_emails: Set[str] = set()
        self.subdomains: Set[str] = set()
        self.robots_cache: Dict[str, RobotFileParser] = {}
        
    async def comprehensive_crawl(self, start_url: str, progress_callback=None) -> CrawlResult:
        """Perform comprehensive crawling of a website"""
        start_time = time.time()
        
        # Normalize URL
        if not start_url.startswith(('http://', 'https://')):
            start_url = f"https://{start_url}"
        
        parsed_url = urlparse(start_url)
        base_domain = parsed_url.netloc
        
        if progress_callback:
            await progress_callback("🔍 Starting comprehensive crawl...")
        
        # Step 1: Discover subdomains
        if progress_callback:
            await progress_callback("🌐 Discovering subdomains...")
        await self._discover_subdomains(base_domain)
        
        # Step 2: Crawl main domain and subdomains
        all_domains = {base_domain} | self.subdomains
        
        for domain in all_domains:
            if len(self.crawled_urls) >= self.max_pages:
                break
                
            if progress_callback:
                await progress_callback(f"🕷️ Crawling {domain}...")
            
            domain_url = f"{parsed_url.scheme}://{domain}"
            await self._crawl_domain(domain_url, progress_callback)
        
        # Calculate results
        unique_domains = {email.split('@')[1].lower() for email in self.found_emails}
        crawl_duration = time.time() - start_time
        
        return CrawlResult(
            emails=self.found_emails,
            base_domain=base_domain,
            total_pages_crawled=len(self.crawled_urls),
            total_emails_found=len(self.found_emails),
            unique_domains=unique_domains,
            crawled_urls=self.crawled_urls,
            failed_urls=self.failed_urls,
            subdomains_found=self.subdomains,
            crawl_duration=crawl_duration
        )
    
    async def _discover_subdomains(self, domain: str):
        """Discover subdomains using various techniques"""
        # Common subdomain prefixes
        common_subs = [
            'www', 'mail', 'email', 'webmail', 'secure', 'admin', 'blog', 'news',
            'shop', 'store', 'api', 'dev', 'test', 'staging', 'support', 'help',
            'docs', 'wiki', 'forum', 'community', 'members', 'portal', 'app',
            'mobile', 'cdn', 'static', 'assets', 'img', 'images', 'media',
            'download', 'files', 'ftp', 'sftp', 'vpn', 'remote', 'access'
        ]
        
        # Test common subdomains
        for sub in common_subs:
            subdomain = f"{sub}.{domain}"
            if await self._check_subdomain_exists(subdomain):
                self.subdomains.add(subdomain)
        
        # Try to find subdomains from certificate transparency logs
        await self._check_crt_sh(domain)
    
    async def _check_subdomain_exists(self, subdomain: str) -> bool:
        """Check if a subdomain exists"""
        try:
            # DNS lookup
            socket.gethostbyname(subdomain)
            
            # HTTP check
            if self.session:
                try:
                    async with self.session.head(f"https://{subdomain}", timeout=aiohttp.ClientTimeout(total=5)) as response:
                        return response.status < 400
                except:
                    try:
                        async with self.session.head(f"http://{subdomain}", timeout=aiohttp.ClientTimeout(total=5)) as response:
                            return response.status < 400
                    except:
                        return False
            return True
        except:
            return False
    
    async def _check_crt_sh(self, domain: str):
        """Check certificate transparency logs for subdomains"""
        try:
            if self.session:
                url = f"https://crt.sh/?q=%.{domain}&output=json"
                async with self.session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as response:
                    if response.status == 200:
                        data = await response.json()
                        for entry in data[:50]:  # Limit results
                            name = entry.get('name_value', '')
                            if name and not name.startswith('*'):
                                clean_name = name.strip().lower()
                                if clean_name.endswith(f".{domain}") and clean_name != domain:
                                    self.subdomains.add(clean_name)
        except:
            pass  # Ignore errors from crt.sh
    
    async def _crawl_domain(self, domain_url: str, progress_callback=None):
        """Crawl a specific domain comprehensively"""
        parsed_domain = urlparse(domain_url)
        base_domain = parsed_domain.netloc
        
        # Get robots.txt
        robots = await self._get_robots_txt(domain_url)
        
        # Get sitemap URLs
        sitemap_urls = await self._get_sitemap_urls(domain_url, robots)
        
        # Start with homepage and sitemap URLs
        urls_to_crawl = deque([domain_url])
        urls_to_crawl.extend(sitemap_urls)
        
        crawled_count = 0
        
        while urls_to_crawl and crawled_count < self.max_pages:
            current_url = urls_to_crawl.popleft()
            
            if current_url in self.crawled_urls:
                continue
            
            # Check robots.txt
            if robots and not robots.can_fetch('*', current_url):
                continue
            
            try:
                # Crawl the page
                page_emails, new_urls = await self._crawl_single_page(current_url, base_domain)
                
                self.found_emails.update(page_emails)
                self.crawled_urls.add(current_url)
                crawled_count += 1
                
                # Add new URLs to queue
                for new_url in new_urls:
                    if new_url not in self.crawled_urls and len(urls_to_crawl) < 1000:
                        urls_to_crawl.append(new_url)
                
                if progress_callback and crawled_count % 10 == 0:
                    await progress_callback(f"📄 Crawled {crawled_count} pages, found {len(self.found_emails)} emails")
                
                # Rate limiting
                await asyncio.sleep(self.delay)
                
            except Exception as e:
                self.failed_urls.add(current_url)
                continue
    
    async def _get_robots_txt(self, domain_url: str) -> Optional[RobotFileParser]:
        """Get and parse robots.txt"""
        try:
            robots_url = urljoin(domain_url, '/robots.txt')
            
            if robots_url in self.robots_cache:
                return self.robots_cache[robots_url]
            
            if self.session:
                async with self.session.get(robots_url, timeout=aiohttp.ClientTimeout(total=10)) as response:
                    if response.status == 200:
                        robots = RobotFileParser()
                        robots.set_url(robots_url)
                        # Note: We can't use read() with async, so we'll skip robots.txt for now
                        self.robots_cache[robots_url] = None
                        return None
        except:
            pass
        return None
    
    async def _get_sitemap_urls(self, domain_url: str, robots: Optional[RobotFileParser]) -> List[str]:
        """Extract URLs from sitemap"""
        sitemap_urls = []
        
        # Check common sitemap locations
        sitemap_locations = ['/sitemap.xml', '/sitemap_index.xml', '/sitemap.txt']
        
        for sitemap_path in sitemap_locations:
            try:
                sitemap_url = urljoin(domain_url, sitemap_path)
                urls = await self._parse_sitemap(sitemap_url)
                sitemap_urls.extend(urls)
            except:
                continue
        
        return sitemap_urls[:100]  # Limit sitemap URLs
    
    async def _parse_sitemap(self, sitemap_url: str) -> List[str]:
        """Parse XML sitemap"""
        urls = []
        
        try:
            if self.session:
                async with self.session.get(sitemap_url, timeout=aiohttp.ClientTimeout(total=15)) as response:
                    if response.status == 200:
                        content = await response.text()
                        
                        # Try to parse as XML
                        try:
                            root = ET.fromstring(content)
                            
                            # Handle sitemap index
                            for sitemap in root.findall('.//{http://www.sitemaps.org/schemas/sitemap/0.9}sitemap'):
                                loc = sitemap.find('{http://www.sitemaps.org/schemas/sitemap/0.9}loc')
                                if loc is not None:
                                    sub_urls = await self._parse_sitemap(loc.text)
                                    urls.extend(sub_urls)
                            
                            # Handle URL entries
                            for url in root.findall('.//{http://www.sitemaps.org/schemas/sitemap/0.9}url'):
                                loc = url.find('{http://www.sitemaps.org/schemas/sitemap/0.9}loc')
                                if loc is not None:
                                    urls.append(loc.text)
                        
                        except ET.ParseError:
                            # Try as plain text sitemap
                            for line in content.split('\n'):
                                line = line.strip()
                                if line.startswith('http'):
                                    urls.append(line)
        except:
            pass
        
        return urls
    
    async def _crawl_single_page(self, url: str, base_domain: str) -> Tuple[Set[str], List[str]]:
        """Crawl a single page and extract emails and links"""
        page_emails = set()
        new_urls = []
        
        if not self.session:
            return page_emails, new_urls
        
        try:
            async with self.session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as response:
                if response.status != 200:
                    return page_emails, new_urls
                
                content = await response.text()
                
                # Extract emails from HTML source
                html_emails = set(self.EMAIL_PATTERN.findall(content))
                
                # Parse HTML
                soup = BeautifulSoup(content, 'html.parser')
                
                # Remove script and style elements
                for script in soup(["script", "style"]):
                    script.decompose()
                
                # Extract emails from text content
                text = soup.get_text()
                text_emails = set(self.EMAIL_PATTERN.findall(text))
                
                # Combine and filter emails
                all_emails = html_emails.union(text_emails)
                page_emails = self._filter_valid_emails(all_emails)
                
                # Extract links for further crawling
                for link in soup.find_all('a', href=True):
                    href = link['href']
                    absolute_url = urljoin(url, href)
                    parsed_link = urlparse(absolute_url)
                    
                    # Only crawl same domain links
                    if parsed_link.netloc == base_domain or parsed_link.netloc in self.subdomains:
                        # Avoid common non-content URLs
                        if not any(skip in absolute_url.lower() for skip in [
                            '.pdf', '.doc', '.zip', '.exe', '.jpg', '.png', '.gif',
                            'mailto:', 'tel:', 'javascript:', '#', '?download'
                        ]):
                            new_urls.append(absolute_url)
                
        except Exception as e:
            raise e
        
        return page_emails, new_urls
    
    def save_to_file(self, result: CrawlResult, filename: str = "maolist.txt") -> str:
        """Save crawl results to a file"""
        content = []
        
        # Add header
        content.append("=" * 60)
        content.append("EMAIL SCRAPING RESULTS")
        content.append("=" * 60)
        content.append(f"Target Domain: {result.base_domain}")
        content.append(f"Crawl Date: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        content.append(f"Pages Crawled: {result.total_pages_crawled}")
        content.append(f"Total Emails Found: {result.total_emails_found}")
        content.append(f"Unique Email Domains: {len(result.unique_domains)}")
        content.append(f"Subdomains Discovered: {len(result.subdomains_found)}")
        content.append(f"Crawl Duration: {result.crawl_duration:.2f} seconds")
        content.append("")
        
        # Add emails section
        content.append("EXTRACTED EMAIL ADDRESSES:")
        content.append("-" * 40)
        
        if result.emails:
            # Group emails by domain
            emails_by_domain = {}
            for email in sorted(result.emails):
                domain = email.split('@')[1].lower()
                if domain not in emails_by_domain:
                    emails_by_domain[domain] = []
                emails_by_domain[domain].append(email)
            
            for domain in sorted(emails_by_domain.keys()):
                content.append(f"\n[{domain.upper()}]")
                for email in sorted(emails_by_domain[domain]):
                    content.append(f"  {email}")
        else:
            content.append("No email addresses found.")
        
        # Add subdomains section
        if result.subdomains_found:
            content.append("\n\nDISCOVERED SUBDOMAINS:")
            content.append("-" * 40)
            for subdomain in sorted(result.subdomains_found):
                content.append(f"  {subdomain}")
        
        # Add crawled URLs section (sample)
        if result.crawled_urls:
            content.append("\n\nCRAWLED URLS (Sample):")
            content.append("-" * 40)
            sample_urls = list(result.crawled_urls)[:50]  # Show first 50
            for url in sorted(sample_urls):
                content.append(f"  {url}")
            
            if len(result.crawled_urls) > 50:
                content.append(f"  ... and {len(result.crawled_urls) - 50} more URLs")
        
        # Add failed URLs if any
        if result.failed_urls:
            content.append(f"\n\nFAILED URLS ({len(result.failed_urls)}):")
            content.append("-" * 40)
            for url in sorted(list(result.failed_urls)[:20]):  # Show first 20
                content.append(f"  {url}")
            
            if len(result.failed_urls) > 20:
                content.append(f"  ... and {len(result.failed_urls) - 20} more failed URLs")
        
        content.append("\n" + "=" * 60)
        content.append("END OF REPORT")
        content.append("=" * 60)
        
        # Write to file
        with open(filename, 'w', encoding='utf-8') as f:
            f.write('\n'.join(content))
        
        return filename
