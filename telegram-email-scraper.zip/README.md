# Telegram Email Scraper Bot

A comprehensive Telegram bot that extracts email addresses from entire websites including all pages, directories, and subdomains.

## 🚀 Features

- 🕷️ **Comprehensive Website Crawling** - Crawls entire websites up to 500 pages
- 🌐 **Subdomain Discovery** - Automatically finds and crawls subdomains
- 📧 **Email Extraction** - Extracts all email addresses from crawled pages
- 📄 **Detailed Reports** - Generates comprehensive crawl reports
- 💾 **File Export** - Sends clean email lists and detailed reports as text files
- 🛡️ **Rate Limiting** - Prevents abuse with built-in rate limiting
- 👥 **User-Friendly** - Simple conversation flow, no complex commands needed

## 📋 Setup Instructions

### 1. Install Dependencies
\`\`\`bash
pip install -r requirements.txt
\`\`\`

### 2. Set Environment Variables
Create a `.env` file or set these environment variables:

\`\`\`bash
# Required
export TELEGRAM_BOT_TOKEN="your_bot_token_from_botfather"

# Optional
export ADMIN_USER_IDS="123456789,987654321"  # Comma-separated admin user IDs
export RATE_LIMIT_SECONDS="30"              # Rate limit between crawls
export MAX_MESSAGE_LENGTH="4096"            # Max Telegram message length
\`\`\`

### 3. Get Bot Token
1. Message [@BotFather](https://t.me/botfather) on Telegram
2. Create a new bot with `/newbot`
3. Copy the bot token
4. Set it as `TELEGRAM_BOT_TOKEN` environment variable

### 4. Run the Bot
\`\`\`bash
python main.py
\`\`\`

## 🎯 How to Use

1. **Start the bot** - Send `/start` to your bot
2. **Send a URL** - Just paste any website URL (e.g., `company.com`)
3. **Wait for results** - Bot will crawl the entire website (2-5 minutes)
4. **Get files** - Receive clean email list and detailed report

### Example Usage
\`\`\`
User: /start
Bot: 👋 Hello! Send me a website URL to scrape...

User: example.com
Bot: 🎯 Starting comprehensive crawl...
     🔍 Step 1/4: Analyzing target website...
     🌐 Step 2/4: Discovering subdomains...
     🕷️ Step 3/4: Crawling pages...
     📊 Step 4/4: Generating email list...
     
     ✅ Crawl Successful!
     📧 Total Emails Found: 47
     📄 Pages Crawled: 156
     
     [Sends emaillist.txt and detailed_report.txt]
\`\`\`

## 📊 What Gets Crawled

✅ **Main domain and all subdomains**
✅ **All discoverable pages and directories**
✅ **Sitemap URLs**
✅ **Internal links (up to 500 pages)**
✅ **Respects robots.txt and rate limits**

## 📁 File Structure

\`\`\`
├── main.py              # Bot entry point
├── config.py            # Configuration management
├── email_scraper.py     # Core scraping and crawling logic
├── handlers.py          # Telegram conversation handlers
├── utils.py             # Utility functions
├── requirements.txt     # Python dependencies
└── README.md           # This file
\`\`\`

## 🔧 Configuration Options

- **Max Pages**: 500 pages per crawl (configurable)
- **Max Depth**: 5 levels deep (configurable)
- **Delay**: 1 second between requests (configurable)
- **Rate Limit**: 30 seconds between user requests
- **Subdomains**: Automatically discovers common subdomains

## 🛡️ Security & Ethics

- **Rate limiting** prevents abuse
- **Respects robots.txt** (when possible)
- **Admin-only commands** for statistics
- **Error handling** for failed requests
- **Input validation** for URLs

## ⚠️ Legal Notice

This bot is for educational and legitimate business purposes only. Users must:
- Respect website terms of service
- Comply with privacy laws (GDPR, CCPA, etc.)
- Not use for spam or unauthorized data collection
- Obtain proper permissions before scraping websites

## 🐛 Troubleshooting

**Bot not responding?**
- Check if `TELEGRAM_BOT_TOKEN` is set correctly
- Verify bot token with @BotFather

**No emails found?**
- Website may not publish email addresses
- Site might be blocking automated access
- Try a different website

**Crawl taking too long?**
- Large websites can take 5+ minutes
- Bot will send progress updates
- Use `/cancel` to stop if needed

## 📞 Support

If you encounter issues:
1. Check the logs for error messages
2. Verify your environment variables
3. Test with a simple website first
4. Check your internet connection

## 🔄 Updates

To update the bot:
1. Pull latest changes
2. Update dependencies: `pip install -r requirements.txt`
3. Restart the bot

---

**Made with ❤️ for legitimate email research and business purposes**
