from telegram import Update
from telegram.ext import ContextTypes, CommandHandler, MessageHandler, filters, ConversationHandler
from telegram.constants import ParseMode
import time
import os
from typing import Dict

from email_scraper import ComprehensiveEmailScraper
from config import config
from utils import is_admin, rate_limit, split_long_message

# Conversation states
WAITING_FOR_URL = 1

# Rate limiting storage
user_last_request: Dict[int, float] = {}
# Active crawls tracking
active_crawls: Dict[int, bool] = {}

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Greet user and ask for URL"""
    user_name = update.effective_user.first_name or "there"
    
    greeting_message = f"""
👋 **Hello {user_name}!**

🕷️ Welcome to the **Email Scraper Bot**!

I'm here to help you extract email addresses from entire websites. I can:

🌐 **Crawl complete websites** (all pages & subdomains)
📧 **Extract all email addresses** found
📄 **Generate detailed reports** with statistics  
💾 **Send you a complete email list** as a text file

---

🎯 **Let's get started!**

Please send me the website URL you want to scrape:

**Examples:**
• `company.com`
• `https://example.org`
• `business-website.net`

Just paste the URL and I'll do the rest! 🚀
    """
    
    await update.message.reply_text(
        greeting_message,
        parse_mode=ParseMode.MARKDOWN
    )
    
    return WAITING_FOR_URL

async def handle_url_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle URL input and start crawling"""
    user_id = update.effective_user.id
    url = update.message.text.strip()
    
    # Check if user already has an active crawl
    if user_id in active_crawls and active_crawls[user_id]:
        await update.message.reply_text(
            "⚠️ **Please wait!** I'm already working on a crawl for you.\n\n"
            "Let me finish the current one first. This usually takes 2-5 minutes."
        )
        return WAITING_FOR_URL
    
    # Rate limiting
    if not rate_limit(user_id, config.rate_limit_seconds):
        await update.message.reply_text(
            f"⏳ **Please wait {config.rate_limit_seconds} seconds** between crawl requests.\n\n"
            "This helps me provide better service to everyone! 😊"
        )
        return WAITING_FOR_URL
    
    # Validate URL format
    if not url or len(url) < 4:
        await update.message.reply_text(
            "❌ **Invalid URL**\n\n"
            "Please send me a valid website URL like:\n"
            "• `example.com`\n"
            "• `https://company.org`\n"
            "• `business-site.net`"
        )
        return WAITING_FOR_URL
    
    active_crawls[user_id] = True
    
    # Send confirmation and start crawling
    await update.message.reply_text(
        f"🎯 **Perfect! Starting comprehensive crawl...**\n\n"
        f"**Target:** `{url}`\n\n"
        "🕷️ **What I'm doing:**\n"
        "• Discovering subdomains\n"
        "• Crawling all pages\n"
        "• Extracting email addresses\n"
        "• Generating your email list\n\n"
        "⏱️ **This will take 2-5 minutes...**\n"
        "I'll send you updates as I work! 📊",
        parse_mode=ParseMode.MARKDOWN
    )
    
    # Start the crawling process
    await perform_comprehensive_crawl(update, url, user_id)
    
    # Ask if they want to crawl another site
    await update.message.reply_text(
        "🎉 **All done!**\n\n"
        "Would you like to scrape another website?\n"
        "Just send me another URL, or use /start to see the welcome message again! 🚀"
    )
    
    return WAITING_FOR_URL

async def perform_comprehensive_crawl(update: Update, url: str, user_id: int):
    """Perform the comprehensive crawl and send results"""
    
    progress_messages = [
        "🔍 **Step 1/4:** Analyzing target website...",
        "🌐 **Step 2/4:** Discovering subdomains...", 
        "🕷️ **Step 3/4:** Crawling pages and extracting emails...",
        "📊 **Step 4/4:** Generating your email list..."
    ]
    
    current_step = 0
    
    async def progress_callback(status: str):
        """Send progress updates"""
        nonlocal current_step
        try:
            if current_step < len(progress_messages):
                await update.message.reply_text(progress_messages[current_step])
                current_step += 1
            
            # Send detailed status every few updates
            if "found" in status.lower() or "crawled" in status.lower():
                await update.message.reply_text(f"📈 **Progress:** {status}")
        except:
            pass
    
    try:
        # Perform comprehensive crawl
        async with ComprehensiveEmailScraper(max_pages=500, max_depth=5, delay=1.0) as scraper:
            result = await scraper.comprehensive_crawl(url, progress_callback)
            
            # Generate summary
            summary = generate_summary(result)
            
            # Save results to file
            filename = f"emaillist_{user_id}_{int(time.time())}.txt"
            filepath = scraper.save_to_file(result, filename)
            
            # Send summary first
            await update.message.reply_text(summary, parse_mode=ParseMode.MARKDOWN)
            
            # Send the email list file
            if os.path.exists(filepath) and result.emails:
                # Create a clean email list file
                clean_filename = f"emaillist_clean_{user_id}_{int(time.time())}.txt"
                create_clean_email_file(result, clean_filename)
                
                # Send both files
                with open(clean_filename, 'rb') as f:
                    await update.message.reply_document(
                        document=f,
                        filename="emaillist.txt",
                        caption="📧 **Clean Email List** - Ready to use!"
                    )
                
                with open(filepath, 'rb') as f:
                    await update.message.reply_document(
                        document=f,
                        filename="detailed_report.txt", 
                        caption="📊 **Detailed Report** - Complete crawl analysis"
                    )
                
                # Clean up files
                os.remove(filepath)
                os.remove(clean_filename)
                
            elif result.emails:
                # If file creation failed, send emails as text
                email_text = "\n".join(sorted(result.emails))
                messages = split_long_message(f"📧 **Found Emails:**\n\n{email_text}", config.max_message_length)
                
                for message in messages:
                    await update.message.reply_text(message)
            else:
                await update.message.reply_text(
                    "😔 **No emails found** on this website.\n\n"
                    "This could mean:\n"
                    "• The site doesn't publish email addresses\n"
                    "• Emails are protected/obfuscated\n"
                    "• The site blocked automated access\n\n"
                    "Try another website! 🔄"
                )
            
    except Exception as e:
        await update.message.reply_text(
            f"❌ **Crawl Failed**\n\n"
            f"**Error:** `{str(e)}`\n\n"
            "**Possible reasons:**\n"
            "• Website is down or blocking access\n"
            "• Invalid URL format\n"
            "• Network connectivity issues\n\n"
            "Please try again with a different URL! 🔄",
            parse_mode=ParseMode.MARKDOWN
        )
    
    finally:
        active_crawls[user_id] = False

def generate_summary(result) -> str:
    """Generate a user-friendly summary"""
    if not result.emails:
        return f"""
❌ **Crawl Complete - No Emails Found**

🎯 **Target:** {result.base_domain}
📄 **Pages Checked:** {result.total_pages_crawled}
🌐 **Subdomains Found:** {len(result.subdomains_found)}
⏱️ **Time Taken:** {result.crawl_duration:.1f} seconds

Unfortunately, no email addresses were discovered on this website.
        """
    
    # Get top domains
    domain_counts = {}
    for email in result.emails:
        domain = email.split('@')[1].lower()
        domain_counts[domain] = domain_counts.get(domain, 0) + 1
    
    top_domains = sorted(domain_counts.items(), key=lambda x: x[1], reverse=True)[:5]
    
    summary = f"""
✅ **Crawl Successful!**

🎯 **Target Website:** {result.base_domain}
📧 **Total Emails Found:** {len(result.emails)}
📄 **Pages Crawled:** {result.total_pages_crawled}
🌐 **Subdomains Discovered:** {len(result.subdomains_found)}
🏢 **Unique Email Domains:** {len(result.unique_domains)}
⏱️ **Crawl Duration:** {result.crawl_duration:.1f} seconds

📊 **Top Email Domains:**
"""
    
    for domain, count in top_domains:
        summary += f"• {domain}: {count} emails\n"
    
    if result.subdomains_found:
        summary += f"\n🌍 **Subdomains Found:**\n"
        for subdomain in sorted(list(result.subdomains_found)[:5]):
            summary += f"• {subdomain}\n"
        
        if len(result.subdomains_found) > 5:
            summary += f"• ... and {len(result.subdomains_found) - 5} more\n"
    
    summary += f"\n📎 **Files being sent:**\n• Clean email list (emaillist.txt)\n• Detailed report (detailed_report.txt)"
    
    return summary

def create_clean_email_file(result, filename: str):
    """Create a clean email list file"""
    content = []
    content.append(f"# Email List - {result.base_domain}")
    content.append(f"# Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    content.append(f"# Total: {len(result.emails)} emails")
    content.append("")
    
    # Add emails sorted by domain
    emails_by_domain = {}
    for email in result.emails:
        domain = email.split('@')[1].lower()
        if domain not in emails_by_domain:
            emails_by_domain[domain] = []
        emails_by_domain[domain].append(email)
    
    for domain in sorted(emails_by_domain.keys()):
        content.append(f"# {domain.upper()} ({len(emails_by_domain[domain])} emails)")
        for email in sorted(emails_by_domain[domain]):
            content.append(email)
        content.append("")
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write('\n'.join(content))

async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle /cancel command"""
    user_id = update.effective_user.id
    
    if user_id in active_crawls and active_crawls[user_id]:
        active_crawls[user_id] = False
        await update.message.reply_text(
            "🛑 **Crawl Cancelled**\n\n"
            "Your active crawl has been stopped.\n"
            "Send me a new URL to start fresh! 🚀"
        )
    else:
        await update.message.reply_text(
            "ℹ️ **No active crawl to cancel.**\n\n"
            "Send me a URL to start scraping! 🕷️"
        )
    
    return WAITING_FOR_URL

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle /stats command (admin only)"""
    user_id = update.effective_user.id
    
    if not is_admin(user_id):
        await update.message.reply_text(
            "❌ This command is only available to administrators.\n\n"
            "Send me a URL to start scraping! 🕷️"
        )
        return WAITING_FOR_URL
    
    active_count = sum(1 for active in active_crawls.values() if active)
    
    stats_message = f"""
📊 **Bot Statistics**

👥 **Total Users:** {len(user_last_request)}
🕷️ **Active Crawls:** {active_count}
⏱️ **Rate Limit:** {config.rate_limit_seconds} seconds
📝 **Max Pages per Crawl:** 500
👑 **Admins:** {len(config.admin_user_ids)}

**Recent Activity:**
{len([t for t in user_last_request.values() if time.time() - t < 3600])} requests in last hour
    """
    
    await update.message.reply_text(stats_message, parse_mode=ParseMode.MARKDOWN)
    return WAITING_FOR_URL

async def fallback_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle unknown commands"""
    await update.message.reply_text(
        "🤔 **I didn't understand that command.**\n\n"
        "Just send me a website URL and I'll scrape it for emails!\n\n"
        "**Example:** `company.com` or `https://example.org` 🚀"
    )
    return WAITING_FOR_URL

# Create conversation handler
conversation_handler = ConversationHandler(
    entry_points=[CommandHandler("start", start_command)],
    states={
        WAITING_FOR_URL: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_url_input),
            CommandHandler("cancel", cancel_command),
            CommandHandler("stats", stats_command),
            CommandHandler("start", start_command),
        ],
    },
    fallbacks=[
        MessageHandler(filters.COMMAND, fallback_command),
        MessageHandler(filters.ALL, fallback_command),
    ],
    per_chat=True,
    per_user=True,
)

# Handler definitions
handlers = [
    conversation_handler,
]
