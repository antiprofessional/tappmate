from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler
from api_client import api
from keyboards import Keyboards

WAITING_ORDER_ID = range(1)

async def start_status_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start order status check process"""
    if update.callback_query:
        await update.callback_query.answer()
        message = update.callback_query.message
        await message.edit_text(
            "📊 **Check Order Status**\n\nPlease send your Order ID:",
            parse_mode='Markdown',
            reply_markup=Keyboards.back_to_menu()
        )
    else:
        await update.message.reply_text(
            "📊 **Check Order Status**\n\nPlease send your Order ID:",
            parse_mode='Markdown',
            reply_markup=Keyboards.back_to_menu()
        )
    
    return WAITING_ORDER_ID

async def handle_order_id_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle order ID input for status check"""
    try:
        order_id = int(update.message.text.strip())
    except ValueError:
        await update.message.reply_text(
            "❌ **Invalid Order ID**\n\nPlease enter a valid numeric Order ID.",
            parse_mode='Markdown'
        )
        return WAITING_ORDER_ID
    
    loading_msg = await update.message.reply_text("📊 Checking order status...")
    
    try:
        status_data = await api.get_order_status(order_id)
        
        if status_data and 'status' in status_data:
            status = status_data['status']
            charge = status_data.get('charge', 'N/A')
            start_count = status_data.get('start_count', 'N/A')
            remains = status_data.get('remains', 'N/A')
            
            # Status emoji mapping
            status_emoji = {
                'Pending': '⏳',
                'In progress': '🔄',
                'Completed': '✅',
                'Partial': '⚠️',
                'Processing': '🔄',
                'Canceled': '❌'
            }
            
            emoji = status_emoji.get(status, '📊')
            
            status_text = f"""
{emoji} **Order Status**

**Order ID:** `{order_id}`
**Status:** `{status}`
**Charge:** `${charge}`
**Start Count:** `{start_count}`
**Remains:** `{remains}`

**Status Meanings:**
• ⏳ Pending - Order is queued
• 🔄 In Progress - Currently processing
• ✅ Completed - Order finished
• ⚠️ Partial - Partially completed
• ❌ Canceled - Order cancelled

*Status updates automatically as order progresses*
            """
            
            await loading_msg.edit_text(
                status_text,
                parse_mode='Markdown',
                reply_markup=Keyboards.order_actions(order_id)
            )
        else:
            error_msg = status_data.get('error', 'Order not found') if status_data else 'Failed to fetch status'
            await loading_msg.edit_text(
                f"❌ **Error:**\n`{error_msg}`\n\nPlease check your Order ID and try again.",
                parse_mode='Markdown',
                reply_markup=Keyboards.back_to_menu()
            )
    
    except Exception as e:
        await loading_msg.edit_text(
            f"❌ **Error checking status:**\n`{str(e)}`",
            parse_mode='Markdown',
            reply_markup=Keyboards.back_to_menu()
        )
    
    return ConversationHandler.END

async def handle_quick_status_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle quick status check from callback"""
    query = update.callback_query
    await query.answer("📊 Checking status...")
    
    order_id = query.data.replace('check_status_', '')
    
    try:
        status_data = await api.get_order_status(order_id)
        
        if status_data and 'status' in status_data:
            status = status_data['status']
            charge = status_data.get('charge', 'N/A')
            start_count = status_data.get('start_count', 'N/A')
            remains = status_data.get('remains', 'N/A')
            
            status_emoji = {
                'Pending': '⏳',
                'In progress': '🔄',
                'Completed': '✅',
                'Partial': '⚠️',
                'Processing': '🔄',
                'Canceled': '❌'
            }
            
            emoji = status_emoji.get(status, '📊')
            
            status_text = f"""
{emoji} **Order Status Updated**

**Order ID:** `{order_id}`
**Status:** `{status}`
**Charge:** `${charge}`
**Start Count:** `{start_count}`
**Remains:** `{remains}`

*Last updated: Just now*
            """
            
            await query.edit_message_text(
                status_text,
                parse_mode='Markdown',
                reply_markup=Keyboards.order_actions(order_id)
            )
        else:
            await query.edit_message_text(
                "❌ **Error fetching status**\n\nPlease try again later.",
                parse_mode='Markdown',
                reply_markup=Keyboards.back_to_menu()
            )
    
    except Exception as e:
        await query.edit_message_text(
            f"❌ **Error:**\n`{str(e)}`",
            parse_mode='Markdown',
            reply_markup=Keyboards.back_to_menu()
        )
