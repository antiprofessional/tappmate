from telegram import Update
from telegram.ext import ContextTypes
from api_client import api
from keyboards import Keyboards

async def handle_services(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle services listing"""
    if update.callback_query:
        await update.callback_query.answer("📋 Loading services...")
        message = update.callback_query.message
    else:
        message = update.message
    
    loading_msg = await message.reply_text("📋 Loading services...")
    
    try:
        services = await api.get_services()
        
        if services and isinstance(services, list):
            # Group services by category
            categories = {}
            for service in services:
                category = service.get('category', 'Other')
                if category not in categories:
                    categories[category] = []
                categories[category].append(service)
            
            services_text = f"""
📋 **Available Services**

**Total Services:** `{len(services)}`
**Categories:** `{len(categories)}`

Select a category to browse services:

💡 **Service Information:**
• Each service shows name and price
• Read descriptions carefully before ordering
• Some services have minimum/maximum limits
            """
            
            await loading_msg.edit_text(
                services_text,
                parse_mode='Markdown',
                reply_markup=Keyboards.services_categories(services)
            )
            
            # Store services in context for later use
            context.user_data['services'] = services
            context.user_data['categories'] = categories
        else:
            await loading_msg.edit_text(
                "❌ **No services available**\n\nPlease try again later or contact support.",
                parse_mode='Markdown',
                reply_markup=Keyboards.back_to_menu()
            )
    
    except Exception as e:
        await loading_msg.edit_text(
            f"❌ **Error loading services:**\n`{str(e)}`",
            parse_mode='Markdown',
            reply_markup=Keyboards.back_to_menu()
        )

async def handle_service_category(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle service category selection"""
    query = update.callback_query
    await query.answer()
    
    category = query.data.replace('category_', '')
    categories = context.user_data.get('categories', {})
    
    if category in categories:
        services = categories[category]
        
        category_text = f"""
📱 **{category} Services**

**Available Services:** `{len(services)}`

Select a service to view details and place an order:
        """
        
        await query.edit_message_text(
            category_text,
            parse_mode='Markdown',
            reply_markup=Keyboards.service_list(services, category)
        )
    else:
        await query.edit_message_text(
            "❌ Category not found. Please try again.",
            reply_markup=Keyboards.back_to_menu()
        )

async def handle_service_details(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle individual service details"""
    query = update.callback_query
    await query.answer()
    
    service_id = query.data.replace('service_', '')
    services = context.user_data.get('services', [])
    
    # Find the service
    service = None
    for s in services:
        if str(s['service']) == service_id:
            service = s
            break
    
    if service:
        service_text = f"""
🔧 **Service Details**

**Name:** `{service['name']}`
**ID:** `{service['service']}`
**Rate:** `${service['rate']}`
**Min Order:** `{service['min']}`
**Max Order:** `{service['max']}`

**Description:**
{service.get('description', 'No description available')}

**Category:** `{service.get('category', 'N/A')}`
**Type:** `{service.get('type', 'Default')}`

💡 **To place an order:**
1. Make sure you have sufficient balance
2. Prepare the target link/username
3. Choose quantity within min/max limits

*Ready to order? Use the button below!*
        """
        
        keyboard = [
            [InlineKeyboardButton("➕ Place Order", callback_data=f"order_{service_id}")],
            [InlineKeyboardButton("🔙 Back to Services", callback_data="services")]
        ]
        
        await query.edit_message_text(
            service_text,
            parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    else:
        await query.edit_message_text(
            "❌ Service not found. Please try again.",
            reply_markup=Keyboards.back_to_menu()
        )
