from telegram import Update
from telegram.ext import ContextTypes
from api_client import api
from keyboards import Keyboards

async def balance_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle balance command"""
    await handle_balance_check(update, context)

async def handle_balance_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle balance check from button or command"""
    # Send loading message
    if update.callback_query:
        await update.callback_query.answer("💰 Checking balance...")
        message = update.callback_query.message
    else:
        message = update.message
    
    loading_msg = await message.reply_text("💰 Fetching your balance...")
    
    try:
        balance_data = await api.get_balance()
        
        if balance_data and 'balance' in balance_data:
            balance = float(balance_data['balance'])
            currency = balance_data.get('currency', 'USD')
            
            balance_text = f"""
💰 **Your Account Balance**

**Current Balance:** `{balance:.4f} {currency}`

💡 **Quick Actions:**
• Place new orders if you have sufficient balance
• Top up your account if balance is low
• Check service prices before ordering

*Balance updates in real-time after each transaction*
            """
            
            await loading_msg.edit_text(
                balance_text,
                parse_mode='Markdown',
                reply_markup=Keyboards.main_inline_menu()
            )
        else:
            await loading_msg.edit_text(
                "❌ **Error fetching balance**\n\nPlease try again later or contact support.",
                parse_mode='Markdown',
                reply_markup=Keyboards.back_to_menu()
            )
    
    except Exception as e:
        await loading_msg.edit_text(
            f"❌ **Error occurred:**\n`{str(e)}`\n\nPlease try again later.",
            parse_mode='Markdown',
            reply_markup=Keyboards.back_to_menu()
        )
