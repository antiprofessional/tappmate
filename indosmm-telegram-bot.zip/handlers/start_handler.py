from telegram import Update
from telegram.ext import ContextTypes
from keyboards import Keyboards
from utils import format_user_info

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command"""
    user = update.effective_user
    
    welcome_text = f"""
🎉 **Welcome to IndoSMM Bot!** 🎉

Hello {user.first_name}! 👋

I'm your personal SMM panel assistant. Here's what I can help you with:

💰 **Check Balance** - View your current account balance
📋 **Browse Services** - Explore all available SMM services
➕ **Place Orders** - Order likes, followers, views, and more
📊 **Track Orders** - Monitor your order status and progress
🔄 **Refill Orders** - Get refills for drop protection
❌ **Cancel Orders** - Cancel pending orders

🚀 **Getting Started:**
Use the menu buttons below or tap any option to begin!

💡 **Need Help?** Use /help for detailed instructions.
📞 **Support?** Contact our team anytime!

---
*Powered by IndoSMM - Your trusted SMM partner* 🌟
    """
    
    await update.message.reply_text(
        welcome_text,
        parse_mode='Markdown',
        reply_markup=Keyboards.main_menu()
    )
    
    # Send inline menu
    await update.message.reply_text(
        "🎛️ **Control Panel** - Choose an action:",
        parse_mode='Markdown',
        reply_markup=Keyboards.main_inline_menu()
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command"""
    help_text = """
📖 **IndoSMM Bot Help Guide**

**🔧 Available Commands:**
/start - Start the bot and show main menu
/help - Show this help message
/balance - Quick balance check
/services - Browse all services

**📱 How to Use:**

**1️⃣ Check Balance:**
• Tap "💰 Balance" to see your current funds
• Make sure you have sufficient balance before ordering

**2️⃣ Browse Services:**
• Tap "📋 Services" to see all available services
• Services are organized by categories (Instagram, Facebook, etc.)
• Each service shows price and description

**3️⃣ Place an Order:**
• Select a service from the services menu
• Follow the prompts to enter:
  - Link (profile/post URL)
  - Quantity (amount you want)
  - Additional parameters if required

**4️⃣ Track Orders:**
• Use "📊 My Orders" to see recent orders
• Check individual order status
• View completion progress

**5️⃣ Refill Orders:**
• Use "🔄 Refill" for orders with drop protection
• Enter your order ID to request a refill

**6️⃣ Cancel Orders:**
• Use "❌ Cancel Orders" to cancel pending orders
• Only works for orders that haven't started yet

**💡 Tips:**
• Keep your order IDs safe for future reference
• Check service descriptions for specific requirements
• Contact support if you encounter any issues

**📞 Need More Help?**
Contact our support team through the bot menu!
    """
    
    await update.message.reply_text(
        help_text,
        parse_mode='Markdown',
        reply_markup=Keyboards.back_to_menu()
    )
