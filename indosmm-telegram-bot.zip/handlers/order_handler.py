from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler
from api_client import api
from keyboards import Keyboards
import re

# Conversation states
WAITING_LINK, WAITING_QUANTITY, WAITING_CONFIRMATION = range(3)

async def start_order_process(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start the order placement process"""
    query = update.callback_query
    await query.answer()
    
    service_id = query.data.replace('order_', '')
    services = context.user_data.get('services', [])
    
    # Find the service
    service = None
    for s in services:
        if str(s['service']) == service_id:
            service = s
            break
    
    if not service:
        await query.edit_message_text(
            "❌ Service not found. Please try again.",
            reply_markup=Keyboards.back_to_menu()
        )
        return ConversationHandler.END
    
    context.user_data['current_service'] = service
    
    order_text = f"""
➕ **Placing Order**

**Service:** `{service['name']}`
**Price:** `${service['rate']} per 1000`
**Min:** `{service['min']}` | **Max:** `{service['max']}`

**Step 1/3:** Please send the target link or username

**Examples:**
• Instagram: `https://instagram.com/username`
• Facebook: `https://facebook.com/page`
• YouTube: `https://youtube.com/watch?v=...`
• TikTok: `https://tiktok.com/@username`

*Send the link now:*
    """
    
    await query.edit_message_text(
        order_text,
        parse_mode='Markdown',
        reply_markup=Keyboards.back_to_menu()
    )
    
    return WAITING_LINK

async def handle_link_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle link input"""
    link = update.message.text.strip()
    
    # Basic URL validation
    url_pattern = re.compile(
        r'^https?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
        r'localhost|'  # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    
    if not url_pattern.match(link):
        await update.message.reply_text(
            "❌ **Invalid URL format**\n\nPlease send a valid URL starting with http:// or https://",
            parse_mode='Markdown'
        )
        return WAITING_LINK
    
    context.user_data['order_link'] = link
    service = context.user_data['current_service']
    
    quantity_text = f"""
➕ **Placing Order**

**Service:** `{service['name']}`
**Link:** `{link}`

**Step 2/3:** Enter the quantity

**Limits:** `{service['min']}` - `{service['max']}`
**Price:** `${service['rate']}` per 1000

💡 **Calculate cost:**
Quantity ÷ 1000 × ${service['rate']} = Total cost

*Enter quantity (numbers only):*
    """
    
    await update.message.reply_text(
        quantity_text,
        parse_mode='Markdown',
        reply_markup=Keyboards.back_to_menu()
    )
    
    return WAITING_QUANTITY

async def handle_quantity_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle quantity input"""
    try:
        quantity = int(update.message.text.strip())
    except ValueError:
        await update.message.reply_text(
            "❌ **Invalid quantity**\n\nPlease enter a valid number.",
            parse_mode='Markdown'
        )
        return WAITING_QUANTITY
    
    service = context.user_data['current_service']
    min_qty = int(service['min'])
    max_qty = int(service['max'])
    
    if quantity < min_qty or quantity > max_qty:
        await update.message.reply_text(
            f"❌ **Quantity out of range**\n\nPlease enter a quantity between `{min_qty}` and `{max_qty}`.",
            parse_mode='Markdown'
        )
        return WAITING_QUANTITY
    
    context.user_data['order_quantity'] = quantity
    
    # Calculate cost
    rate = float(service['rate'])
    cost = (quantity / 1000) * rate
    
    link = context.user_data['order_link']
    
    confirmation_text = f"""
✅ **Order Confirmation**

**Service:** `{service['name']}`
**Link:** `{link}`
**Quantity:** `{quantity:,}`
**Cost:** `${cost:.4f}`

**Step 3/3:** Confirm your order

⚠️ **Important:**
• Make sure you have sufficient balance
• Double-check the link and quantity
• Orders cannot be modified after placement

*Confirm to place the order:*
    """
    
    keyboard = [
        [
            InlineKeyboardButton("✅ Confirm Order", callback_data="confirm_place_order"),
            InlineKeyboardButton("❌ Cancel", callback_data="cancel_order")
        ]
    ]
    
    await update.message.reply_text(
        confirmation_text,
        parse_mode='Markdown',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    return WAITING_CONFIRMATION

async def confirm_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Confirm and place the order"""
    query = update.callback_query
    await query.answer("🔄 Placing your order...")
    
    service = context.user_data['current_service']
    link = context.user_data['order_link']
    quantity = context.user_data['order_quantity']
    
    order_data = {
        'service': service['service'],
        'link': link,
        'quantity': quantity
    }
    
    try:
        result = await api.place_order(order_data)
        
        if result and 'order' in result:
            order_id = result['order']
            
            success_text = f"""
🎉 **Order Placed Successfully!**

**Order ID:** `{order_id}`
**Service:** `{service['name']}`
**Quantity:** `{quantity:,}`
**Status:** `Pending`

💡 **What's next?**
• Your order is now in the queue
• Processing will begin shortly
• Use Order ID to track progress

*Save your Order ID for future reference!*
            """
            
            await query.edit_message_text(
                success_text,
                parse_mode='Markdown',
                reply_markup=Keyboards.order_actions(order_id)
            )
        else:
            error_msg = result.get('error', 'Unknown error occurred') if result else 'API request failed'
            await query.edit_message_text(
                f"❌ **Order Failed**\n\n`{error_msg}`\n\nPlease try again or contact support.",
                parse_mode='Markdown',
                reply_markup=Keyboards.back_to_menu()
            )
    
    except Exception as e:
        await query.edit_message_text(
            f"❌ **Error placing order:**\n`{str(e)}`",
            parse_mode='Markdown',
            reply_markup=Keyboards.back_to_menu()
        )
    
    # Clear order data
    context.user_data.pop('current_service', None)
    context.user_data.pop('order_link', None)
    context.user_data.pop('order_quantity', None)
    
    return ConversationHandler.END

async def cancel_order_process(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancel the order process"""
    query = update.callback_query
    await query.answer("❌ Order cancelled")
    
    await query.edit_message_text(
        "❌ **Order Cancelled**\n\nYou can start a new order anytime from the main menu.",
        parse_mode='Markdown',
        reply_markup=Keyboards.main_inline_menu()
    )
    
    # Clear order data
    context.user_data.pop('current_service', None)
    context.user_data.pop('order_link', None)
    context.user_data.pop('order_quantity', None)
    
    return ConversationHandler.END
