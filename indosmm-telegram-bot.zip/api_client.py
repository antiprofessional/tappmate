import aiohttp
import json
from typing import Dict, List, Union, Optional
from config import config

class IndoSMMAPI:
    def __init__(self):
        self.api_url = config.API_URL
        self.api_key = config.API_KEY
    
    async def _make_request(self, data: Dict) -> Optional[Dict]:
        """Make HTTP request to IndoSMM API"""
        data['key'] = self.api_key
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.api_url,
                    data=data,
                    ssl=False,
                    headers={'User-Agent': 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)'}
                ) as response:
                    result = await response.text()
                    return json.loads(result) if result else None
        except Exception as e:
            print(f"API Error: {e}")
            return None
    
    async def get_services(self) -> Optional[List[Dict]]:
        """Get all available services"""
        data = {'action': 'services'}
        return await self._make_request(data)
    
    async def get_balance(self) -> Optional[Dict]:
        """Get account balance"""
        data = {'action': 'balance'}
        return await self._make_request(data)
    
    async def place_order(self, order_data: Dict) -> Optional[Dict]:
        """Place a new order"""
        data = {'action': 'add', **order_data}
        return await self._make_request(data)
    
    async def get_order_status(self, order_id: Union[int, str]) -> Optional[Dict]:
        """Get single order status"""
        data = {'action': 'status', 'order': str(order_id)}
        return await self._make_request(data)
    
    async def get_multiple_order_status(self, order_ids: List[Union[int, str]]) -> Optional[List[Dict]]:
        """Get multiple orders status"""
        data = {'action': 'status', 'orders': ','.join(map(str, order_ids))}
        return await self._make_request(data)
    
    async def refill_order(self, order_id: Union[int, str]) -> Optional[Dict]:
        """Refill single order"""
        data = {'action': 'refill', 'order': str(order_id)}
        return await self._make_request(data)
    
    async def refill_multiple_orders(self, order_ids: List[Union[int, str]]) -> Optional[Dict]:
        """Refill multiple orders"""
        data = {'action': 'refill', 'orders': ','.join(map(str, order_ids))}
        return await self._make_request(data)
    
    async def get_refill_status(self, refill_id: Union[int, str]) -> Optional[Dict]:
        """Get refill status"""
        data = {'action': 'refill_status', 'refill': str(refill_id)}
        return await self._make_request(data)
    
    async def cancel_orders(self, order_ids: List[Union[int, str]]) -> Optional[Dict]:
        """Cancel orders"""
        data = {'action': 'cancel', 'orders': ','.join(map(str, order_ids))}
        return await self._make_request(data)

# Global API instance
api = IndoSMMAPI()
