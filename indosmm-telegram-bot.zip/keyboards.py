from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton

class Keyboards:
    @staticmethod
    def main_menu():
        """Main menu persistent keyboard"""
        keyboard = [
            [KeyboardButton("🏠 Main Menu"), KeyboardButton("💰 Balance")],
            [KeyboardButton("📋 Services"), KeyboardButton("📊 My Orders")],
            [KeyboardButton("🔄 Refill"), KeyboardButton("❌ Cancel Orders")]
        ]
        return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, persistent=True)
    
    @staticmethod
    def main_inline_menu():
        """Main inline menu"""
        keyboard = [
            [
                InlineKeyboardButton("💰 Check Balance", callback_data="balance"),
                InlineKeyboardButton("📋 View Services", callback_data="services")
            ],
            [
                InlineKeyboardButton("➕ Place Order", callback_data="place_order"),
                InlineKeyboardButton("📊 Order Status", callback_data="order_status")
            ],
            [
                InlineKeyboardButton("🔄 Refill Order", callback_data="refill_order"),
                InlineKeyboardButton("❌ Cancel Orders", callback_data="cancel_orders")
            ],
            [
                InlineKeyboardButton("ℹ️ Help", callback_data="help"),
                InlineKeyboardButton("📞 Support", callback_data="support")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def services_categories(services):
        """Services categories keyboard"""
        categories = {}
        for service in services:
            category = service.get('category', 'Other')
            if category not in categories:
                categories[category] = []
            categories[category].append(service)
        
        keyboard = []
        for category in sorted(categories.keys()):
            keyboard.append([InlineKeyboardButton(
                f"📱 {category} ({len(categories[category])})",
                callback_data=f"category_{category}"
            )])
        
        keyboard.append([InlineKeyboardButton("🔙 Back to Menu", callback_data="main_menu")])
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def service_list(services, category, page=0):
        """Service list with pagination"""
        keyboard = []
        start_idx = page * 5
        end_idx = start_idx + 5
        
        for service in services[start_idx:end_idx]:
            service_text = f"{service['name']} - ${service['rate']}"
            keyboard.append([InlineKeyboardButton(
                service_text[:50] + "..." if len(service_text) > 50 else service_text,
                callback_data=f"service_{service['service']}"
            )])
        
        # Pagination buttons
        nav_buttons = []
        if page > 0:
            nav_buttons.append(InlineKeyboardButton("⬅️ Previous", callback_data=f"services_page_{category}_{page-1}"))
        if end_idx < len(services):
            nav_buttons.append(InlineKeyboardButton("➡️ Next", callback_data=f"services_page_{category}_{page+1}"))
        
        if nav_buttons:
            keyboard.append(nav_buttons)
        
        keyboard.append([InlineKeyboardButton("🔙 Back to Categories", callback_data="services")])
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def order_actions(order_id):
        """Order action buttons"""
        keyboard = [
            [
                InlineKeyboardButton("📊 Check Status", callback_data=f"check_status_{order_id}"),
                InlineKeyboardButton("🔄 Refill", callback_data=f"refill_{order_id}")
            ],
            [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def confirmation_keyboard(action, data):
        """Confirmation keyboard for actions"""
        keyboard = [
            [
                InlineKeyboardButton("✅ Confirm", callback_data=f"confirm_{action}_{data}"),
                InlineKeyboardButton("❌ Cancel", callback_data="main_menu")
            ]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def back_to_menu():
        """Simple back to menu button"""
        keyboard = [[InlineKeyboardButton("🔙 Back to Menu", callback_data="main_menu")]]
        return InlineKeyboardMarkup(keyboard)
