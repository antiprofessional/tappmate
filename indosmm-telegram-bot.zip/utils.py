from datetime import datetime
from typing import Dict, Any

def format_user_info(user) -> str:
    """Format user information"""
    return f"@{user.username}" if user.username else f"{user.first_name} {user.last_name or ''}".strip()

def format_currency(amount: float, currency: str = "USD") -> str:
    """Format currency amount"""
    return f"${amount:.4f} {currency}"

def format_timestamp(timestamp: int) -> str:
    """Format timestamp to readable date"""
    return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")

def truncate_text(text: str, max_length: int = 50) -> str:
    """Truncate text with ellipsis"""
    return text[:max_length] + "..." if len(text) > max_length else text

def get_status_emoji(status: str) -> str:
    """Get emoji for order status"""
    status_emojis = {
        'Pending': '⏳',
        'In progress': '🔄',
        'Completed': '✅',
        'Partial': '⚠️',
        'Processing': '🔄',
        'Canceled': '❌',
        'Refunding': '💰',
        'Refunded': '✅'
    }
    return status_emojis.get(status, '📊')

def validate_url(url: str) -> bool:
    """Basic URL validation"""
    import re
    url_pattern = re.compile(
        r'^https?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
        r'localhost|'  # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    return bool(url_pattern.match(url))

def calculate_order_cost(quantity: int, rate: float) -> float:
    """Calculate order cost"""
    return (quantity / 1000) * rate

def format_service_info(service: Dict[str, Any]) -> str:
    """Format service information"""
    return f"""
**{service['name']}**
ID: `{service['service']}`
Rate: `${service['rate']}`
Min: `{service['min']}` | Max: `{service['max']}`
Category: `{service.get('category', 'N/A')}`
"""
