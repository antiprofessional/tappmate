import logging
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ConversationHandler, filters
)
from config import config
from keyboards import Keyboards

# Import handlers
from handlers.start_handler import start_command, help_command
from handlers.balance_handler import balance_command, handle_balance_check
from handlers.services_handler import handle_services, handle_service_category, handle_service_details
from handlers.order_handler import (
    start_order_process, handle_link_input, handle_quantity_input,
    confirm_order, cancel_order_process, WAITING_LINK, WAITING_QUANTITY, WAITING_CONFIRMATION
)
from handlers.status_handler import (
    start_status_check, handle_order_id_input, handle_quick_status_check, WAITING_ORDER_ID
)

# Enable logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def handle_main_menu_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle main menu button presses"""
    text = update.message.text
    
    if text == "🏠 Main Menu":
        await update.message.reply_text(
            "🎛️ **Main Menu**\n\nChoose an action:",
            parse_mode='Markdown',
            reply_markup=Keyboards.main_inline_menu()
        )
    elif text == "💰 Balance":
        await handle_balance_check(update, context)
    elif text == "📋 Services":
        await handle_services(update, context)
    elif text == "📊 My Orders":
        await start_status_check(update, context)
    elif text == "🔄 Refill":
        await update.message.reply_text(
            "🔄 **Refill Orders**\n\nThis feature will be available soon!",
            parse_mode='Markdown',
            reply_markup=Keyboards.back_to_menu()
        )
    elif text == "❌ Cancel Orders":
        await update.message.reply_text(
            "❌ **Cancel Orders**\n\nThis feature will be available soon!",
            parse_mode='Markdown',
            reply_markup=Keyboards.back_to_menu()
        )

async def handle_callback_queries(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle callback queries from inline keyboards"""
    query = update.callback_query
    data = query.data
    
    if data == "main_menu":
        await query.answer()
        await query.edit_message_text(
            "🎛️ **Main Menu**\n\nChoose an action:",
            parse_mode='Markdown',
            reply_markup=Keyboards.main_inline_menu()
        )
    elif data == "balance":
        await handle_balance_check(update, context)
    elif data == "services":
        await handle_services(update, context)
    elif data == "order_status":
        await start_status_check(update, context)
    elif data == "help":
        await query.answer()
        await help_command(update, context)
    elif data == "support":
        await query.answer()
        await query.edit_message_text(
            "📞 **Support**\n\nNeed help? Contact our support team:\n\n• Email: support@indosmm.id\n• Telegram: @indosmm_support\n• Website: https://indosmm.id",
            parse_mode='Markdown',
            reply_markup=Keyboards.back_to_menu()
        )
    elif data.startswith("category_"):
        await handle_service_category(update, context)
    elif data.startswith("service_"):
        await handle_service_details(update, context)
    elif data.startswith("check_status_"):
        await handle_quick_status_check(update, context)

def main():
    """Start the bot"""
    # Create application
    application = Application.builder().token(config.BOT_TOKEN).build()
    
    # Order conversation handler
    order_conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_order_process, pattern=r'^order_\d+$')],
        states={
            WAITING_LINK: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_link_input)],
            WAITING_QUANTITY: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_quantity_input)],
            WAITING_CONFIRMATION: [
                CallbackQueryHandler(confirm_order, pattern='^confirm_place_order$'),
                CallbackQueryHandler(cancel_order_process, pattern='^cancel_order$')
            ],
        },
        fallbacks=[
            CallbackQueryHandler(cancel_order_process, pattern='^main_menu$'),
            CommandHandler('start', start_command)
        ],
    )
    
    # Status check conversation handler
    status_conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_status_check, pattern='^order_status$')],
        states={
            WAITING_ORDER_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, handle_order_id_input)],
        },
        fallbacks=[
            CallbackQueryHandler(handle_callback_queries, pattern='^main_menu$'),
            CommandHandler('start', start_command)
        ],
    )
    
    # Add handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("balance", balance_command))
    
    # Add conversation handlers
    application.add_handler(order_conv_handler)
    application.add_handler(status_conv_handler)
    
    # Add callback query handler
    application.add_handler(CallbackQueryHandler(handle_callback_queries))
    
    # Add message handler for menu buttons
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND, 
        handle_main_menu_buttons
    ))
    
    # Start the bot
    print("🤖 IndoSMM Bot is starting...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
