import os
from dataclasses import dataclass

@dataclass
class Config:
    # Telegram Bot Configuration
    BOT_TOKEN: str = os.getenv('BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')
    
    # IndoSMM API Configuration
    API_URL: str = 'https://indosmm.id/api/v2'
    API_KEY: str = os.getenv('API_KEY', '8b6668fe31405e82299d8b3d7e480a24')
    
    # Bot Settings
    ADMIN_IDS: list = [123456789]  # Add admin user IDs
    MAX_ORDERS_PER_PAGE: int = 10
    
config = Config()
