# IndoSMM Telegram Bot

A comprehensive Telegram bot for managing IndoSMM panel services with a modern, user-friendly interface.

## Features

- 💰 **Balance Management** - Check account balance in real-time
- 📋 **Service Browser** - Browse services by categories with pagination
- ➕ **Order Placement** - Easy step-by-step order placement
- 📊 **Order Tracking** - Check order status and progress
- 🔄 **Refill System** - Request refills for orders with drop protection
- ❌ **Order Management** - Cancel pending orders
- 🎛️ **Persistent Menu** - Always-visible menu buttons for quick access
- 📱 **Mobile Optimized** - Responsive design for mobile users

## Installation

1. **Clone the repository:**
   \`\`\`bash
   git clone <repository-url>
   cd indosmm-telegram-bot
   \`\`\`

2. **Install dependencies:**
   \`\`\`bash
   pip install -r requirements.txt
   \`\`\`

3. **Set up environment variables:**
   \`\`\`bash
   cp .env.example .env
   # Edit .env with your bot token and API key
   \`\`\`

4. **Run the bot:**
   \`\`\`bash
   python main.py
   \`\`\`

## Configuration

### Environment Variables

- `BOT_TOKEN`: Your Telegram bot token from @BotFather
- `API_KEY`: Your IndoSMM API key
- `ADMIN_IDS`: Comma-separated list of admin user IDs (optional)

### Bot Setup

1. Create a new bot with @BotFather on Telegram
2. Get your bot token and add it to `.env`
3. Get your IndoSMM API key from your panel
4. Start the bot and send `/start`

## Project Structure

\`\`\`
├── main.py                 # Main bot application
├── config.py              # Configuration settings
├── api_client.py          # IndoSMM API client
├── keyboards.py           # Keyboard layouts
├── utils.py               # Utility functions
├── handlers/              # Command and callback handlers
│   ├── start_handler.py   # Start and help commands
│   ├── balance_handler.py # Balance checking
│   ├── services_handler.py# Service browsing
│   ├── order_handler.py   # Order placement
│   └── status_handler.py  # Order status checking
├── requirements.txt       # Python dependencies
├── .env.example          # Environment variables template
└── README.md             # This file
\`\`\`

## Usage

### Basic Commands

- `/start` - Start the bot and show main menu
- `/help` - Show help information
- `/balance` - Quick balance check

### Menu Navigation

The bot features a persistent keyboard with quick access buttons:

- 🏠 **Main Menu** - Return to main menu
- 💰 **Balance** - Check account balance
- 📋 **Services** - Browse available services
- 📊 **My Orders** - Check order status
- 🔄 **Refill** - Request order refills
- ❌ **Cancel Orders** - Cancel pending orders

### Placing Orders

1. Tap "📋 Services" to browse available services
2. Select a category (Instagram, Facebook, etc.)
3. Choose a specific service
4. Tap "➕ Place Order"
5. Follow the step-by-step process:
   - Enter target link/username
   - Specify quantity
   - Confirm order details

### Checking Order Status

1. Use "📊 My Orders" from the menu
2. Enter your order ID
3. View detailed status information
4. Use quick action buttons for refills

## API Integration

The bot integrates with IndoSMM API v2 and supports:

- Service listing and categorization
- Order placement with validation
- Real-time status checking
- Balance monitoring
- Refill requests
- Order cancellation

## Error Handling

- Comprehensive error messages for users
- API timeout and connection error handling
- Input validation for all user inputs
- Graceful fallbacks for failed operations

## Security Features

- API key protection through environment variables
- Input sanitization and validation
- Rate limiting considerations
- Admin-only features (configurable)

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Support

For support and questions:
- Create an issue on GitHub
- Contact IndoSMM support team
- Check the documentation

## License

This project is licensed under the MIT License.
