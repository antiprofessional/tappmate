// Cryptocurrency addresses
export const CRYPTO_ADDRESSES = {
  BTC: "bc1q4h77y69kwdcr558w7ejzyntmjr9xy5wsqp9sys",
  ETH: "0x1f2a5b807058c171aa28a19b21ee77a1ab93da06",
  USDT: "TUZKzK18cp2J1gxK9zNrEBkARBntgcZFEz",
  LTC: "LU2KwsLukY2onmTRwtbTfLQserH6StS496",
  XMR: "85XyJpNNE7CFiyqKdgKbLXVrUbtabDrY3dk7QzzTVeETU9zM",
  SOL: "B2fBMqSxTRRYpNHVHCKB5vi5iA7y6wXAEs3UkBrvi3Pf",
}
