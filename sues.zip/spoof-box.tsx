"use client"

import { useState } from "react"
import { ChevronDown, Menu, Plus } from "lucide-react"
import Image from "next/image"

export default function SpoofBox() {
  const [activeTab, setActiveTab] = useState("Browser")
  const [activeNumberTab, setActiveNumberTab] = useState("Number")

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-purple-600 text-white p-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold tracking-wider">SPOOF BOX</h1>
        <div className="flex items-center gap-4">
          <button className="p-2">
            <Menu className="w-6 h-6" />
          </button>
          <div className="w-8 h-6 relative">
            <Image
              src="/placeholder.svg?height=24&width=32"
              alt="US Flag"
              width={32}
              height={24}
              className="object-cover"
            />
          </div>
        </div>
      </header>

      {/* Logo Section */}
      <div className="bg-[#4b4564] text-white py-8 flex justify-center items-center">
        <div className="text-center">
          <div className="text-4xl font-bold mb-2">SPOOF</div>
          <div className="flex items-center justify-center">
            <div className="text-4xl font-bold">MY PHONE</div>
            <Image src="/placeholder.svg?height=40&width=40" alt="Sound Wave" width={40} height={40} className="ml-2" />
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="bg-[#4b4564] text-white border-t border-gray-600 flex">
        <a href="#" className="flex-1 py-3 text-center font-medium bg-[#3d3a52]">
          Spoof Call
        </a>
        <a href="#" className="flex-1 py-3 text-center font-medium">
          Interactive
        </a>
        <a href="#" className="flex-1 py-3 text-center font-medium">
          FAQ
        </a>
        <a href="#" className="flex-1 py-3 text-center font-medium">
          Free
        </a>
      </nav>

      {/* Main Content */}
      <main className="flex-1 bg-white p-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl text-[#4b4564] text-center font-medium mb-2">Spoof Call</h2>
          <p className="text-center text-gray-500 mb-8">Spoof caller ID and add amazing features</p>

          {/* Tabs */}
          <div className="flex mb-4">
            <button
              className={`py-2 px-6 rounded-md ${
                activeTab === "Browser" ? "bg-[#8d5b8e] text-white" : "bg-gray-200 text-gray-700"
              }`}
              onClick={() => setActiveTab("Browser")}
            >
              Browser
            </button>
            <button
              className={`py-2 px-6 ml-2 rounded-md ${
                activeTab === "Your number" ? "bg-[#8d5b8e] text-white" : "bg-gray-200 text-gray-700"
              }`}
              onClick={() => setActiveTab("Your number")}
            >
              Your number
            </button>
          </div>

          <p className="text-gray-600 mb-1">Your call will be directly connected to your web browser.</p>
          <p className="text-gray-600 mb-4">
            Please make sure to enable your microphone and speaker to talk and hear your recipient.{" "}
            <a href="#" className="text-[#8d5b8e]">
              More about »
            </a>
          </p>

          {/* Login Notice */}
          <div className="bg-red-50 border border-red-100 p-4 mb-6 text-red-400">
            » Please login to enable spoof calls via your browser
          </div>

          {/* Spoof Number Section */}
          <div className="mb-6">
            <h3 className="text-[#4b4564] font-medium mb-1">Spoof Number</h3>
            <p className="text-gray-500 text-sm mb-2">This fake number will be displayed on the call</p>

            <div className="flex mb-4">
              <button
                className={`py-2 px-6 rounded-md ${
                  activeNumberTab === "Number" ? "bg-[#8d5b8e] text-white" : "bg-gray-200 text-gray-700"
                }`}
                onClick={() => setActiveNumberTab("Number")}
              >
                Number
              </button>
              <button
                className={`py-2 px-6 ml-2 rounded-md ${
                  activeNumberTab === "Anonymous Call" ? "bg-[#8d5b8e] text-white" : "bg-gray-200 text-gray-700"
                }`}
                onClick={() => setActiveNumberTab("Anonymous Call")}
              >
                Anonymous Call
              </button>
            </div>

            <div className="flex border rounded-md overflow-hidden">
              <div className="flex items-center px-3 border-r bg-white">
                <span className="text-sm mr-1">🇺🇸</span>
                <ChevronDown className="w-4 h-4" />
              </div>
              <input type="text" placeholder="(201) 555-0123" className="flex-1 p-3 outline-none" />
            </div>
          </div>

          {/* Recipient Section */}
          <div className="mb-6">
            <h3 className="text-[#4b4564] font-medium mb-1">Recipient's</h3>
            <p className="text-gray-500 text-sm mb-2">Who will get your fake call?</p>

            <div className="flex border rounded-md overflow-hidden mb-2">
              <div className="flex items-center px-3 border-r bg-white">
                <span className="text-sm mr-1">🇺🇸</span>
                <ChevronDown className="w-4 h-4" />
              </div>
              <input type="text" placeholder="(401) 555-0123" className="flex-1 p-3 outline-none" />
            </div>

            <p className="text-gray-500 text-sm text-center mb-4">
              You can add multiple recipients to create a spoof conference call. Simply choose them above and click on
              "add" to create spoof group calls.
            </p>

            <button className="w-full bg-[#8d5b8e] text-white py-3 rounded-md flex items-center justify-center mb-4">
              <Plus className="w-5 h-5 mr-2" />
              ADD
            </button>

            <p className="text-gray-500 text-sm text-center mb-4">
              Your current recipient list. Please add at least one
            </p>

            <div className="border rounded-md p-4 mb-6 h-16"></div>
          </div>

          {/* Spoof Voice Section */}
          <div className="mb-6">
            <h3 className="text-[#4b4564] font-medium mb-1">Spoof Voice</h3>
            <p className="text-gray-500 text-sm mb-2">Change the pitch of your voice to talk like a female or male</p>

            <div className="grid grid-cols-3 gap-4 mb-6">
              <button className="bg-[#8d5b8e] text-white py-3 rounded-md flex items-center justify-center">
                <span className="mr-2">♂</span> Male
              </button>
              <button className="bg-[#8d5b8e] text-white py-3 rounded-md flex items-center justify-center">
                <span className="mr-2">♀</span> Female
              </button>
              <button className="bg-[#8d5b8e] text-white py-3 rounded-md flex items-center justify-center">Off</button>
            </div>
          </div>

          {/* Text to Speech Section */}
          <div className="mb-6">
            <h3 className="text-[#4b4564] font-medium mb-1">Text to speech</h3>
            <p className="text-gray-500 text-sm mb-2">
              Enter a text that should be spoken by a female or male voice in a certain language.
            </p>

            <div className="grid grid-cols-3 gap-4 mb-4">
              <button className="bg-[#8d5b8e] text-white py-3 rounded-md flex items-center justify-center">
                <span className="mr-2">♂</span> Man
              </button>
              <button className="bg-[#8d5b8e] text-white py-3 rounded-md flex items-center justify-center">
                <span className="mr-2">♀</span> Woman
              </button>
              <button className="bg-[#8d5b8e] text-white py-3 rounded-md flex items-center justify-center">Off</button>
            </div>

            <div className="border rounded-md p-4 mb-4 flex items-center justify-between">
              <span className="text-gray-500">Choose a spoken language</span>
              <ChevronDown className="w-5 h-5 text-gray-400" />
            </div>

            <div className="border rounded-md p-4 flex items-center justify-between">
              <span className="text-gray-500">Play Once</span>
              <ChevronDown className="w-5 h-5 text-gray-400" />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
