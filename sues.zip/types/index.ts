export type VoiceMode = "Male" | "Female" | "Off"
export type TextToSpeechMode = "Man" | "Woman" | "Off"
export type CryptoType = "BTC" | "ETH" | "USDT" | "LTC" | "XMR" | "SOL"
export type SubscriptionPlan = "1month" | "6months" | "1year" | null

export interface Recipient {
  id: string
  number: string
}
