import SpoofMaster from "../spoof-master"

export default function Page() {
  return <SpoofMaster />
}
