"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Header from "@/components/layout/Header"
import Logo from "@/components/layout/Logo"
import Navigation from "@/components/layout/Navigation"
import SpoofNumber from "@/components/spoof/SpoofNumber"
import RecipientSection from "@/components/spoof/RecipientSection"
import VoiceChanger from "@/components/spoof/VoiceChanger"
import TextToSpeech from "@/components/spoof/TextToSpeech"
import CallButton from "@/components/spoof/CallButton"
import SubscriptionModal from "@/components/modals/SubscriptionModal"
import PaymentModal from "@/components/modals/PaymentModal"
import CallModal from "@/components/modals/CallModal"
import type { SubscriptionPlan } from "@/types"

export default function SpoofMaster() {
  // Modal states
  const [showSubscription, setShowSubscription] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [isCallActive, setIsCallActive] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan>(null)

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  // Handle starting a call
  const handleStartCall = () => {
    setShowSubscription(true)
  }

  // Handle plan selection
  const handlePlanSelect = (plan: SubscriptionPlan) => {
    setSelectedPlan(plan)
    setShowSubscription(false)
    setShowPaymentModal(true)
  }

  // Handle payment completion
  const handlePaymentComplete = () => {
    setShowPaymentModal(false)
    setIsCallActive(true)
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Header />
      <Logo />
      <Navigation />

      {/* Main Content */}
      <motion.main
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="flex-1 bg-gray-900 p-6"
      >
        <motion.div className="max-w-3xl mx-auto" variants={containerVariants} initial="hidden" animate="visible">
          <motion.h2 className="text-4xl text-center font-bold mb-2 bg-gradient-to-r from-cyan-500 to-blue-500 bg-clip-text text-transparent">
            Spoof Call
          </motion.h2>
          <motion.p className="text-center text-gray-400 mb-8">Spoof caller ID and add amazing features</motion.p>

          <motion.p className="text-gray-400 mb-1">Your call will be directly connected to your web browser.</motion.p>
          <motion.p className="text-gray-400 mb-4">
            Please make sure to enable your microphone and speaker to talk and hear your recipient.{" "}
            <motion.a
              href="#"
              className="text-cyan-400 hover:text-cyan-300 transition-colors"
              whileHover={{ scale: 1.05 }}
            >
              More about »
            </motion.a>
          </motion.p>

          <SpoofNumber />
          <RecipientSection />
          <VoiceChanger />
          <TextToSpeech />
          <CallButton onStartCall={handleStartCall} />
        </motion.div>
      </motion.main>

      {/* Modals */}
      <SubscriptionModal
        isOpen={showSubscription}
        onClose={() => setShowSubscription(false)}
        onSelectPlan={handlePlanSelect}
        selectedPlan={selectedPlan}
      />

      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        selectedPlan={selectedPlan}
        onPaymentComplete={handlePaymentComplete}
      />

      <CallModal isOpen={isCallActive} onClose={() => setIsCallActive(false)} />
    </div>
  )
}
