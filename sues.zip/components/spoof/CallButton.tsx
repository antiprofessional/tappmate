"use client"

import { motion } from "framer-motion"

interface CallButtonProps {
  onStartCall: () => void
}

export default function CallButton({ onStartCall }: CallButtonProps) {
  return (
    <motion.div className="mt-8 mb-12">
      <motion.button
        className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white py-4 rounded-xl font-bold text-xl"
        whileHover={{ scale: 1.03, boxShadow: "0 10px 25px -5px rgba(6, 182, 212, 0.5)" }}
        whileTap={{ scale: 0.97 }}
        onClick={onStartCall}
        animate={{
          boxShadow: ["0 0 0 rgba(6, 182, 212, 0)", "0 0 20px rgba(6, 182, 212, 0.7)", "0 0 0 rgba(6, 182, 212, 0)"],
          transition: { duration: 2, repeat: Number.POSITIVE_INFINITY },
        }}
      >
        START SPOOFING CALL
      </motion.button>
    </motion.div>
  )
}
