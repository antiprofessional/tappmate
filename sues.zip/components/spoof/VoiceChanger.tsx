"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import type { VoiceMode } from "@/types"

export default function VoiceChanger() {
  const [voiceMode, setVoiceMode] = useState<VoiceMode>("Off")

  return (
    <motion.div className="mb-6 bg-gray-800 p-6 rounded-xl border border-gray-700">
      <motion.h3 className="text-xl font-bold mb-1 text-cyan-400" whileHover={{ x: 5 }}>
        Spoof Voice
      </motion.h3>
      <motion.p className="text-gray-400 text-sm mb-4">
        Change the pitch of your voice to talk like a female or male
      </motion.p>

      <motion.div className="grid grid-cols-3 gap-4 mb-6">
        <motion.button
          className={`bg-gradient-to-r ${
            voiceMode === "Male" ? "from-cyan-500 to-blue-500 ring-2 ring-cyan-300" : "from-cyan-600 to-blue-600"
          } text-white py-3 rounded-md flex items-center justify-center`}
          whileHover={{ scale: 1.05, y: -5 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setVoiceMode("Male")}
        >
          <span className="mr-2">♂</span> Male
        </motion.button>
        <motion.button
          className={`bg-gradient-to-r ${
            voiceMode === "Female" ? "from-cyan-500 to-blue-500 ring-2 ring-cyan-300" : "from-cyan-600 to-blue-600"
          } text-white py-3 rounded-md flex items-center justify-center`}
          whileHover={{ scale: 1.05, y: -5 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setVoiceMode("Female")}
        >
          <span className="mr-2">♀</span> Female
        </motion.button>
        <motion.button
          className={`bg-gradient-to-r ${
            voiceMode === "Off" ? "from-cyan-500 to-blue-500 ring-2 ring-cyan-300" : "from-cyan-600 to-blue-600"
          } text-white py-3 rounded-md flex items-center justify-center`}
          whileHover={{ scale: 1.05, y: -5 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setVoiceMode("Off")}
        >
          Off
        </motion.button>
      </motion.div>
    </motion.div>
  )
}
