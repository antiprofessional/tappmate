"use client"

import { motion } from "framer-motion"
import { ChevronDown } from "lucide-react"
import { useState } from "react"

export default function SpoofNumber() {
  const [activeNumberTab, setActiveNumberTab] = useState("Number")
  const [spoofNumber, setSpoofNumber] = useState("")

  return (
    <motion.div className="mb-6 bg-gray-800 p-6 rounded-xl border border-gray-700">
      <motion.h3 className="text-xl font-bold mb-1 text-cyan-400" whileHover={{ x: 5 }}>
        Spoof Number
      </motion.h3>
      <motion.p className="text-gray-400 text-sm mb-4">
        Enter any number you want to appear on the recipient's caller ID
      </motion.p>

      <motion.div className="flex mb-4" whileHover={{ scale: 1.01 }}>
        <motion.button
          className={`py-2 px-6 rounded-md ${
            activeNumberTab === "Number" ? "bg-cyan-700 text-white" : "bg-gray-700 text-gray-300"
          }`}
          onClick={() => setActiveNumberTab("Number")}
          whileTap={{ scale: 0.95 }}
        >
          Number
        </motion.button>
        <motion.button
          className={`py-2 px-6 ml-2 rounded-md ${
            activeNumberTab === "Anonymous Call" ? "bg-cyan-700 text-white" : "bg-gray-700 text-gray-300"
          }`}
          onClick={() => setActiveNumberTab("Anonymous Call")}
          whileTap={{ scale: 0.95 }}
        >
          Anonymous Call
        </motion.button>
      </motion.div>

      {activeNumberTab === "Number" ? (
        <motion.div
          className="flex border border-gray-600 rounded-md overflow-hidden bg-gray-900"
          whileHover={{ scale: 1.01, borderColor: "#22d3ee" }}
          transition={{ duration: 0.2 }}
        >
          <motion.div className="flex items-center px-3 border-r border-gray-600 bg-gray-800">
            <span className="text-sm mr-1">🇺🇸</span>
            <ChevronDown className="w-4 h-4 text-gray-400" />
          </motion.div>
          <motion.input
            type="text"
            placeholder="Enter any number..."
            className="flex-1 p-3 outline-none bg-transparent text-white"
            value={spoofNumber}
            onChange={(e) => setSpoofNumber(e.target.value)}
          />
        </motion.div>
      ) : (
        <div className="text-gray-300 p-3 bg-gray-900 rounded-md border border-gray-700">
          Your call will appear as "Unknown" or "No Caller ID"
        </div>
      )}
    </motion.div>
  )
}
