"use client"

import { motion } from "framer-motion"
import { ChevronDown, Plus, X } from "lucide-react"
import { useState } from "react"
import { v4 as uuidv4 } from "uuid"
import type { Recipient } from "@/types"

export default function RecipientSection() {
  const [recipientNumber, setRecipientNumber] = useState("")
  const [recipients, setRecipients] = useState<Recipient[]>([])

  const handleAddRecipient = () => {
    if (recipientNumber && !recipients.some((r) => r.number === recipientNumber)) {
      setRecipients([...recipients, { id: uuidv4(), number: recipientNumber }])
      setRecipientNumber("")
    }
  }

  const handleRemoveRecipient = (id: string) => {
    setRecipients(recipients.filter((recipient) => recipient.id !== id))
  }

  return (
    <motion.div className="mb-6 bg-gray-800 p-6 rounded-xl border border-gray-700">
      <motion.h3 className="text-xl font-bold mb-1 text-cyan-400" whileHover={{ x: 5 }}>
        Recipient's
      </motion.h3>
      <motion.p className="text-gray-400 text-sm mb-4">Who will get your fake call?</motion.p>

      <motion.div
        className="flex border border-gray-600 rounded-md overflow-hidden bg-gray-900 mb-4"
        whileHover={{ scale: 1.01, borderColor: "#22d3ee" }}
        transition={{ duration: 0.2 }}
      >
        <motion.div className="flex items-center px-3 border-r border-gray-600 bg-gray-800">
          <span className="text-sm mr-1">🇺🇸</span>
          <ChevronDown className="w-4 h-4 text-gray-400" />
        </motion.div>
        <motion.input
          type="text"
          placeholder="Enter recipient number..."
          className="flex-1 p-3 outline-none bg-transparent text-white"
          value={recipientNumber}
          onChange={(e) => setRecipientNumber(e.target.value)}
        />
      </motion.div>

      <motion.p
        className="text-gray-400 text-sm text-center mb-4"
        animate={{
          opacity: [0.7, 1, 0.7],
          transition: { duration: 3, repeat: Number.POSITIVE_INFINITY },
        }}
      >
        You can add multiple recipients to create a spoof conference call. Simply choose them above and click on "add"
        to create spoof group calls.
      </motion.p>

      <motion.button
        className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white py-3 rounded-md flex items-center justify-center mb-4"
        whileHover={{ scale: 1.02, boxShadow: "0 5px 15px rgba(6, 182, 212, 0.4)" }}
        whileTap={{ scale: 0.98 }}
        onClick={handleAddRecipient}
      >
        <Plus className="w-5 h-5 mr-2" />
        ADD
      </motion.button>

      <motion.p className="text-gray-400 text-sm text-center mb-4">
        {recipients.length > 0
          ? "Your current recipient list:"
          : "Your current recipient list. Please add at least one"}
      </motion.p>

      <motion.div
        className="border border-gray-700 rounded-md p-4 mb-6 min-h-16 bg-gray-900"
        whileHover={{ borderColor: "#22d3ee" }}
      >
        {recipients.length > 0 ? (
          <div className="space-y-2">
            {recipients.map((recipient) => (
              <div key={recipient.id} className="flex justify-between items-center">
                <span className="text-gray-300">{recipient.number}</span>
                <button className="text-red-400 hover:text-red-300" onClick={() => handleRemoveRecipient(recipient.id)}>
                  <X size={16} />
                </button>
              </div>
            ))}
          </div>
        ) : null}
      </motion.div>
    </motion.div>
  )
}
