"use client"

import { motion, AnimatePresence } from "framer-motion"
import { ChevronDown, Languages, Volume2 } from "lucide-react"
import { useState } from "react"
import type { TextToSpeechMode } from "@/types"

export default function TextToSpeech() {
  const [textToSpeechMode, setTextToSpeechMode] = useState<TextToSpeechMode>("Off")
  const [language, setLanguage] = useState("English")
  const [playMode, setPlayMode] = useState("Play Once")
  const [textToSpeechContent, setTextToSpeechContent] = useState("")

  const languages = ["English", "Spanish", "French", "German", "Italian", "Japanese", "Chinese", "Russian"]
  const playModes = ["Play Once", "Play Twice", "Loop"]

  return (
    <motion.div className="mb-6 bg-gray-800 p-6 rounded-xl border border-gray-700">
      <motion.h3 className="text-xl font-bold mb-1 text-cyan-400" whileHover={{ x: 5 }}>
        Text to speech
      </motion.h3>
      <motion.p className="text-gray-400 text-sm mb-4">
        Enter a text that should be spoken by a female or male voice in a certain language.
      </motion.p>

      <motion.div className="grid grid-cols-3 gap-4 mb-4">
        <motion.button
          className={`bg-gradient-to-r ${
            textToSpeechMode === "Man" ? "from-cyan-500 to-blue-500 ring-2 ring-cyan-300" : "from-cyan-600 to-blue-600"
          } text-white py-3 rounded-md flex items-center justify-center`}
          whileHover={{ scale: 1.05, y: -5 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setTextToSpeechMode("Man")}
        >
          <span className="mr-2">♂</span> Man
        </motion.button>
        <motion.button
          className={`bg-gradient-to-r ${
            textToSpeechMode === "Woman"
              ? "from-cyan-500 to-blue-500 ring-2 ring-cyan-300"
              : "from-cyan-600 to-blue-600"
          } text-white py-3 rounded-md flex items-center justify-center`}
          whileHover={{ scale: 1.05, y: -5 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setTextToSpeechMode("Woman")}
        >
          <span className="mr-2">♀</span> Woman
        </motion.button>
        <motion.button
          className={`bg-gradient-to-r ${
            textToSpeechMode === "Off" ? "from-cyan-500 to-blue-500 ring-2 ring-cyan-300" : "from-cyan-600 to-blue-600"
          } text-white py-3 rounded-md flex items-center justify-center`}
          whileHover={{ scale: 1.05, y: -5 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setTextToSpeechMode("Off")}
        >
          Off
        </motion.button>
      </motion.div>

      <AnimatePresence>
        {textToSpeechMode !== "Off" && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4"
          >
            <textarea
              className="w-full p-3 bg-gray-900 border border-gray-700 rounded-md text-white resize-none h-24 focus:outline-none focus:border-cyan-500"
              placeholder="Enter text to be spoken..."
              value={textToSpeechContent}
              onChange={(e) => setTextToSpeechContent(e.target.value)}
            ></textarea>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        className="border border-gray-700 rounded-md p-4 mb-4 flex items-center justify-between bg-gray-900"
        whileHover={{ borderColor: "#22d3ee", scale: 1.01 }}
        onClick={() => {
          const currentIndex = languages.indexOf(language)
          const nextIndex = (currentIndex + 1) % languages.length
          setLanguage(languages[nextIndex])
        }}
      >
        <div className="flex items-center">
          <Languages className="w-5 h-5 mr-2 text-gray-400" />
          <span className="text-gray-300">{language}</span>
        </div>
        <ChevronDown className="w-5 h-5 text-gray-400" />
      </motion.div>

      <motion.div
        className="border border-gray-700 rounded-md p-4 flex items-center justify-between bg-gray-900"
        whileHover={{ borderColor: "#22d3ee", scale: 1.01 }}
        onClick={() => {
          const currentIndex = playModes.indexOf(playMode)
          const nextIndex = (currentIndex + 1) % playModes.length
          setPlayMode(playModes[nextIndex])
        }}
      >
        <div className="flex items-center">
          <Volume2 className="w-5 h-5 mr-2 text-gray-400" />
          <span className="text-gray-300">{playMode}</span>
        </div>
        <ChevronDown className="w-5 h-5 text-gray-400" />
      </motion.div>
    </motion.div>
  )
}
