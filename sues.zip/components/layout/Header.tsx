"use client"

import { motion } from "framer-motion"
import { Menu, Phone } from "lucide-react"

export default function Header() {
  return (
    <motion.header
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-black text-white p-4 flex justify-between items-center border-b border-gray-800"
    >
      <motion.div className="flex items-center" whileHover={{ scale: 1.05 }}>
        <Phone className="w-6 h-6 mr-2 text-cyan-500" />
        <h1 className="text-3xl font-bold tracking-wider bg-gradient-to-r from-cyan-500 to-blue-500 bg-clip-text text-transparent">
          SPOOF MASTER
        </h1>
      </motion.div>
      <motion.div className="flex items-center gap-4" whileHover={{ scale: 1.05 }}>
        <button className="p-2 hover:bg-gray-800 rounded-full transition-all duration-300">
          <Menu className="w-6 h-6" />
        </button>
      </motion.div>
    </motion.header>
  )
}
