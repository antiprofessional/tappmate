"use client"

import { motion } from "framer-motion"

export default function Navigation() {
  return (
    <motion.nav
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.3 }}
      className="bg-gray-800 text-white border-t border-gray-700 flex justify-center"
    >
      <motion.div
        className="py-3 px-8 text-center font-medium bg-gray-900 border-b-2 border-cyan-500"
        whileHover={{ backgroundColor: "#2d2d3a" }}
      >
        Spoof Call
      </motion.div>
    </motion.nav>
  )
}
