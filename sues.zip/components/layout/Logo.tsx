"use client"

import { motion } from "framer-motion"
import Image from "next/image"

export default function Logo() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.2 }}
      className="bg-gray-800 text-white py-8 flex justify-center items-center"
    >
      <motion.div
        className="text-center"
        animate={{
          scale: [1, 1.05, 1],
          transition: { duration: 3, repeat: Number.POSITIVE_INFINITY },
        }}
      >
        <motion.div className="text-5xl font-bold mb-2 bg-gradient-to-r from-cyan-500 to-blue-500 bg-clip-text text-transparent">
          SPOOF
        </motion.div>
        <motion.div className="flex items-center justify-center">
          <motion.div className="text-5xl font-bold bg-gradient-to-r from-cyan-500 to-blue-500 bg-clip-text text-transparent">
            MASTER
          </motion.div>
          <motion.div
            animate={{
              opacity: [0.5, 1, 0.5],
              transition: { duration: 1.5, repeat: Number.POSITIVE_INFINITY },
            }}
          >
            <Image src="/placeholder.svg?height=40&width=40" alt="Sound Wave" width={40} height={40} className="ml-2" />
          </motion.div>
        </motion.div>
      </motion.div>
    </motion.div>
  )
}
