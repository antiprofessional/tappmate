"use client"

import { motion, AnimatePresence } from "framer-motion"
import { X, Clock, CheckCircle2, Loader2 } from "lucide-react"
import { useState, useEffect } from "react"
import type { CryptoType, SubscriptionPlan } from "@/types"
import { CRYPTO_ADDRESSES } from "@/constants/crypto"
import QRCode from "@/components/ui/QRCode"
import CryptoSelector from "@/components/ui/CryptoSelector"
import AddressDisplay from "@/components/ui/AddressDisplay"

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  selectedPlan: SubscriptionPlan
  onPaymentComplete: () => void
}

export default function PaymentModal({ isOpen, onClose, selectedPlan, onPaymentComplete }: PaymentModalProps) {
  const [selectedCrypto, setSelectedCrypto] = useState<CryptoType>("BTC")
  const [isCopied, setIsCopied] = useState(false)
  const [paymentVerifying, setPaymentVerifying] = useState(false)
  const [paymentSuccess, setPaymentSuccess] = useState(false)
  const [timeLeft, setTimeLeft] = useState(300) // 5 minutes in seconds

  // Handle copy to clipboard
  const handleCopyAddress = () => {
    navigator.clipboard.writeText(CRYPTO_ADDRESSES[selectedCrypto])
    setIsCopied(true)
    setTimeout(() => setIsCopied(false), 2000)
  }

  // Handle payment verification
  const handleVerifyPayment = () => {
    setPaymentVerifying(true)

    // Simulate payment verification
    setTimeout(() => {
      setPaymentVerifying(false)
      setPaymentSuccess(true)

      // Simulate page reload after successful payment
      setTimeout(() => {
        onPaymentComplete()
      }, 2000)
    }, 3000)
  }

  // Format time left
  const formatTimeLeft = () => {
    const minutes = Math.floor(timeLeft / 60)
    const seconds = timeLeft % 60
    return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`
  }

  // Timer for payment window
  useEffect(() => {
    if (isOpen && !paymentVerifying && !paymentSuccess) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer)
            return 0
          }
          return prev - 1
        })
      }, 1000)

      return () => clearInterval(timer)
    }
  }, [isOpen, paymentVerifying, paymentSuccess])

  // Reset state when modal is closed
  useEffect(() => {
    if (!isOpen) {
      setTimeLeft(300)
      setPaymentVerifying(false)
      setPaymentSuccess(false)
    }
  }, [isOpen])

  if (!isOpen) return null

  const getPlanPrice = () => {
    switch (selectedPlan) {
      case "1month":
        return "$200"
      case "6months":
        return "$400"
      case "1year":
        return "$750"
      default:
        return "$0"
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-gray-800 rounded-xl p-6 max-w-md w-full"
        >
          {paymentVerifying ? (
            <div className="flex flex-col items-center justify-center py-8">
              <Loader2 className="w-16 h-16 text-cyan-500 animate-spin mb-4" />
              <h3 className="text-xl font-bold mb-2">Please wait</h3>
              <p className="text-gray-300 text-center">Verifying your payment...</p>
            </div>
          ) : paymentSuccess ? (
            <div className="flex flex-col items-center justify-center py-8">
              <CheckCircle2 className="w-16 h-16 text-green-500 mb-4" />
              <h3 className="text-xl font-bold mb-2">Payment Successful!</h3>
              <p className="text-gray-300 text-center mb-4">Thank you for your purchase.</p>
              <p className="text-gray-400 text-center text-sm">Redirecting to your dashboard...</p>
            </div>
          ) : (
            <>
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold">Crypto Payment</h3>
                <div className="flex items-center">
                  <Clock className="w-5 h-5 text-yellow-500 mr-2" />
                  <span className="text-yellow-500 font-medium">{formatTimeLeft()}</span>
                  <button onClick={onClose} className="text-gray-400 hover:text-white ml-4">
                    <X size={24} />
                  </button>
                </div>
              </div>

              <div className="mb-6">
                <p className="text-gray-300 mb-4">
                  Send {getPlanPrice()} worth of cryptocurrency to the following address:
                </p>

                <CryptoSelector
                  selectedCrypto={selectedCrypto}
                  onSelect={(crypto) => setSelectedCrypto(crypto)}
                  cryptoOptions={Object.keys(CRYPTO_ADDRESSES) as CryptoType[]}
                />

                <AddressDisplay
                  address={CRYPTO_ADDRESSES[selectedCrypto]}
                  onCopy={handleCopyAddress}
                  isCopied={isCopied}
                />

                <div className="flex justify-center mb-4">
                  <QRCode value={CRYPTO_ADDRESSES[selectedCrypto]} />
                </div>

                <p className="text-sm text-gray-400 text-center mb-6">
                  Scan this QR code or copy the address above to make your payment
                </p>

                <div className="bg-yellow-900 bg-opacity-30 border border-yellow-700 rounded-md p-3 mb-6">
                  <p className="text-yellow-400 text-sm">
                    <span className="font-bold">Important:</span> Please send exactly the required amount. The payment
                    window will expire in 5 minutes.
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg font-medium"
                  onClick={handleVerifyPayment}
                >
                  I've Sent the Payment
                </motion.button>

                <motion.button
                  whileTap={{ scale: 0.95 }}
                  className="w-full py-3 bg-transparent border border-gray-600 rounded-lg font-medium text-gray-300 hover:bg-gray-700 transition-colors duration-300"
                  onClick={onClose}
                >
                  Cancel
                </motion.button>
              </div>
            </>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
