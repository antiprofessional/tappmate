"use client"

import { motion, AnimatePresence } from "framer-motion"
import { X, Check, Bitcoin, Wallet, Hexagon } from "lucide-react"
import type { SubscriptionPlan } from "@/types"

interface SubscriptionModalProps {
  isOpen: boolean
  onClose: () => void
  onSelectPlan: (plan: SubscriptionPlan) => void
  selectedPlan: SubscriptionPlan
}

export default function SubscriptionModal({ isOpen, onClose, onSelectPlan, selectedPlan }: SubscriptionModalProps) {
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
      },
    },
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const pulseAnimation = {
    scale: [1, 1.02, 1],
    transition: {
      duration: 2,
      repeat: Number.POSITIVE_INFINITY,
      repeatType: "reverse" as const,
    },
  }

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-gray-800 rounded-xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
        >
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-2xl font-bold bg-gradient-to-r from-cyan-500 to-blue-500 bg-clip-text text-transparent">
              Subscription Required
            </h3>
            <button onClick={onClose} className="text-gray-400 hover:text-white">
              <X size={24} />
            </button>
          </div>

          <motion.div className="text-center mb-12" variants={itemVariants} initial="hidden" animate="visible">
            <motion.h2
              className="text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-500 to-blue-500 bg-clip-text text-transparent"
              animate={pulseAnimation}
            >
              UNLOCK PREMIUM SPOOFING
            </motion.h2>
            <motion.p className="text-gray-400 text-xl">
              Choose your subscription plan to access unlimited caller ID spoofing
            </motion.p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-3 gap-8 mb-12"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {/* 1 Month Plan */}
            <motion.div
              className={`bg-gray-900 rounded-xl overflow-hidden border-2 ${
                selectedPlan === "1month" ? "border-cyan-500" : "border-gray-700"
              } transition-all duration-300`}
              variants={itemVariants}
              whileHover={{ y: -10, boxShadow: "0 10px 25px -5px rgba(6, 182, 212, 0.5)" }}
            >
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-200">Basic</h3>
                <div className="flex items-end gap-1 mb-4">
                  <span className="text-4xl font-bold text-white">$200</span>
                  <span className="text-gray-400 mb-1">/month</span>
                </div>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Unlimited Caller ID Spoofing
                  </li>
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Voice Changer
                  </li>
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Text to Speech
                  </li>
                </ul>
                <motion.button
                  className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 rounded-lg font-medium hover:from-cyan-700 hover:to-blue-700 transition-all duration-300"
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onSelectPlan("1month")}
                >
                  Select Plan
                </motion.button>
              </div>
            </motion.div>

            {/* 6 Month Plan */}
            <motion.div
              className={`bg-gray-900 rounded-xl overflow-hidden border-2 ${
                selectedPlan === "6months" ? "border-cyan-500" : "border-gray-700"
              } transition-all duration-300 relative`}
              variants={itemVariants}
              whileHover={{ y: -10, boxShadow: "0 10px 25px -5px rgba(6, 182, 212, 0.5)" }}
            >
              <motion.div
                className="absolute top-0 right-0 bg-cyan-600 text-white text-xs font-bold px-3 py-1"
                animate={{
                  scale: [1, 1.1, 1],
                  transition: { duration: 1.5, repeat: Number.POSITIVE_INFINITY },
                }}
              >
                POPULAR
              </motion.div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-200">Standard</h3>
                <div className="flex items-end gap-1 mb-4">
                  <span className="text-4xl font-bold text-white">$400</span>
                  <span className="text-gray-400 mb-1">/6 months</span>
                </div>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Unlimited Caller ID Spoofing
                  </li>
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Voice Changer
                  </li>
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Text to Speech
                  </li>
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Conference Calls
                  </li>
                </ul>
                <motion.button
                  className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg font-medium hover:from-cyan-600 hover:to-blue-600 transition-all duration-300"
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onSelectPlan("6months")}
                >
                  Select Plan
                </motion.button>
              </div>
            </motion.div>

            {/* 1 Year Plan */}
            <motion.div
              className={`bg-gray-900 rounded-xl overflow-hidden border-2 ${
                selectedPlan === "1year" ? "border-cyan-500" : "border-gray-700"
              } transition-all duration-300`}
              variants={itemVariants}
              whileHover={{ y: -10, boxShadow: "0 10px 25px -5px rgba(6, 182, 212, 0.5)" }}
            >
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-200">Premium</h3>
                <div className="flex items-end gap-1 mb-4">
                  <span className="text-4xl font-bold text-white">$750</span>
                  <span className="text-gray-400 mb-1">/year</span>
                </div>
                <ul className="mb-6 space-y-2">
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Unlimited Caller ID Spoofing
                  </li>
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Voice Changer
                  </li>
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Text to Speech
                  </li>
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Conference Calls
                  </li>
                  <li className="flex items-center text-gray-300">
                    <Check className="w-5 h-5 mr-2 text-cyan-500" />
                    Priority Support
                  </li>
                </ul>
                <motion.button
                  className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 rounded-lg font-medium hover:from-cyan-700 hover:to-blue-700 transition-all duration-300"
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onSelectPlan("1year")}
                >
                  Select Plan
                </motion.button>
              </div>
            </motion.div>
          </motion.div>

          <motion.div className="text-center text-gray-400" variants={itemVariants}>
            <p>We accept cryptocurrency payments only</p>
            <div className="flex justify-center gap-4 mt-4">
              <motion.div whileHover={{ scale: 1.1 }} className="text-yellow-500">
                <Bitcoin size={24} />
              </motion.div>
              <motion.div whileHover={{ scale: 1.1 }} className="text-blue-400">
                <Hexagon size={24} />
              </motion.div>
              <motion.div whileHover={{ scale: 1.1 }} className="text-green-400">
                <Wallet size={24} />
              </motion.div>
            </div>
          </motion.div>

          <motion.div className="mt-8 text-center" variants={itemVariants}>
            <motion.button
              className="text-gray-400 hover:text-white transition-colors duration-300"
              whileHover={{ scale: 1.05 }}
              onClick={onClose}
            >
              Cancel and return to configuration
            </motion.button>
          </motion.div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
