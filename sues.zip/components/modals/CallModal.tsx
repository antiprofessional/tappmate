"use client"

import { motion, AnimatePresence } from "framer-motion"
import { Phone, Mic, Volume2, RefreshCw } from "lucide-react"
import { useState } from "react"

interface CallModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function CallModal({ isOpen, onClose }: CallModalProps) {
  const [callStatus, setCallStatus] = useState("Connecting...")

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-gray-800 rounded-xl p-8 max-w-md w-full text-center"
        >
          <div className="mb-6">
            <div className="w-24 h-24 bg-cyan-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Phone className="w-12 h-12 text-white" />
            </div>
            <h3 className="text-2xl font-bold mb-2">Call in Progress</h3>
            <p className="text-gray-300">{callStatus}</p>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-6">
            <button className="bg-gray-700 hover:bg-gray-600 p-4 rounded-full flex items-center justify-center">
              <Mic className="w-6 h-6 text-white" />
            </button>
            <button className="bg-gray-700 hover:bg-gray-600 p-4 rounded-full flex items-center justify-center">
              <Volume2 className="w-6 h-6 text-white" />
            </button>
            <button className="bg-gray-700 hover:bg-gray-600 p-4 rounded-full flex items-center justify-center">
              <RefreshCw className="w-6 h-6 text-white" />
            </button>
          </div>

          <button
            className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium"
            onClick={onClose}
          >
            End Call
          </button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
