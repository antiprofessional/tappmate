"use client"

import QRCodeReact from "react-qr-code"

interface QRCodeProps {
  value: string
  size?: number
}

export default function QRCode({ value, size = 150 }: QRCodeProps) {
  return (
    <div className="bg-white p-4 rounded-lg">
      <QRCodeReact size={size} value={value} viewBox={`0 0 ${size} ${size}`} />
    </div>
  )
}
