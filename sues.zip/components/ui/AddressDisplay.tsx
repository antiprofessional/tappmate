"use client"
import { Check, Copy } from "lucide-react"

interface AddressDisplayProps {
  address: string
  onCopy: () => void
  isCopied: boolean
}

export default function AddressDisplay({ address, onCopy, isCopied }: AddressDisplayProps) {
  return (
    <div className="bg-gray-900 p-4 rounded-lg mb-4 relative">
      <p className="font-mono text-cyan-400 break-all text-sm">{address}</p>
      <button
        className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
        onClick={onCopy}
      >
        {isCopied ? <Check size={20} className="text-green-500" /> : <Copy size={20} />}
      </button>
    </div>
  )
}
