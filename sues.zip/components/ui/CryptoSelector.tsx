"use client"

import type { CryptoType } from "@/types"

interface CryptoSelectorProps {
  selectedCrypto: CryptoType
  onSelect: (crypto: CryptoType) => void
  cryptoOptions: CryptoType[]
}

export default function CryptoSelector({ selectedCrypto, onSelect, cryptoOptions }: CryptoSelectorProps) {
  return (
    <div className="mb-4">
      <label className="text-sm text-gray-400 mb-2 block">Select cryptocurrency:</label>
      <div className="grid grid-cols-3 gap-2 mb-4">
        {cryptoOptions.map((crypto) => (
          <button
            key={crypto}
            className={`py-2 px-3 rounded-md text-sm font-medium ${
              selectedCrypto === crypto ? "bg-cyan-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"
            }`}
            onClick={() => onSelect(crypto)}
          >
            {crypto}
          </button>
        ))}
      </div>
    </div>
  )
}
