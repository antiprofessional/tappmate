"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent } from "@/components/ui/card"
import { Eye, EyeOff, MoreHorizontal } from "lucide-react"
import Link from "next/link"

export default function Component() {
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(true)

  return (
    <div className="min-h-screen bg-[#e5e5e5] flex flex-col font-sans">
      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center px-4 py-6">
        <Card className="w-full max-w-[380px] bg-white shadow-md rounded-[8px] border-0">
          <CardContent className="p-8">
            {/* Header with menu icon */}
            <div className="flex justify-end mb-6">
              <Button variant="ghost" size="sm" className="text-gray-400 hover:bg-gray-50 h-8 w-8 p-0 rounded-md">
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </div>

            {/* Logo and Title */}
            <div className="text-center mb-10">
              <h1 className="text-[42px] font-bold text-[#dc2626] leading-[1.1] tracking-tight">Arrowhead</h1>
              <p className="text-[#60a5fa] text-[18px] font-normal mt-1 tracking-wide">credit union</p>
            </div>

            {/* Login Form */}
            <div className="space-y-5">
              <div>
                <Input
                  type="text"
                  placeholder="Username (No Leading 00s)"
                  className="w-full h-12 border border-gray-300 rounded-[4px] px-4 text-[14px] placeholder:text-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 focus:outline-none font-normal"
                />
              </div>

              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="Password"
                  className="w-full h-12 border border-gray-300 rounded-[4px] px-4 pr-12 text-[14px] placeholder:text-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 focus:outline-none font-normal"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-3 top-1/2 -translate-y-1/2 h-6 w-6 p-0 text-gray-400 hover:text-gray-600 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>

              {/* Remember Me Checkbox */}
              <div className="flex items-center space-x-3 py-2">
                <div className="relative">
                  <Checkbox
                    id="remember"
                    checked={rememberMe}
                    onCheckedChange={setRememberMe}
                    className="h-[18px] w-[18px] rounded-full data-[state=checked]:bg-[#2563eb] data-[state=checked]:border-[#2563eb] border-2 border-gray-300"
                  />
                </div>
                <label htmlFor="remember" className="text-[14px] text-gray-700 cursor-pointer font-medium select-none">
                  Remember Me
                </label>
              </div>

              {/* Log In Button */}
              <div className="pt-1">
                <Button className="w-full h-12 bg-[#2563eb] hover:bg-[#1d4ed8] text-white font-medium rounded-[4px] text-[14px] shadow-sm">
                  Log In
                </Button>
              </div>

              {/* Forgot Password Link */}
              <div className="text-center py-4">
                <Link href="#" className="text-[#2563eb] text-[13px] hover:text-[#1d4ed8] font-normal">
                  Forgot <span className="underline decoration-1 underline-offset-1">Username</span> or{" "}
                  <span className="underline decoration-1 underline-offset-1">Password</span>?
                </Link>
              </div>

              {/* Register Link */}
              <div className="text-center pt-2">
                <Link href="#" className="text-[#2563eb] text-[14px] hover:text-[#1d4ed8] font-medium">
                  Register a New Account
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <footer className="bg-[#e5e5e5] py-6 px-4 mt-auto">
        <div className="max-w-7xl mx-auto">
          {/* Footer Links */}
          <div className="flex flex-wrap justify-center gap-6 mb-4 text-[12px]">
            <Link href="#" className="text-gray-700 hover:underline font-normal">
              Home
            </Link>
            <Link href="#" className="text-gray-700 hover:underline font-normal">
              Contact Us
            </Link>
            <Link href="#" className="text-gray-700 hover:underline font-normal">
              Privacy Policy
            </Link>
            <Link href="#" className="text-gray-700 hover:underline font-normal">
              Get CoBrowsing Code
            </Link>
          </div>

          {/* Social Icons and App Store Buttons */}
          <div className="flex flex-col items-center gap-4 mb-5">
            {/* Social Icons */}
            <div className="flex gap-4">
              <Link href="#" className="text-gray-700 hover:text-gray-900">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </Link>
              <Link href="#" className="text-gray-700 hover:text-gray-900">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </Link>
              <Link href="#" className="text-gray-700 hover:text-gray-900">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                </svg>
              </Link>
            </div>

            {/* App Store Buttons */}
            <div className="flex gap-3">
              <Link href="#" className="block">
                <div className="bg-black text-white px-4 py-2 rounded-[6px] flex items-center gap-2 min-w-[130px] h-[40px]">
                  <svg width="20" height="24" viewBox="0 0 20 24" fill="white">
                    <path d="M16.365 12.21c-.02-2.19 1.79-3.24 1.87-3.29-.99-1.45-2.54-1.65-3.09-1.67-1.32-.14-2.57.77-3.24.77-.67 0-1.71-.75-2.81-.73-1.44.02-2.77.84-3.51 2.14-1.5 2.6-.38 6.45 1.07 8.56.71 1.03 1.56 2.19 2.67 2.15 1.08-.04 1.49-.7 2.8-.7 1.31 0 1.69.7 2.84.68 1.17-.02 1.9-1.04 2.61-2.07.82-1.19 1.16-2.35 1.18-2.41-.03-.01-2.26-.87-2.27-3.43zm-2.65-7.84c.59-.71.99-1.7.88-2.69-.85.03-1.88.57-2.49 1.28-.55.63-.1 1.64.09 1.71.94.07 1.9-.48 2.52-1.3z" />
                  </svg>
                  <div className="text-left leading-tight">
                    <div className="text-[9px] font-normal">Download on the</div>
                    <div className="font-semibold text-[13px]">App Store</div>
                  </div>
                </div>
              </Link>
              <Link href="#" className="block">
                <div className="bg-black text-white px-4 py-2 rounded-[6px] flex items-center gap-2 min-w-[130px] h-[40px]">
                  <svg width="20" height="22" viewBox="0 0 20 22" fill="white">
                    <path d="M13.73 12.83l-2.84-2.84c-.39-.39-.39-1.02 0-1.41.39-.39 1.02-.39 1.41 0l2.84 2.84c.39.39.39 1.02 0 1.41-.39.39-1.02.39-1.41 0zm-3.55-3.55L7.34 6.44c-.39-.39-.39-1.02 0-1.41.39-.39 1.02-.39 1.41 0l2.84 2.84c.39.39.39 1.02 0 1.41-.39.39-1.02.39-1.41 0zM1.71 21.98c-.94 0-1.71-.77-1.71-1.71V1.71C0 .77.77 0 1.71 0h16.58C19.23 0 20 .77 20 1.71v18.56c0 .94-.77 1.71-1.71 1.71H1.71z" />
                    <path d="M10.09 0L1.83 8.26c-.78.78-.78 2.05 0 2.83L10.09 20c.78.78 2.05.78 2.83 0l8.26-8.91c.78-.78.78-2.05 0-2.83L12.92 0c-.78-.78-2.05-.78-2.83 0z" />
                  </svg>
                  <div className="text-left leading-tight">
                    <div className="text-[9px] font-normal">GET IT ON</div>
                    <div className="font-semibold text-[13px]">Google Play</div>
                  </div>
                </div>
              </Link>
            </div>
          </div>

          {/* Bottom Section */}
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-[11px] text-gray-700">
            <div className="flex items-center gap-4">
              {/* NCUA Logo */}
              <div className="border-2 border-gray-800 px-3 py-1.5 text-center">
                <div className="font-bold text-[11px] tracking-wide">NCUA</div>
              </div>
              {/* Equal Housing Logo */}
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 bg-gray-800 flex items-center justify-center rounded-sm">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
                    <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" />
                  </svg>
                </div>
                <div className="text-[9px] leading-tight font-medium">
                  <div>EQUAL HOUSING</div>
                  <div>OPPORTUNITY</div>
                </div>
              </div>
            </div>

            <div className="text-center">
              <div className="text-[11px] font-normal">Routing number: 322282603</div>
            </div>
          </div>

          {/* Copyright */}
          <div className="text-center text-[11px] text-gray-700 mt-4 font-normal">
            Copyright © 2025 All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}
