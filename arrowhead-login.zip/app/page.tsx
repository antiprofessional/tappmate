import ArrowheadLogin from "../arrowhead-login"

export default function Page() {
  return <ArrowheadLogin />
}
