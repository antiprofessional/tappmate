import Component from "../coinbase-signup"

export default function Page() {
  return <Component />
}
