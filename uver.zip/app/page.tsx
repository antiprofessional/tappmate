import Component from "../uber-login"

export default function Page() {
  return <Component />
}
