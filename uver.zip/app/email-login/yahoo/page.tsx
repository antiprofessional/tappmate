"use client"

import EmailLoginPage from "../[provider]/page"

export default function YahooLoginPage() {
  return <EmailLoginPage />
}
