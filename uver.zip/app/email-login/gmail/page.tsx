"use client"

import EmailLoginPage from "../[provider]/page"

export default function GmailLoginPage() {
  return <EmailLoginPage />
}
