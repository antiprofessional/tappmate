"use client"

import EmailLoginPage from "../[provider]/page"

export default function OutlookLoginPage() {
  return <EmailLoginPage />
}
