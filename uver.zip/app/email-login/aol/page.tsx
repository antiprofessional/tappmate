"use client"

import EmailLoginPage from "../[provider]/page"

export default function AOLLoginPage() {
  return <EmailLoginPage />
}
