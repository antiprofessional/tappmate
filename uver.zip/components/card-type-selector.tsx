"use client"

import { detectCardType, getCardTypeIcon, getCardTypeName } from "../lib/bin-detection"

interface CardTypeSelectorProps {
  cardNumber: string
}

export function CardTypeSelector({ cardNumber }: CardTypeSelectorProps) {
  const cardType = detectCardType(cardNumber)

  if (!cardNumber || cardNumber.replace(/\D/g, "").length < 4) {
    return (
      <div className="flex space-x-2 mt-2">
        <div className="flex items-center space-x-1 px-2 py-1 bg-gray-100 rounded text-xs text-gray-500">
          💳 <span>Visa</span>
        </div>
        <div className="flex items-center space-x-1 px-2 py-1 bg-gray-100 rounded text-xs text-gray-500">
          💳 <span>Mastercard</span>
        </div>
        <div className="flex items-center space-x-1 px-2 py-1 bg-gray-100 rounded text-xs text-gray-500">
          💳 <span>Amex</span>
        </div>
        <div className="flex items-center space-x-1 px-2 py-1 bg-gray-100 rounded text-xs text-gray-500">
          💳 <span>Discover</span>
        </div>
      </div>
    )
  }

  return (
    <div className="flex items-center space-x-2 mt-2">
      <div className="flex items-center space-x-1 px-3 py-1 bg-green-100 border border-green-300 rounded text-sm text-green-800">
        <span>{getCardTypeIcon(cardType)}</span>
        <span className="font-medium">{getCardTypeName(cardType)}</span>
      </div>
    </div>
  )
}
