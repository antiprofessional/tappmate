"use client"

import { useEffect, useState } from "react"
import { detectEmailProvider, getProviderName } from "../lib/email-detection"

interface EmailProviderDetectorProps {
  email: string
  onProviderDetected: (provider: string) => void
}

export function EmailProviderDetector({ email, onProviderDetected }: EmailProviderDetectorProps) {
  const [detectedProvider, setDetectedProvider] = useState<string>("")

  useEffect(() => {
    if (email && email.includes("@")) {
      const provider = detectEmailProvider(email)
      setDetectedProvider(provider)
      onProviderDetected(provider)
    }
  }, [email, onProviderDetected])

  if (!detectedProvider || !email.includes("@")) {
    return null
  }

  return (
    <div className="mt-2 p-2 bg-blue-50 rounded-lg border border-blue-200">
      <p className="text-sm text-blue-700">📧 Detected: {getProviderName(detectedProvider)} account</p>
    </div>
  )
}
