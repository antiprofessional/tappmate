"use client"

import { useEffect, useState } from "react"
import {
  detectCardInfo,
  getCardTypeIcon,
  getCardTypeName,
  getCardLevelName,
  getCardLevelColor,
  formatBIN,
} from "../lib/bin-detection"
import type { CardInfo } from "../lib/bin-detection"

interface CardInfoDisplayProps {
  cardNumber: string
}

export function CardInfoDisplay({ cardNumber }: CardInfoDisplayProps) {
  const [cardInfo, setCardInfo] = useState<CardInfo>({
    type: "unknown",
    level: "unknown",
    bank: "Unknown",
    country: "Unknown",
    isValid: false,
  })

  useEffect(() => {
    if (cardNumber.replace(/\D/g, "").length >= 6) {
      const info = detectCardInfo(cardNumber)
      setCardInfo(info)
    } else {
      setCardInfo({
        type: "unknown",
        level: "unknown",
        bank: "Unknown",
        country: "Unknown",
        isValid: false,
      })
    }
  }, [cardNumber])

  if (!cardInfo.isValid || cardNumber.replace(/\D/g, "").length < 6) {
    return null
  }

  const bin = formatBIN(cardNumber)

  return (
    <div className="mt-3 p-3 bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="space-y-2">
        {/* Card Type and Level */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-lg">{getCardTypeIcon(cardInfo.type)}</span>
            <span className="font-medium text-gray-900">{getCardTypeName(cardInfo.type)}</span>
            <span className={`text-sm font-medium ${getCardLevelColor(cardInfo.level)}`}>
              {getCardLevelName(cardInfo.level)}
            </span>
          </div>
          <div className="text-xs text-gray-500">BIN: {bin}</div>
        </div>

        {/* Bank and Country */}
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-1">
            <span className="text-gray-600">🏦</span>
            <span className="text-gray-700">{cardInfo.bank}</span>
          </div>
          <div className="flex items-center space-x-1">
            <span className="text-gray-600">🌍</span>
            <span className="text-gray-700">{cardInfo.country}</span>
          </div>
        </div>

        {/* Card Features */}
        <div className="flex flex-wrap gap-1 mt-2">
          {cardInfo.level === "gold" && (
            <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">✨ Premium</span>
          )}
          {cardInfo.level === "platinum" && (
            <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded-full">💎 Platinum</span>
          )}
          {cardInfo.level === "infinite" && (
            <span className="px-2 py-1 bg-black text-white text-xs rounded-full">♾️ Infinite</span>
          )}
          {cardInfo.level === "world_elite" && (
            <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">🌟 World Elite</span>
          )}
          {cardInfo.level === "centurion" && (
            <span className="px-2 py-1 bg-black text-white text-xs rounded-full">🏆 Centurion</span>
          )}
          {cardInfo.type === "amex" && (
            <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">🔒 Secure</span>
          )}
        </div>
      </div>
    </div>
  )
}
