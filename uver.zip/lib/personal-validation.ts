export function isValidName(name: string): boolean {
  return name.trim().length >= 2 && /^[a-zA-Z\s\-'.]+$/.test(name.trim())
}

export function isValidDateOfBirth(dob: string): boolean {
  if (!dob) return false

  const date = new Date(dob)
  const today = new Date()
  const minAge = new Date(today.getFullYear() - 120, today.getMonth(), today.getDate())
  const maxAge = new Date(today.getFullYear() - 13, today.getMonth(), today.getDate())

  return date >= minAge && date <= maxAge
}

export function isValidAddress(address: string): boolean {
  return address.trim().length >= 5
}

export function isValidCity(city: string): boolean {
  return city.trim().length >= 2 && /^[a-zA-Z\s\-'.]+$/.test(city.trim())
}

export function isValidStateProvince(state: string): boolean {
  return state.trim().length >= 2
}

export function isValidPhoneNumber(phone: string): boolean {
  // International phone validation - remove all non-digits and check length
  const cleaned = phone.replace(/\D/g, "")
  return cleaned.length >= 7 && cleaned.length <= 15
}

export function formatPhoneNumber(value: string): string {
  // Basic formatting - keep only digits and common symbols
  return value.replace(/[^\d\s\-+$$$$]/g, "").substring(0, 20)
}

export function formatDateOfBirth(value: string): string {
  // Format as YYYY-MM-DD for HTML date input
  return value
}
