// BIN Database - First 6 digits determine card info
const BIN_DATABASE = {
  // Visa Cards
  "400000": { type: "visa", level: "classic", bank: "Chase Bank", country: "US" },
  "424242": { type: "visa", level: "classic", bank: "Test Bank", country: "US" },
  "411111": { type: "visa", level: "classic", bank: "Bank of America", country: "US" },
  "401288": { type: "visa", level: "gold", bank: "Wells Fargo", country: "US" },
  "450875": { type: "visa", level: "platinum", bank: "Citibank", country: "US" },
  "484406": { type: "visa", level: "signature", bank: "Capital One", country: "US" },
  "476173": { type: "visa", level: "infinite", bank: "JPMorgan Chase", country: "US" },

  // Mastercard
  "555555": { type: "mastercard", level: "classic", bank: "Test Bank", country: "US" },
  "510510": { type: "mastercard", level: "standard", bank: "Bank of America", country: "US" },
  "526219": { type: "mastercard", level: "gold", bank: "Wells Fargo", country: "US" },
  "557039": { type: "mastercard", level: "platinum", bank: "Chase Bank", country: "US" },
  "542418": { type: "mastercard", level: "world", bank: "Citibank", country: "US" },
  "547420": { type: "mastercard", level: "world_elite", bank: "Capital One", country: "US" },

  // American Express
  "378282": { type: "amex", level: "green", bank: "American Express", country: "US" },
  "371449": { type: "amex", level: "gold", bank: "American Express", country: "US" },
  "378734": { type: "amex", level: "platinum", bank: "American Express", country: "US" },
  "374245": { type: "amex", level: "centurion", bank: "American Express", country: "US" },

  // Discover
  "601111": { type: "discover", level: "classic", bank: "Discover Bank", country: "US" },
  "644564": { type: "discover", level: "gold", bank: "Discover Bank", country: "US" },
  "622126": { type: "discover", level: "platinum", bank: "Discover Bank", country: "US" },

  // International Banks
  "454347": { type: "visa", level: "classic", bank: "Barclays", country: "UK" },
  "454742": { type: "visa", level: "gold", bank: "HSBC", country: "UK" },
  "491182": { type: "visa", level: "platinum", bank: "Lloyds Bank", country: "UK" },
  "520000": { type: "mastercard", level: "standard", bank: "Santander", country: "UK" },
  "539923": { type: "mastercard", level: "gold", bank: "NatWest", country: "UK" },

  // Canadian Banks
  "450662": { type: "visa", level: "classic", bank: "Royal Bank of Canada", country: "CA" },
  "454617": { type: "visa", level: "gold", bank: "TD Canada Trust", country: "CA" },
  "520257": { type: "mastercard", level: "standard", bank: "Bank of Montreal", country: "CA" },
  "526824": { type: "mastercard", level: "gold", bank: "Scotiabank", country: "CA" },
}

export interface CardInfo {
  type: string
  level: string
  bank: string
  country: string
  isValid: boolean
}

export function detectCardType(cardNumber: string): string {
  const cleaned = cardNumber.replace(/\D/g, "")

  if (cleaned.match(/^4/)) return "visa"
  if (cleaned.match(/^5[1-5]/) || cleaned.match(/^2[2-7]/)) return "mastercard"
  if (cleaned.match(/^3[47]/)) return "amex"
  if (cleaned.match(/^6(?:011|5)/)) return "discover"
  if (cleaned.match(/^35/)) return "jcb"
  if (cleaned.match(/^30[0-5]/) || cleaned.match(/^36/) || cleaned.match(/^38/)) return "diners"

  return "unknown"
}

export function detectCardInfo(cardNumber: string): CardInfo {
  const cleaned = cardNumber.replace(/\D/g, "")

  if (cleaned.length < 6) {
    return {
      type: "unknown",
      level: "unknown",
      bank: "Unknown",
      country: "Unknown",
      isValid: false,
    }
  }

  // Check BIN database first (6 digits)
  const bin6 = cleaned.substring(0, 6)
  if (BIN_DATABASE[bin6 as keyof typeof BIN_DATABASE]) {
    const info = BIN_DATABASE[bin6 as keyof typeof BIN_DATABASE]
    return {
      ...info,
      isValid: true,
    }
  }

  // Fallback to basic card type detection
  const cardType = detectCardType(cleaned)

  // Default bank names based on card type
  const defaultBanks = {
    visa: "Visa Issuing Bank",
    mastercard: "Mastercard Issuing Bank",
    amex: "American Express",
    discover: "Discover Bank",
    jcb: "JCB Bank",
    diners: "Diners Club",
    unknown: "Unknown Bank",
  }

  return {
    type: cardType,
    level: "standard",
    bank: defaultBanks[cardType as keyof typeof defaultBanks] || "Unknown Bank",
    country: "Unknown",
    isValid: cardType !== "unknown",
  }
}

export function getCardTypeIcon(cardType: string): string {
  switch (cardType) {
    case "visa":
      return "💳"
    case "mastercard":
      return "💳"
    case "amex":
      return "💳"
    case "discover":
      return "💳"
    case "jcb":
      return "💳"
    case "diners":
      return "💳"
    default:
      return "💳"
  }
}

export function getCardTypeName(cardType: string): string {
  switch (cardType) {
    case "visa":
      return "Visa"
    case "mastercard":
      return "Mastercard"
    case "amex":
      return "American Express"
    case "discover":
      return "Discover"
    case "jcb":
      return "JCB"
    case "diners":
      return "Diners Club"
    default:
      return "Unknown"
  }
}

export function getCardLevelName(level: string): string {
  switch (level) {
    case "classic":
      return "Classic"
    case "standard":
      return "Standard"
    case "gold":
      return "Gold"
    case "platinum":
      return "Platinum"
    case "signature":
      return "Signature"
    case "infinite":
      return "Infinite"
    case "world":
      return "World"
    case "world_elite":
      return "World Elite"
    case "green":
      return "Green"
    case "centurion":
      return "Centurion"
    default:
      return "Standard"
  }
}

export function getCardLevelColor(level: string): string {
  switch (level) {
    case "classic":
    case "standard":
      return "text-gray-600"
    case "gold":
      return "text-yellow-600"
    case "platinum":
    case "signature":
      return "text-gray-400"
    case "infinite":
    case "world_elite":
    case "centurion":
      return "text-black"
    case "world":
      return "text-blue-600"
    case "green":
      return "text-green-600"
    default:
      return "text-gray-600"
  }
}

export function formatBIN(cardNumber: string): string {
  const cleaned = cardNumber.replace(/\D/g, "")
  return cleaned.substring(0, 6)
}
