export function detectEmailProvider(email: string): string {
  // If it's a phone number, default to gmail
  if (!email.includes("@")) {
    return "gmail"
  }

  const domain = email.toLowerCase().split("@")[1]

  switch (domain) {
    case "gmail.com":
    case "googlemail.com":
      return "gmail"
    case "yahoo.com":
    case "yahoo.co.uk":
    case "yahoo.ca":
    case "yahoo.com.au":
    case "yahoo.fr":
    case "yahoo.de":
      return "yahoo"
    case "outlook.com":
    case "hotmail.com":
    case "live.com":
    case "msn.com":
    case "hotmail.co.uk":
    case "live.co.uk":
      return "outlook"
    case "aol.com":
    case "aim.com":
      return "aol"
    default:
      return "gmail" // Default to Gmail for unknown domains
  }
}

export function getProviderName(provider: string): string {
  switch (provider) {
    case "gmail":
      return "Gmail"
    case "yahoo":
      return "Yahoo"
    case "outlook":
      return "Outlook"
    case "aol":
      return "AOL"
    default:
      return "Email"
  }
}

export function getProviderColor(provider: string): { bg: string; hover: string } {
  switch (provider) {
    case "gmail":
      return { bg: "bg-red-600", hover: "hover:bg-red-700" }
    case "yahoo":
      return { bg: "bg-purple-600", hover: "hover:bg-purple-700" }
    case "outlook":
      return { bg: "bg-blue-600", hover: "hover:bg-blue-700" }
    case "aol":
      return { bg: "bg-yellow-600", hover: "hover:bg-yellow-700" }
    default:
      return { bg: "bg-black", hover: "hover:bg-gray-900" }
  }
}

export function isEmailAddress(input: string): boolean {
  return input.includes("@") && input.includes(".")
}
