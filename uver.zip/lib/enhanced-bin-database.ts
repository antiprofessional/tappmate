// Extended BIN database with more cards
export const EXTENDED_BIN_DATABASE = {
  // Major US Banks - Visa
  "400000": { type: "visa", level: "classic", bank: "Chase Bank", country: "US", network: "Visa" },
  "411111": { type: "visa", level: "classic", bank: "Bank of America", country: "US", network: "Visa" },
  "401288": { type: "visa", level: "gold", bank: "Wells Fargo", country: "US", network: "Visa" },
  "450875": { type: "visa", level: "platinum", bank: "Citibank", country: "US", network: "Visa" },
  "484406": { type: "visa", level: "signature", bank: "Capital One", country: "US", network: "Visa" },
  "476173": { type: "visa", level: "infinite", bank: "JPMorgan Chase", country: "US", network: "Visa" },
  "414720": { type: "visa", level: "business", bank: "US Bank", country: "US", network: "Visa" },
  "463100": { type: "visa", level: "rewards", bank: "PNC Bank", country: "US", network: "Visa" },

  // Major US Banks - Mastercard
  "555555": { type: "mastercard", level: "standard", bank: "Test Bank", country: "US", network: "Mastercard" },
  "510510": { type: "mastercard", level: "standard", bank: "Bank of America", country: "US", network: "Mastercard" },
  "526219": { type: "mastercard", level: "gold", bank: "Wells Fargo", country: "US", network: "Mastercard" },
  "557039": { type: "mastercard", level: "platinum", bank: "Chase Bank", country: "US", network: "Mastercard" },
  "542418": { type: "mastercard", level: "world", bank: "Citibank", country: "US", network: "Mastercard" },
  "547420": { type: "mastercard", level: "world_elite", bank: "Capital One", country: "US", network: "Mastercard" },
  "530131": { type: "mastercard", level: "business", bank: "US Bank", country: "US", network: "Mastercard" },
  "552426": { type: "mastercard", level: "rewards", bank: "Discover Bank", country: "US", network: "Mastercard" },

  // American Express
  "378282": { type: "amex", level: "green", bank: "American Express", country: "US", network: "American Express" },
  "371449": { type: "amex", level: "gold", bank: "American Express", country: "US", network: "American Express" },
  "378734": { type: "amex", level: "platinum", bank: "American Express", country: "US", network: "American Express" },
  "374245": { type: "amex", level: "centurion", bank: "American Express", country: "US", network: "American Express" },
  "343434": { type: "amex", level: "business", bank: "American Express", country: "US", network: "American Express" },

  // UK Banks
  "454347": { type: "visa", level: "classic", bank: "Barclays", country: "UK", network: "Visa" },
  "454742": { type: "visa", level: "gold", bank: "HSBC", country: "UK", network: "Visa" },
  "491182": { type: "visa", level: "platinum", bank: "Lloyds Bank", country: "UK", network: "Visa" },
  "465978": { type: "visa", level: "premier", bank: "NatWest", country: "UK", network: "Visa" },
  "520000": { type: "mastercard", level: "standard", bank: "Santander UK", country: "UK", network: "Mastercard" },
  "539923": { type: "mastercard", level: "gold", bank: "NatWest", country: "UK", network: "Mastercard" },
  "516193": { type: "mastercard", level: "platinum", bank: "HSBC UK", country: "UK", network: "Mastercard" },

  // Canadian Banks
  "450662": { type: "visa", level: "classic", bank: "Royal Bank of Canada", country: "CA", network: "Visa" },
  "454617": { type: "visa", level: "gold", bank: "TD Canada Trust", country: "CA", network: "Visa" },
  "465671": { type: "visa", level: "infinite", bank: "Bank of Montreal", country: "CA", network: "Visa" },
  "520257": { type: "mastercard", level: "standard", bank: "Bank of Montreal", country: "CA", network: "Mastercard" },
  "526824": { type: "mastercard", level: "gold", bank: "Scotiabank", country: "CA", network: "Mastercard" },
  "547702": { type: "mastercard", level: "world_elite", bank: "CIBC", country: "CA", network: "Mastercard" },

  // European Banks
  "450875": { type: "visa", level: "classic", bank: "Deutsche Bank", country: "DE", network: "Visa" },
  "454742": { type: "visa", level: "gold", bank: "Commerzbank", country: "DE", network: "Visa" },
  "491182": { type: "visa", level: "platinum", bank: "Sparkasse", country: "DE", network: "Visa" },
  "520000": { type: "mastercard", level: "standard", bank: "BNP Paribas", country: "FR", network: "Mastercard" },
  "539923": { type: "mastercard", level: "gold", bank: "Crédit Agricole", country: "FR", network: "Mastercard" },
  "516193": { type: "mastercard", level: "platinum", bank: "Société Générale", country: "FR", network: "Mastercard" },

  // Australian Banks
  "450662": { type: "visa", level: "classic", bank: "Commonwealth Bank", country: "AU", network: "Visa" },
  "454617": { type: "visa", level: "gold", bank: "ANZ Bank", country: "AU", network: "Visa" },
  "465671": { type: "visa", level: "platinum", bank: "Westpac", country: "AU", network: "Visa" },
  "520257": { type: "mastercard", level: "standard", bank: "Westpac", country: "AU", network: "Mastercard" },
  "526824": { type: "mastercard", level: "gold", bank: "NAB", country: "AU", network: "Mastercard" },
  "547702": { type: "mastercard", level: "platinum", bank: "Commonwealth Bank", country: "AU", network: "Mastercard" },

  // Discover Cards
  "601111": { type: "discover", level: "classic", bank: "Discover Bank", country: "US", network: "Discover" },
  "644564": { type: "discover", level: "gold", bank: "Discover Bank", country: "US", network: "Discover" },
  "622126": { type: "discover", level: "platinum", bank: "Discover Bank", country: "US", network: "Discover" },
  "601100": { type: "discover", level: "cashback", bank: "Discover Bank", country: "US", network: "Discover" },
}
